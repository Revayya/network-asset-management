# Network Asset Management System
## Database Architecture & Setup Guide

This document describes the relational database schema, integrity constraints, indexing strategies, concurrency safeguards, and SQLyog integration for the `network_asset_management` database.

---

## 1. Relational Schema Architecture

The database is built on MySQL InnoDB engine with full support for foreign key cascades, unique constraints, and atomic transactions.

```mermaid
erDiagram
    users ||--o{ assets : creates
    users ||--o{ asset_usage : issues
    assets ||--o{ asset_usage : contains
    asset_usage ||--o{ asset_returns : references
    users ||--o{ audit_logs : logs

    users {
        int id PK
        string username UK
        string password_hash
        string full_name
        enum role
        string department
        tinyint is_active
        datetime created_at
        datetime last_login_at
    }

    assets {
        int id PK
        string asset_number UK
        string asset_name
        string asset_location
        decimal asset_quantity
        decimal asset_available
        enum uom
        int created_by FK
        datetime created_at
        datetime updated_at
    }

    asset_usage {
        int id PK
        int asset_id FK
        decimal quantity_used
        enum uom
        string used_by
        string department
        string short_description
        int issued_by_user_id FK
        datetime usage_datetime
        datetime created_at
    }

    asset_returns {
        int id PK
        int usage_id FK
        int asset_id FK
        decimal quantity_returned
        string returned_by
        int received_by_user_id FK
        string return_reason
        datetime return_datetime
    }

    audit_logs {
        int id PK
        int user_id FK
        string action
        string entity_type
        int entity_id
        text details
        string ip_address
        datetime created_at
    }
```

---

## 2. Table Specifications

### `users` Table
Stores enterprise credentials and access permissions:
- `id` (INT AUTO_INCREMENT PRIMARY KEY): Unique identifier.
- `username` (VARCHAR(50) UNIQUE NOT NULL): Login username.
- `password_hash` (VARCHAR(255) NOT NULL): Salted cryptographic SHA-256 hash formatted as `<salt>$<hex_hash>`. Plaintext passwords are never stored.
- `role` (ENUM('admin', 'user')): Strict role for server-side access control.
- `is_active` (TINYINT(1) DEFAULT 1): Account lifecycle status flag.

### `assets` Table
Master inventory catalog of network infrastructure and hardware:
- `id` (INT AUTO_INCREMENT PRIMARY KEY): Database primary key.
- `asset_number` (VARCHAR(50) UNIQUE NOT NULL): Enterprise tag (e.g. `NET-SW-9300`).
- `asset_name` (VARCHAR(150) NOT NULL): Equipment description.
- `asset_location` (VARCHAR(100) NOT NULL): Data center rack, IDF room, or warehouse bin.
- `asset_quantity` (DECIMAL(12,2) NOT NULL): Total stock acquired.
- `asset_available` (DECIMAL(12,2) NOT NULL): Current unassigned stock remaining.
- `uom` (ENUM('NO', 'MTR') NOT NULL): Unit of measure (`NO` for discrete hardware, `MTR` for bulk network cables).
- `created_by` (INT NOT NULL): Foreign key referencing `users.id`.

### `asset_usage` Table
Immutable operational transaction ledger recording every asset issuance:
- `id` (INT AUTO_INCREMENT PRIMARY KEY): Transaction ID.
- `asset_id` (INT NOT NULL): Foreign key referencing `assets.id`.
- `quantity_used` (DECIMAL(12,2) NOT NULL): Amount checked out.
- `used_by` (VARCHAR(100) NOT NULL): Employee or technician receiving the item.
- `department` (VARCHAR(100) NOT NULL): Destination department or operational unit.
- `short_description` (VARCHAR(255) NOT NULL): Installation purpose, rack slot, or ticket number.
- `issued_by_user_id` (INT NOT NULL): User who authorized or recorded the checkout.
- `usage_datetime` (DATETIME NOT NULL): Actual transaction timestamp recorded by the server.

### `asset_returns` Table
Records stock returned back into inventory from a prior checkout without overwriting historical usage logs.

### `audit_logs` Table
Immutable security trail logging user logins, asset creations, updates, deletions, and stock transactions with user IDs and IP addresses.

---

## 3. Stock Concurrency and Consistency Safeguards

To prevent race conditions where two technicians attempt to checkout the same remaining item simultaneously:

1. **Atomic Conditional Updates:**
   Stock deduction executes with an atomic SQL predicate:
   ```sql
   UPDATE assets 
   SET asset_available = asset_available - ?, updated_at = NOW() 
   WHERE id = ? AND asset_available >= ?;
   ```
2. **Transaction Rollback:**
   The entire checkout operation runs inside an explicit `conn.BeginTrans ... conn.CommitTrans` boundary. If the atomic update affects 0 rows (indicating stock was depleted), the transaction immediately rolls back and alerts the client with HTTP 409 Conflict.
3. **Immutability of Total Quantity:**
   During ordinary issue transactions, total catalog stock remains unchanged. Only `asset_available` decreases.

---

## 4. SQL Import Guide via SQLyog

1. Open **SQLyog Community Edition**.
2. Connect to your MySQL server.
3. Open `database/setup_all.sql` by pressing `Ctrl + O`.
4. Press `F9` (or click the green Execute button) to run the complete script.
5. In the message window, verify that all queries executed with 0 errors.
