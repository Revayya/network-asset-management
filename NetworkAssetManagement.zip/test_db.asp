<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Database Diagnostic - Network Asset Management</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 30px; background: #f8fafc; color: #1e293b; }
        .box { background: #fff; max-width: 750px; margin: 0 auto; padding: 25px; border-radius: 8px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        h2 { margin-top: 0; color: #0f172a; }
        .success { color: #10b981; font-weight: bold; }
        .fail { color: #ef4444; font-weight: bold; }
        .log-item { padding: 10px; border-bottom: 1px solid #f1f5f9; font-size: 13px; }
        pre { background: #0f172a; color: #38bdf8; padding: 14px; border-radius: 6px; overflow-x: auto; font-size: 12px; }
    </style>
</head>
<body>
<div class="box">
    <h2>NetAsset Diagnostic Utility</h2>
    <p>Tests ADODB, ODBC Drivers, and MySQL Database Connection.</p>
    <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 15px 0;">

<%
Dim testConn
Set testConn = GetDbConnection()

If Not testConn Is Nothing Then
    Response.Write "<div class='log-item'><span class='success'>&#10004; Database Connection Successful!</span></div>"
    
    On Error Resume Next
    Dim rsVer
    Set rsVer = testConn.Execute("SELECT VERSION() AS ver, DATABASE() AS cur_db, NOW() AS cur_time")
    If Err.Number = 0 Then
        Response.Write "<div class='log-item'><strong>MySQL Engine Version:</strong> " & rsVer("ver") & "</div>"
        Response.Write "<div class='log-item'><strong>Connected Database:</strong> " & rsVer("cur_db") & "</div>"
        Response.Write "<div class='log-item'><strong>Database Server Time:</strong> " & rsVer("cur_time") & "</div>"
    End If
    rsVer.Close
    Set rsVer = Nothing

    ' Verify tables
    Dim tables, t, foundTables, missingTables
    tables = Array("users", "assets", "asset_usage", "audit_logs", "app_settings", "asset_returns")
    foundTables = ""
    missingTables = ""
    
    For Each t in tables
        Dim rsT
        Err.Clear
        Set rsT = testConn.Execute("SELECT COUNT(*) AS c FROM " & t)
        If Err.Number = 0 Then
            foundTables = foundTables & t & " (" & rsT("c") & " rows), "
            rsT.Close
        Else
            missingTables = missingTables & t & ", "
            Err.Clear
        End If
        Set rsT = Nothing
    Next

    If foundTables <> "" Then
        Response.Write "<div class='log-item'><span class='success'>&#10004; Verified Tables:</span> " & Left(foundTables, Len(foundTables) - 2) & "</div>"
    End If
    If missingTables <> "" Then
        Response.Write "<div class='log-item'><span class='fail'>&#10008; Missing Tables:</span> " & Left(missingTables, Len(missingTables) - 2) & " (Please import setup_all.sql into MySQL)</div>"
    End If

    CloseDbConnection testConn
Else
    Response.Write "<div class='log-item'><span class='fail'>&#10008; Database Connection Failed!</span></div>"
    Response.Write "<div class='log-item'><strong>Diagnostics Details:</strong><br><pre>" & Server.HTMLEncode(g_LastDbError) & "</pre></div>"
    Response.Write "<div class='log-item'><strong>Troubleshooting Steps:</strong><ol>" & _
                   "<li>Verify MySQL Server is running on port <code>3306</code>.</li>" & _
                   "<li>Verify database <code>network_asset_management</code> exists. Import <code>database/setup_all.sql</code>.</li>" & _
                   "<li>Check credentials in <code>config/config.asp</code> (User, Password, Port).</li>" & _
                   "<li>Ensure MySQL ODBC 5.1 or 8.0 Driver is installed.</li>" & _
                   "</ol></div>"
End If
%>
    <div style="margin-top: 20px;">
        <a href="dashboard.asp" style="display: inline-block; padding: 8px 16px; background: #2563eb; color: #fff; text-decoration: none; border-radius: 6px; font-size: 13px;">Return to Dashboard</a>
    </div>
</div>
</body>
</html>
