<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<%
' If already authenticated, redirect directly to dashboard
If IsUserLoggedIn() Then
    Response.Redirect "dashboard.asp"
    Response.End
End If

Dim errorMessage, infoMessage
errorMessage = ""
infoMessage = ""

Dim msgParam
msgParam = Request.QueryString("msg")
If msgParam = "logged_out" Then
    infoMessage = "You have been successfully logged out."
ElseIf msgParam = "session_expired" Then
    errorMessage = "Your session has expired due to inactivity. Please log in again."
ElseIf msgParam = "access_denied" Then
    errorMessage = "Access denied. Administrator privileges required."
End If

' Handle POST Login Submission
If Request.ServerVariables("REQUEST_METHOD") = "POST" Then
    Dim postUsername, postPassword, postCsrf
    postUsername = CleanInput(Request.Form("username"))
    postPassword = CleanInput(Request.Form("password"))
    postCsrf     = CleanInput(Request.Form("csrf_token"))

    If Not VerifyCsrfToken(postCsrf) Then
        errorMessage = "Security validation failed. Please refresh the page and try again."
    ElseIf postUsername = "" Or postPassword = "" Then
        errorMessage = "Please enter both username and password."
    Else
        Dim conn
        Set conn = GetDbConnection()
        
        If conn Is Nothing Then
            errorMessage = "Database connection error. Please check database server and ODBC settings."
        Else
            On Error Resume Next
            Dim cmdAuth, rsAuth
            Set cmdAuth = Server.CreateObject("ADODB.Command")
            Set cmdAuth.ActiveConnection = conn
            cmdAuth.CommandText = "SELECT id, username, password_hash, full_name, role, department, is_active FROM users WHERE username = ?"
            cmdAuth.CommandType = 1
            cmdAuth.Parameters.Append cmdAuth.CreateParameter("p_u", 200, 1, 50, postUsername)
            Set rsAuth = cmdAuth.Execute

            If Not rsAuth.EOF Then
                If rsAuth("is_active") <> 1 Then
                    errorMessage = "This account is inactive. Please contact your system administrator."
                Else
                    Dim storedHash, isMatch
                    storedHash = rsAuth("password_hash")
                    isMatch = VerifyPasswordWithConn(postPassword, storedHash, conn)

                    If isMatch Then
                        ' Successful Login
                        PerformLogin rsAuth("id"), rsAuth("username"), rsAuth("full_name"), rsAuth("role"), rsAuth("department"), conn
                        LogAudit conn, rsAuth("id"), "USER_LOGIN", "AUTH", rsAuth("id"), "User logged in successfully"
                        
                        rsAuth.Close
                        Set rsAuth = Nothing
                        Set cmdAuth = Nothing
                        CloseDbConnection conn
                        
                        Response.Redirect "dashboard.asp"
                        Response.End
                    Else
                        errorMessage = "Invalid username or password. Please try again."
                        LogAudit conn, Null, "LOGIN_FAILED", "AUTH", Null, "Failed password attempt for username: " & postUsername
                    End If
                End If
            Else
                errorMessage = "Invalid username or password. Please try again."
            End If

            rsAuth.Close
            Set rsAuth = Nothing
            Set cmdAuth = Nothing
            CloseDbConnection conn
            On Error GoTo 0
        End If
    End If
End If
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sign In - Network Asset Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body class="login-body">
    <div class="login-card">
        <div class="login-brand">
            <svg class="login-brand-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
                <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
                <line x1="6" y1="6" x2="6.01" y2="6"></line>
                <line x1="6" y1="18" x2="6.01" y2="18"></line>
                <line x1="10" y1="10" x2="14" y2="14"></line>
            </svg>
            <h1 class="login-title">NetAsset Core</h1>
            <p class="login-subtitle">Network Asset & Inventory Management System</p>
        </div>

        <% If errorMessage <> "" Then %>
            <div class="form-error" style="background-color: var(--danger-light); padding: 10px 14px; border-radius: var(--radius-md); margin-bottom: 20px; font-weight: 500;">
                <%= HtmlEncode(errorMessage) %>
            </div>
        <% End If %>

        <% If infoMessage <> "" Then %>
            <div class="form-text text-success" style="background-color: var(--success-light); padding: 10px 14px; border-radius: var(--radius-md); margin-bottom: 20px; font-weight: 500;">
                <%= HtmlEncode(infoMessage) %>
            </div>
        <% End If %>

        <form method="POST" action="login.asp" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<%= GetCsrfToken() %>">

            <div class="form-group">
                <label for="username" class="form-label required">Username</label>
                <input type="text" id="username" name="username" class="form-control" placeholder="Enter username" required autofocus value="<%= HtmlEncode(Request.Form("username")) %>">
            </div>

            <div class="form-group">
                <label for="password" class="form-label required">Password</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-lg" style="width: 100%; margin-top: 10px;">
                Sign In to NetAsset
            </button>
        </form>

        <div class="login-help-box">
            <strong>Initial Evaluation Credentials:</strong>
            <div style="margin-top: 6px; display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
                <div>
                    <strong>Admin Role:</strong><br>
                    User: <code>admin</code><br>
                    Pass: <code>Admin@12345</code>
                </div>
                <div>
                    <strong>User Role:</strong><br>
                    User: <code>user</code><br>
                    Pass: <code>User@12345</code>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
