/**
 * Network Asset Management System
 * Filter and Pagination Utilities (filters.js)
 */

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Render pagination controls
 * @param {string} containerId 
 * @param {number} currentPage 
 * @param {number} totalPages 
 * @param {number} totalRecords 
 * @param {number} pageSize 
 * @param {function} onPageClick 
 */
function renderPagination(containerId, currentPage, totalPages, totalRecords, pageSize, onPageClick) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (totalRecords === 0) {
        container.innerHTML = '<div class="text-muted">No records found</div>';
        return;
    }

    const startRecord = (currentPage - 1) * pageSize + 1;
    const endRecord = Math.min(currentPage * pageSize, totalRecords);

    let html = `
        <div class="pagination-info">
            Showing <strong>${startRecord}</strong> to <strong>${endRecord}</strong> of <strong>${totalRecords}</strong> entries
        </div>
        <div class="pagination-controls">
            <button type="button" class="page-btn" ${currentPage <= 1 ? 'disabled' : ''} data-page="${currentPage - 1}">
                &laquo;
            </button>
    `;

    // Calculate visible page buttons (max 5)
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, startPage + 4);
    if (endPage - startPage < 4) {
        startPage = Math.max(1, endPage - 4);
    }

    for (let p = startPage; p <= endPage; p++) {
        html += `
            <button type="button" class="page-btn ${p === currentPage ? 'active' : ''}" data-page="${p}">
                ${p}
            </button>
        `;
    }

    html += `
            <button type="button" class="page-btn ${currentPage >= totalPages ? 'disabled' : ''} data-page="${currentPage + 1}">
                &raquo;
            </button>
        </div>
    `;

    container.innerHTML = html;

    // Attach click events
    container.querySelectorAll('.page-btn[data-page]').forEach(btn => {
        btn.addEventListener('click', function() {
            if (this.disabled) return;
            const targetPage = parseInt(this.getAttribute('data-page'), 10);
            if (!isNaN(targetPage) && targetPage >= 1 && targetPage <= totalPages && targetPage !== currentPage) {
                onPageClick(targetPage);
            }
        });
    });
}

/**
 * Triggers a file download via hidden iframe or anchor
 */
function triggerCsvExport(csvUrl, filterParams, filename) {
    const query = new URLSearchParams(filterParams).toString();
    const fullUrl = `${csvUrl}?${query}&export=csv&_t=${Date.now()}`;
    
    showToast('Preparing CSV export...', 'info', 2000);
    
    const a = document.createElement('a');
    a.href = fullUrl;
    a.download = filename || 'export.csv';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => a.remove(), 1000);
}
