<%
' ===================================================================
' Network Asset Management System
' Role-Based Access Control and Server-Side Enforcement (permissions.asp)
' ===================================================================

Function IsAdmin()
    IsAdmin = (GetAuthRole() = "admin")
End Function

Function IsApiRequest()
    Dim scriptName, acceptHdr
    scriptName = LCase(Request.ServerVariables("QUERY_STRING"))
    acceptHdr = LCase(Request.ServerVariables("HTTP_ACCEPT"))
    
    If InStr(scriptName, "ajax=1") > 0 Or InStr(acceptHdr, "application/json") > 0 Then
        IsApiRequest = True
    Else
        IsApiRequest = False
    End If
End Function

Sub RequireLogin()
    If Not IsUserLoggedIn() Then
        If IsApiRequest() Then
            Response.Clear
            Response.ContentType = "application/json; charset=utf-8"
            Response.Status = "401 Unauthorized"
            Response.Write "{""success"":false,""message"":""Session expired or not authenticated. Please log in."",""data"":null}"
            Response.End
        Else
            Response.Redirect "login.asp?msg=session_expired"
            Response.End
        End If
    End If
End Sub

Sub RequireAdmin()
    RequireLogin()
    If Not IsAdmin() Then
        If IsApiRequest() Then
            Response.Clear
            Response.ContentType = "application/json; charset=utf-8"
            Response.Status = "403 Forbidden"
            Response.Write "{""success"":false,""message"":""Access denied. Administrator privileges required."",""data"":null}"
            Response.End
        Else
            Response.Redirect "dashboard.asp?msg=access_denied"
            Response.End
        End If
    End If
End Sub
%>
