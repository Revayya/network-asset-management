/**
 * Network Asset Management System
 * Asset Usage and Issuance UI Helpers (asset_usage.js)
 */

document.addEventListener('DOMContentLoaded', function() {
    const issueForm = document.getElementById('issueAssetForm');
    if (issueForm) {
        issueForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            const assetId = document.getElementById('issueAssetSelect').value;
            const qtyUsed = parseFloat(document.getElementById('issueQuantityUsed').value);
            const usedBy = document.getElementById('issueUsedBy').value.trim();
            const dept = document.getElementById('issueDepartment').value.trim();
            const desc = document.getElementById('issueDescription').value.trim();

            if (!assetId) {
                showToast('Please select an asset.', 'warning');
                return;
            }

            if (isNaN(qtyUsed) || qtyUsed <= 0) {
                showToast('Quantity used must be greater than zero.', 'warning');
                return;
            }

            if (!usedBy || !dept || !desc) {
                showToast('Please fill all required fields.', 'warning');
                return;
            }

            const submitBtn = document.getElementById('btnSubmitIssueAsset');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Processing...';
            }

            const res = await apiFetch('asset_issue.asp?ajax=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    asset_id: parseInt(assetId, 10),
                    quantity_used: qtyUsed,
                    used_by: usedBy,
                    department: dept,
                    short_description: desc
                })
            });

            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Submit Usage Request';
            }

            if (res.success) {
                showToast('Asset issued successfully!', 'success');
                closeModal('issueAssetModal');
                setTimeout(() => window.location.reload(), 600);
            } else {
                showToast(res.message || 'Transaction failed.', 'error');
            }
        });
    }
});
