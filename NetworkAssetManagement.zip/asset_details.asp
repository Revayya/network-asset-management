<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireLogin()

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error: " & g_LastDbError
    Response.End
End If

Dim assetId
assetId = CleanInput(Request("id"))

If Not IsNumeric(assetId) Or CLng(assetId) <= 0 Then
    CloseDbConnection conn
    Response.Redirect "assets.asp?msg=invalid_id"
    Response.End
End If

' Fetch Asset
Dim cmd, rs
Set cmd = Server.CreateObject("ADODB.Command")
Set cmd.ActiveConnection = conn
cmd.CommandText = "SELECT a.*, COALESCE(u.full_name, 'System') AS creator_name " & _
                  "FROM assets a LEFT JOIN users u ON a.created_by = u.id WHERE a.id = ?"
cmd.CommandType = 1
cmd.Parameters.Append cmd.CreateParameter("p_id", 3, 1, , CLng(assetId))
Set rs = cmd.Execute

If rs.EOF Then
    rs.Close
    Set rs = Nothing
    Set cmd = Nothing
    CloseDbConnection conn
    Response.Redirect "assets.asp?msg=not_found"
    Response.End
End If

Dim aNum, aName, aLoc, aQty, aAvail, aUom, aCreated, aUpdated, aCreator
aNum     = rs("asset_number")
aName    = rs("asset_name")
aLoc     = rs("asset_location")
aQty     = rs("asset_quantity")
aAvail   = rs("asset_available")
aUom     = rs("uom")
aCreated = rs("created_at")
aUpdated = rs("updated_at")
aCreator = rs("creator_name")

rs.Close
Set rs = Nothing
Set cmd = Nothing

' Fetch Usage History for this asset
Dim rsUsage
Set rsUsage = conn.Execute("SELECT id, quantity_used, uom, used_by, department, short_description, usage_datetime " & _
                           "FROM asset_usage WHERE asset_id = " & CLng(assetId) & " ORDER BY usage_datetime DESC, id DESC")

Dim pageTitle
pageTitle = "Asset Details: " & aNum
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Asset Specifications: <%= HtmlEncode(aNum) %></h1>
        <p><%= HtmlEncode(aName) %> &bull; Location: <%= HtmlEncode(aLoc) %></p>
    </div>
    <div class="page-header-actions">
        <% If CDbl(aAvail) > 0 Then %>
        <a href="asset_issue.asp?asset_id=<%= assetId %>" class="btn btn-primary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>
            <span>Issue This Asset</span>
        </a>
        <% End If %>

        <% If IsAdmin() Then %>
        <a href="asset_edit.asp?id=<%= assetId %>" class="btn btn-secondary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><polygon points="14 2 18 6 7 17 3 17 3 13 14 2"></polygon><line x1="3" y1="22" x2="21" y2="22"></line></svg>
            <span>Edit Asset</span>
        </a>
        <% End If %>

        <a href="assets.asp" class="btn btn-secondary">&larr; Back to Assets</a>
    </div>
</div>

<!-- Specs Cards Grid -->
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header">
        <h3 class="card-title">Hardware Specifications</h3>
    </div>
    <div class="card-body">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px;">
            <div>
                <label class="text-muted" style="font-size: 11px; font-weight: 700; text-transform: uppercase;">Asset Tag / Number</label>
                <div class="font-mono font-bold text-primary" style="font-size: 16px;"><%= HtmlEncode(aNum) %></div>
            </div>
            <div>
                <label class="text-muted" style="font-size: 11px; font-weight: 700; text-transform: uppercase;">Unit of Measurement</label>
                <div>
                    <span class="badge <%= IIf(aUom = "MTR", "badge-uom-mtr", "badge-uom-no") %>"><%= HtmlEncode(aUom) %></span>
                </div>
            </div>
            <div>
                <label class="text-muted" style="font-size: 11px; font-weight: 700; text-transform: uppercase;">Total Catalog Stock</label>
                <div class="font-bold" style="font-size: 18px;"><%= FormatDisplayQuantity(aQty, aUom) %></div>
            </div>
            <div>
                <label class="text-muted" style="font-size: 11px; font-weight: 700; text-transform: uppercase;">Currently Available</label>
                <div class="font-bold text-success" style="font-size: 18px;"><%= FormatDisplayQuantity(aAvail, aUom) %></div>
            </div>
            <div>
                <label class="text-muted" style="font-size: 11px; font-weight: 700; text-transform: uppercase;">Physical Rack Location</label>
                <div style="font-size: 14px;"><%= HtmlEncode(aLoc) %></div>
            </div>
            <div>
                <label class="text-muted" style="font-size: 11px; font-weight: 700; text-transform: uppercase;">Registered By</label>
                <div style="font-size: 14px;"><%= HtmlEncode(aCreator) %></div>
            </div>
            <div>
                <label class="text-muted" style="font-size: 11px; font-weight: 700; text-transform: uppercase;">Date Added</label>
                <div class="font-mono text-muted" style="font-size: 12px;"><%= FormatDisplayDate(aCreated) %></div>
            </div>
            <div>
                <label class="text-muted" style="font-size: 11px; font-weight: 700; text-transform: uppercase;">Last Updated</label>
                <div class="font-mono text-muted" style="font-size: 12px;"><%= FormatDisplayDate(aUpdated) %></div>
            </div>
        </div>
    </div>
</div>

<!-- Attached Usage Transactions -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Transaction & Issue History for this Asset</h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>TX ID</th>
                    <th>Used By</th>
                    <th>Department</th>
                    <th>Quantity Issued</th>
                    <th>Date & Time</th>
                    <th>Description / Purpose</th>
                </tr>
            </thead>
            <tbody>
                <% If rsUsage.EOF Then %>
                    <tr><td colspan="6" class="empty-state"><p>No usage records recorded for this asset yet.</p></td></tr>
                <% Else %>
                    <% Do While Not rsUsage.EOF %>
                    <tr>
                        <td class="font-mono text-muted">#TX-<%= rsUsage("id") %></td>
                        <td><strong><%= HtmlEncode(rsUsage("used_by")) %></strong></td>
                        <td><span class="badge" style="background:#f1f5f9; color:#334155;"><%= HtmlEncode(rsUsage("department")) %></span></td>
                        <td class="text-danger font-bold">-<%= FormatDisplayQuantity(rsUsage("quantity_used"), rsUsage("uom")) %></td>
                        <td class="text-muted font-mono" style="font-size: 11px;"><%= FormatDisplayDate(rsUsage("usage_datetime")) %></td>
                        <td><%= HtmlEncode(rsUsage("short_description")) %></td>
                    </tr>
                    <% rsUsage.MoveNext %>
                    <% Loop %>
                <% End If %>
            </tbody>
        </table>
    </div>
</div>

<%
rsUsage.Close
Set rsUsage = Nothing
CloseDbConnection conn
%>

<!--#include file="includes/footer.asp"-->
