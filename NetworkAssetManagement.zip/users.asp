<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireAdmin()
Dim pageTitle
pageTitle = "User Management"

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error: " & g_LastDbError
    Response.End
End If

Dim errorMessage, successMessage
errorMessage = ""
successMessage = ""

' Handle POST actions
If Request.ServerVariables("REQUEST_METHOD") = "POST" Then
    Dim action
    action = CleanInput(Request.Form("action"))

    Select Case action
        Case "create"
            Dim username, password, fullName, role, department
            username   = CleanInput(Request.Form("username"))
            password   = CleanInput(Request.Form("password"))
            fullName   = CleanInput(Request.Form("full_name"))
            role       = LCase(CleanInput(Request.Form("role")))
            department = CleanInput(Request.Form("department"))

            If Not IsValidUsername(username) Then
                errorMessage = "Username must be 3-50 alphanumeric characters (or _, -, .)."
            ElseIf Len(password) < 6 Then
                errorMessage = "Password must be at least 6 characters long."
            ElseIf fullName = "" Then
                errorMessage = "Full Name is required."
            Else
                If role <> "admin" And role <> "user" Then role = "user"
                
                On Error Resume Next
                ' Duplicate check
                Dim cmdDup, rsDup
                Set cmdDup = Server.CreateObject("ADODB.Command")
                Set cmdDup.ActiveConnection = conn
                cmdDup.CommandText = "SELECT id FROM users WHERE username = ?"
                cmdDup.CommandType = 1
                cmdDup.Parameters.Append cmdDup.CreateParameter("p_u", 200, 1, 50, username)
                Set rsDup = cmdDup.Execute

                If Not rsDup.EOF Then
                    errorMessage = "Username '" & username & "' is already taken."
                    rsDup.Close
                    Set rsDup = Nothing
                    Set cmdDup = Nothing
                Else
                    rsDup.Close
                    Set rsDup = Nothing
                    Set cmdDup = Nothing

                    Dim salt, pwdHash, fullHash
                    salt = GenerateSalt(32)
                    pwdHash = HashPasswordWithConn(password, salt, conn)
                    fullHash = salt & "$" & pwdHash

                    Dim cmdAdd
                    Set cmdAdd = Server.CreateObject("ADODB.Command")
                    Set cmdAdd.ActiveConnection = conn
                    cmdAdd.CommandText = "INSERT INTO users (username, password_hash, full_name, role, department, is_active, created_at) VALUES (?, ?, ?, ?, ?, 1, NOW())"
                    cmdAdd.CommandType = 1
                    cmdAdd.Parameters.Append cmdAdd.CreateParameter("p_u", 200, 1, 50, username)
                    cmdAdd.Parameters.Append cmdAdd.CreateParameter("p_h", 200, 1, 255, fullHash)
                    cmdAdd.Parameters.Append cmdAdd.CreateParameter("p_n", 200, 1, 100, fullName)
                    cmdAdd.Parameters.Append cmdAdd.CreateParameter("p_r", 200, 1, 10, role)
                    cmdAdd.Parameters.Append cmdAdd.CreateParameter("p_d", 200, 1, 100, department)
                    cmdAdd.Execute
                    Set cmdAdd = Nothing

                    LogAudit conn, GetAuthUserId(), "USER_CREATE", "USER", 0, "Created user '" & username & "' (" & fullName & ") with role " & role
                    successMessage = "User account created successfully!"
                End If
                On Error GoTo 0
            End If

        Case "toggle_status"
            Dim targetId, newStatus
            targetId  = CleanInput(Request.Form("user_id"))
            newStatus = CleanInput(Request.Form("is_active"))

            If IsNumeric(targetId) And CLng(targetId) > 0 Then
                If CLng(targetId) = GetAuthUserId() Then
                    errorMessage = "You cannot deactivate your own account."
                Else
                    Dim statusVal
                    If newStatus = "1" Then statusVal = 1 Else statusVal = 0
                    conn.Execute "UPDATE users SET is_active = " & statusVal & ", updated_at = NOW() WHERE id = " & CLng(targetId)
                    LogAudit conn, GetAuthUserId(), "USER_STATUS_CHANGE", "USER", CLng(targetId), "Changed active status to " & statusVal
                    successMessage = "User account status updated!"
                End If
            End If

        Case "reset_password"
            Dim rUserId, rNewPass
            rUserId  = CleanInput(Request.Form("user_id"))
            rNewPass = CleanInput(Request.Form("new_password"))

            If Not IsNumeric(rUserId) Or CLng(rUserId) <= 0 Then
                errorMessage = "Valid user ID is required."
            ElseIf Len(rNewPass) < 6 Then
                errorMessage = "New password must be at least 6 characters long."
            Else
                Dim rSalt, rHash, rFullHash
                rSalt = GenerateSalt(32)
                rHash = HashPasswordWithConn(rNewPass, rSalt, conn)
                rFullHash = rSalt & "$" & rHash

                Dim cmdReset
                Set cmdReset = Server.CreateObject("ADODB.Command")
                Set cmdReset.ActiveConnection = conn
                cmdReset.CommandText = "UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?"
                cmdReset.CommandType = 1
                cmdReset.Parameters.Append cmdReset.CreateParameter("p_h", 200, 1, 255, rFullHash)
                cmdReset.Parameters.Append cmdReset.CreateParameter("p_id", 3, 1, , CLng(rUserId))
                cmdReset.Execute
                Set cmdReset = Nothing

                LogAudit conn, GetAuthUserId(), "USER_PASSWORD_RESET", "USER", CLng(rUserId), "Password reset by administrator"
                successMessage = "Password has been successfully reset!"
            End If
    End Select
End If

' Fetch all users for rendering
Dim rsUsers
Set rsUsers = conn.Execute("SELECT id, username, full_name, role, department, is_active, created_at, last_login_at FROM users ORDER BY id ASC")
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>User Account Management</h1>
        <p>Control user authentication, assign roles, manage permissions, and enforce password resets.</p>
    </div>
    <div class="page-header-actions">
        <button type="button" class="btn btn-primary" onclick="openModal('addUserModal')">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
            <span>Add User</span>
        </button>
    </div>
</div>

<% If errorMessage <> "" Then %>
    <div class="form-error" style="background-color: var(--danger-light); padding: 12px 18px; border-radius: var(--radius-md); margin-bottom: 20px;">
        &#10008; <%= HtmlEncode(errorMessage) %>
    </div>
<% End If %>

<% If successMessage <> "" Then %>
    <div style="background-color: var(--success-light); color: var(--success); padding: 12px 18px; border-radius: var(--radius-md); margin-bottom: 20px; font-weight: 500;">
        &#10004; <%= HtmlEncode(successMessage) %>
    </div>
<% End If %>

<div class="card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Role</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Last Login</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <% If rsUsers.EOF Then %>
                    <tr><td colspan="9" class="empty-state"><p>No user accounts found</p></td></tr>
                <% Else %>
                    <% Do While Not rsUsers.EOF %>
                    <% 
                    Dim isActive: isActive = (rsUsers("is_active") = 1)
                    Dim isSelf: isSelf = (GetAuthUserId() = rsUsers("id"))
                    %>
                    <tr>
                        <td class="font-mono text-muted">#<%= rsUsers("id") %></td>
                        <td><strong class="font-mono"><%= HtmlEncode(rsUsers("username")) %></strong></td>
                        <td><%= HtmlEncode(rsUsers("full_name")) %></td>
                        <td>
                            <span class="badge <%= IIf(rsUsers("role") = "admin", "badge-admin", "badge-user") %>"><%= UCase(rsUsers("role")) %></span>
                        </td>
                        <td><%= HtmlEncode(IIf(IsNull(rsUsers("department")), "-", rsUsers("department"))) %></td>
                        <td>
                            <% If isActive Then %>
                                <span class="badge badge-stock-in">Active</span>
                            <% Else %>
                                <span class="badge badge-stock-out">Inactive</span>
                            <% End If %>
                        </td>
                        <td class="text-muted font-mono" style="font-size: 11px;"><%= FormatDisplayDate(rsUsers("created_at")) %></td>
                        <td class="text-muted font-mono" style="font-size: 11px;"><%= FormatDisplayDate(rsUsers("last_login_at")) %></td>
                        <td style="text-align: right;">
                            <div style="display: flex; gap: 4px; justify-content: flex-end;">
                                <button type="button" class="btn btn-sm btn-secondary" onclick="openResetModal(<%= rsUsers("id") %>, '<%= EscapeJson(rsUsers("username")) %>')">Reset Pass</button>
                                
                                <% If Not isSelf Then %>
                                    <form method="POST" action="users.asp" style="display: inline;">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <input type="hidden" name="user_id" value="<%= rsUsers("id") %>">
                                        <input type="hidden" name="is_active" value="<%= IIf(isActive, 0, 1) %>">
                                        <button type="submit" class="btn btn-sm <%= IIf(isActive, "btn-outline-danger", "btn-success") %>" onclick="return confirm('Change status for this user?');">
                                            <%= IIf(isActive, "Deactivate", "Activate") %>
                                        </button>
                                    </form>
                                <% End If %>
                            </div>
                        </td>
                    </tr>
                    <% rsUsers.MoveNext %>
                    <% Loop %>
                <% End If %>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: Add User -->
<div class="modal-overlay" id="addUserModal" style="display: none;">
    <div class="modal-card">
        <div class="modal-header">
            <h3 class="modal-title">Create User Account</h3>
            <button type="button" class="modal-close" onclick="closeModal('addUserModal')">&times;</button>
        </div>
        <form method="POST" action="users.asp">
            <input type="hidden" name="action" value="create">
            <div class="modal-body">
                <div class="form-group">
                    <label for="nu_name" class="form-label required">Username</label>
                    <input type="text" id="nu_name" name="username" class="form-control" placeholder="e.g. jdoe" required>
                </div>

                <div class="form-group">
                    <label for="nu_pass" class="form-label required">Initial Password</label>
                    <input type="password" id="nu_pass" name="password" class="form-control" placeholder="Minimum 6 characters" required>
                </div>

                <div class="form-group">
                    <label for="nu_full" class="form-label required">Full Name</label>
                    <input type="text" id="nu_full" name="full_name" class="form-control" placeholder="e.g. John Doe" required>
                </div>

                <div class="form-group">
                    <label for="nu_role" class="form-label required">Role</label>
                    <select id="nu_role" name="role" class="form-select" required>
                        <option value="user">User (Standard Access)</option>
                        <option value="admin">Administrator (Full Access)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="nu_dept" class="form-label required">Department</label>
                    <input type="text" id="nu_dept" name="department" class="form-control" placeholder="e.g. Network Operations" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('addUserModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Create Account</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Reset Password -->
<div class="modal-overlay" id="resetPasswordModal" style="display: none;">
    <div class="modal-card modal-sm">
        <div class="modal-header">
            <h3 class="modal-title">Reset Password</h3>
            <button type="button" class="modal-close" onclick="closeModal('resetPasswordModal')">&times;</button>
        </div>
        <form method="POST" action="users.asp">
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" id="reset_user_id" name="user_id">
            <div class="modal-body">
                <p style="margin-bottom: 12px; font-size: 13px;">Reset password for: <strong id="reset_username_disp"></strong></p>
                <div class="form-group">
                    <label for="reset_new_pass" class="form-label required">New Password</label>
                    <input type="password" id="reset_new_pass" name="new_password" class="form-control" placeholder="Enter new password" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('resetPasswordModal')">Cancel</button>
                <button type="submit" class="btn btn-danger">Update Password</button>
            </div>
        </form>
    </div>
</div>

<script>
function openResetModal(userId, username) {
    document.getElementById('reset_user_id').value = userId;
    document.getElementById('reset_username_disp').textContent = username;
    document.getElementById('reset_new_pass').value = '';
    openModal('resetPasswordModal');
}
</script>

<%
rsUsers.Close
Set rsUsers = Nothing
CloseDbConnection conn
%>

<!--#include file="includes/footer.asp"-->
