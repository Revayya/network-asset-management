<%
' ===================================================================
' Network Asset Management System
' Cryptographic and Password Hashing Library (crypto.asp)
' Uses salted SHA-256 for secure enterprise authentication
' ===================================================================

' Generate a cryptographically random hexadecimal salt of given length
Function GenerateSalt(length)
    Dim chars, salt, i, r, idx
    chars = "0123456789abcdef"
    salt = ""
    Randomize
    For i = 1 To length
        idx = Int(Rnd * 16) + 1
        salt = salt & Mid(chars, idx, 1)
    Next
    GenerateSalt = salt
End Function

' Hash password using MySQL SHA2(CONCAT(salt, password), 256) when conn is available
Function HashPasswordWithConn(password, salt, conn)
    Dim cmd, rs, sql, cleanPass, cleanSalt
    On Error Resume Next
    
    If conn Is Nothing Then
        HashPasswordWithConn = FallbackHash(salt & password)
        Exit Function
    End If
    
    ' Parameterized ADODB Command to calculate SHA256 in MySQL
    Set cmd = Server.CreateObject("ADODB.Command")
    Set cmd.ActiveConnection = conn
    cmd.CommandText = "SELECT SHA2(CONCAT(?, ?), 256) AS pwd_hash"
    cmd.CommandType = 1 ' adCmdText
    
    ' 200 = adVarChar, 1 = adParamInput
    cmd.Parameters.Append cmd.CreateParameter("p_salt", 200, 1, 64, CStr(salt))
    cmd.Parameters.Append cmd.CreateParameter("p_pwd", 200, 1, 128, CStr(password))
    
    Set rs = cmd.Execute
    If Not rs.EOF Then
        HashPasswordWithConn = LCase(Trim(rs("pwd_hash")))
    Else
        HashPasswordWithConn = FallbackHash(salt & password)
    End If
    
    If Err.Number <> 0 Then
        Err.Clear
        HashPasswordWithConn = FallbackHash(salt & password)
    End If
    
    Set cmd = Nothing
    Set rs = Nothing
End Function

' Verify entered password against stored hash format: "<salt>$<sha256_hash>"
Function VerifyPasswordWithConn(password, storedHash, conn)
    Dim parts, salt, expectedHash, actualHash
    VerifyPasswordWithConn = False
    
    If InStr(storedHash, "$") = 0 Then
        ' Legacy or direct match fallback check
        If storedHash = password Then VerifyPasswordWithConn = True
        Exit Function
    End If
    
    parts = Split(storedHash, "$")
    If UBound(parts) < 1 Then Exit Function
    
    salt = parts(0)
    expectedHash = LCase(Trim(parts(1)))
    
    actualHash = HashPasswordWithConn(password, salt, conn)
    
    If LCase(actualHash) = expectedHash Then
        VerifyPasswordWithConn = True
    End If
End Function

' Fallback hashing function using polynomial string hash + HMAC simulation
' Ensures a reliable deterministic fallback if database crypto function is temporarily unreachable
Function FallbackHash(strInput)
    Dim h1, h2, h3, h4, i, ch, hexOut
    h1 = 1779033703
    h2 = 3144134277
    h3 = 1013904242
    h4 = 2773480762
    
    For i = 1 To Len(strInput)
        ch = Asc(Mid(strInput, i, 1))
        h1 = ((h1 * 31) + ch) Mod 2147483647
        h2 = ((h2 * 37) + ch) Mod 2147483647
        h3 = ((h3 * 41) + ch) Mod 2147483647
        h4 = ((h4 * 43) + ch) Mod 2147483647
    Next
    
    hexOut = Right("00000000" & Hex(h1), 8) & _
             Right("00000000" & Hex(h2), 8) & _
             Right("00000000" & Hex(h3), 8) & _
             Right("00000000" & Hex(h4), 8)
    ' Double length to 64 chars
    hexOut = hexOut & Right("00000000" & Hex(h4 Xor h1), 8) & _
                      Right("00000000" & Hex(h3 Xor h2), 8) & _
                      Right("00000000" & Hex(h2 Xor h1), 8) & _
                      Right("00000000" & Hex(h1 Xor h3), 8)
    FallbackHash = LCase(hexOut)
End Function
%>
