# Network Asset Management System
## Complete Installation and Deployment Guide

This document provides a step-by-step walkthrough for deploying the **Network Asset Management System** on a Windows Server or Windows PC running Microsoft Internet Information Services (IIS) and MySQL.

---

## 1. Prerequisites and System Requirements

### Hardware Requirements
- **Processor:** 1.8 GHz 64-bit multi-core CPU or better
- **RAM:** 4 GB minimum (8 GB recommended for enterprise production)
- **Storage:** 500 MB free disk space for application files and database growth

### Software Prerequisites
- **Operating System:** Windows Server 2012 / 2016 / 2019 / 2022 or Windows 10 / 11 (Pro, Enterprise, or Education)
- **Web Server:** Microsoft Internet Information Services (IIS 7.5, 8.5, 10.0+) with **ASP (Classic ASP)** role service enabled
- **Database Server:** MySQL Server 5.5, 5.6, 5.7, 8.0+ or MariaDB 10.3+
- **ODBC Driver:** MySQL Connector/ODBC 5.1 (or MySQL Connector/ODBC 8.0) 64-bit
- **Database Management Tool:** SQLyog Community Edition (or MySQL Workbench / CLI)

---

## 2. MySQL Installation & Service Configuration

1. Download and run the **MySQL Community Server Installer** (or MariaDB).
2. Choose **Server only** or **Typical** installation.
3. In the Configuration Wizard:
   - **Config Type:** Server Computer
   - **Port:** `3306`
   - **Authentication Method:** Use Legacy Authentication or Strong Password Encryption (ensure user authentication plugin is compatible with ODBC, e.g., `mysql_native_password` or `caching_sha2_password`).
4. Set a strong password for the `root` administrative account.
5. Ensure the MySQL Windows service is set to **Automatic** startup and is currently running.
   ```powershell
   Get-Service -Name *mysql*
   ```

---

## 3. MySQL ODBC Driver Setup

The system connects via ADODB using the MySQL ODBC driver.

1. Install **MySQL Connector/ODBC 5.1 (winx64)** (or MySQL Connector/ODBC 8.0 winx64).
2. To verify installed ODBC drivers on your Windows machine, open PowerShell and run:
   ```powershell
   Get-OdbcDriver -Name "*MySQL*"
   ```
3. You should see `MySQL ODBC 5.1 Driver` or `MySQL ODBC 8.0 Unicode Driver` listed under Platform `64-bit`.
4. *Architecture Matching Note:* The IIS Application Pool architecture (32-bit vs. 64-bit) must match your ODBC driver architecture. Since standard modern IIS App Pools run in 64-bit mode by default, ensure the **64-bit** ODBC driver is installed.

---

## 4. SQLyog Community Edition Database Setup

1. Launch **SQLyog Community Edition**.
2. Click **New Connection**:
   - **MySQL Host Address:** `127.0.0.1` (or your MySQL Server IP)
   - **Username:** `root`
   - **Password:** `<Your_MySQL_Password>`
   - **Port:** `3306`
3. Click **Connect**.
4. Create the database:
   - In SQLyog, press `Ctrl + Shift + Q` to open a new query tab.
   - Run:
     ```sql
     CREATE DATABASE network_asset_management
         DEFAULT CHARACTER SET utf8mb4
         DEFAULT COLLATE utf8mb4_unicode_ci;
     ```
5. Import Database Schema and Data:
   - In SQLyog, go to **Database &rarr; Run SQL Script...** (or press `Ctrl + Shift + S`).
   - Select the file `database/setup_all.sql` located in this project.
   - Click **Execute**.
   - SQLyog will create all tables, indexes, constraints, application settings, and initial seed data.
6. Verify the imported tables in SQLyog Object Browser:
   - `users`
   - `assets`
   - `asset_usage`
   - `asset_returns`
   - `audit_logs`
   - `app_settings`

---

## 5. Configuring Classic ASP Database Connection

1. In the project root, open `config/config.asp` in your text editor (such as Notepad or VS Code).
2. Configure the database credentials to match your MySQL server:
   ```vbscript
   Const DB_SERVER   = "localhost"
   Const DB_PORT     = "3306"
   Const DB_NAME     = "network_asset_management"
   Const DB_USER     = "root"
   Const DB_PASSWORD = "YourSecurePasswordHere"
   Const DB_DRIVER   = "MySQL ODBC 5.1 Driver"
   ```
   *Note:* The system automatically attempts fallback drivers (`MySQL ODBC 8.0 Unicode Driver`, `MySQL ODBC 8.0 ANSI Driver`, etc.) if `MySQL ODBC 5.1 Driver` is not found.

---

## 6. Enabling Classic ASP in IIS

By default on modern Windows, the Classic ASP feature of IIS is not activated. Follow these steps to enable it:

### On Windows 10 / 11:
1. Open **Control Panel** &rarr; **Programs and Features** &rarr; **Turn Windows features on or off**.
2. Expand **Internet Information Services**.
3. Expand **World Wide Web Services** &rarr; **Application Development Features**.
4. Check **ASP** (Classic ASP) and **ISAPI Extensions**.
5. Click **OK** and wait for Windows to apply changes.

### On Windows Server (2016 / 2019 / 2022):
1. Open **Server Manager** &rarr; **Manage** &rarr; **Add Roles and Features**.
2. Under **Server Roles**, expand **Web Server (IIS)** &rarr; **Web Server** &rarr; **Application Development**.
3. Check **ASP** and complete the wizard.

### Enable Parent Paths (Recommended):
Open an administrative command prompt or PowerShell and execute:
```cmd
%windir%\system32\inetsrv\appcmd.exe set config /section:asp /enableParentPaths:True
```

---

## 7. Creating IIS Website / Virtual Application

1. Open **IIS Manager** (`inetmgr`).
2. In the Connections pane, expand your server node, then right-click **Sites** &rarr; **Add Website...**
   - **Site name:** `NetworkAssetManagement`
   - **Physical path:** `C:\inetpub\wwwroot\NetworkAssetManagement` (or your project path: `C:\Users\hp\.gemini\antigravity\scratch\NetworkAssetManagement`)
   - **Binding Type:** `http`
   - **IP address:** `All Unassigned`
   - **Port:** `8080` (or `80`)
3. Click **OK**.
4. Configure Application Pool:
   - In IIS Manager, click **Application Pools**.
   - Select the pool for `NetworkAssetManagement`.
   - Click **Advanced Settings...**:
     - **.NET CLR Version:** `No Managed Code`
     - **Enable 32-Bit Applications:** `False` (for 64-bit ODBC) or `True` (only if you installed a 32-bit ODBC driver).
     - **Identity:** `ApplicationPoolIdentity` (or `NetworkService`).
5. Configure Directory Permissions:
   - Ensure the application folder has **Read & Execute** permissions for `IIS_IUSRS` and `IUSR`.
   ```powershell
   icacls "C:\Users\hp\.gemini\antigravity\scratch\NetworkAssetManagement" /grant "IIS_IUSRS:(OI)(CI)RX"
   icacls "C:\Users\hp\.gemini\antigravity\scratch\NetworkAssetManagement" /grant "IUSR:(OI)(CI)RX"
   ```

---

## 8. Testing Database Connectivity & Login

1. Open your web browser and navigate to:
   ```
   http://localhost:8080/test_db.asp
   ```
2. You should see a green success banner:
   - `✓ Database Connection Successful!`
   - `✓ Verified Tables: users, assets, asset_usage, audit_logs, app_settings, asset_returns`
3. Now navigate to the application login:
   ```
   http://localhost:8080/login.asp
   ```
4. Test login using the initial evaluation accounts:
   - **Administrator Account:**
     - Username: `admin`
     - Password: `Admin@12345`
   - **Standard User Account:**
     - Username: `user`
     - Password: `User@12345`

---

## 9. Intranet Deployment for Organization Users

To make the application accessible across your company local network:

1. In Windows Defender Firewall, open incoming port `8080` (or `80`):
   ```powershell
   New-NetFirewallRule -DisplayName "IIS NetAsset Core Intranet" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow
   ```
2. Find the server's local IPv4 address:
   ```powershell
   ipconfig
   ```
3. Intranet users on the same corporate LAN or Wi-Fi can now access the portal via:
   ```
   http://<SERVER_IP>:8080/
   ```
   *(e.g., `http://192.168.1.100:8080/`)*
4. Configure an internal DNS record (e.g., `http://netasset.corporate.local`) pointing to the server IP for seamless company-wide access.
