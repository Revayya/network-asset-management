<%
' Determine active navigation item
Dim currentPage
currentPage = LCase(Request.ServerVariables("SCRIPT_NAME"))
If InStr(currentPage, "/") > 0 Then
    currentPage = Mid(currentPage, InStrRev(currentPage, "/") + 1)
End If
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<%= GetCsrfToken() %>">
    <title><%= HtmlEncode(pageTitle) %> - Network Asset Management</title>
    
    <!-- Enterprise Dashboard Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body class="app-body">
    <div class="app-container">
        <!-- Sidebar Navigation -->
        <aside class="app-sidebar" id="appSidebar">
            <div class="sidebar-header">
                <div class="brand-logo">
                    <svg class="brand-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
                        <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
                        <line x1="6" y1="6" x2="6.01" y2="6"></line>
                        <line x1="6" y1="18" x2="6.01" y2="18"></line>
                        <line x1="10" y1="10" x2="14" y2="14"></line>
                    </svg>
                    <div class="brand-text">
                        <span class="brand-title">NetAsset</span>
                        <span class="brand-subtitle">Operations Core</span>
                    </div>
                </div>
                <button type="button" class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Close menu">&times;</button>
            </div>

            <!-- Current User Badge -->
            <div class="sidebar-user-card">
                <div class="user-avatar">
                    <%= UCase(Left(GetAuthFullName(), 1)) %>
                </div>
                <div class="user-meta">
                    <div class="user-name"><%= HtmlEncode(GetAuthFullName()) %></div>
                    <div class="user-role-badge badge-<%= GetAuthRole() %>">
                        <%= UCase(GetAuthRole()) %>
                    </div>
                </div>
            </div>

            <nav class="sidebar-nav">
                <div class="nav-section-label">General</div>
                <a href="dashboard.asp" class="nav-item <%= IIf(currentPage = "dashboard.asp", "active", "") %>">
                    <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                    <span>Dashboard</span>
                </a>
                <a href="assets.asp" class="nav-item <%= IIf(currentPage = "assets.asp", "active", "") %>">
                    <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    <span>Asset Management</span>
                </a>
                <a href="asset_usage.asp" class="nav-item <%= IIf(currentPage = "asset_usage.asp", "active", "") %>">
                    <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    <span>Asset Usage History</span>
                </a>

                <% If IsAdmin() Then %>
                <div class="nav-section-label">Administration</div>
                <a href="reports.asp" class="nav-item <%= IIf(currentPage = "reports.asp", "active", "") %>">
                    <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                    <span>Reports & Analytics</span>
                </a>
                <a href="users.asp" class="nav-item <%= IIf(currentPage = "users.asp", "active", "") %>">
                    <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                    <span>User Management</span>
                </a>
                <a href="audit_logs.asp" class="nav-item <%= IIf(currentPage = "audit_logs.asp", "active", "") %>">
                    <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                    <span>Audit Logs</span>
                </a>
                <a href="settings.asp" class="nav-item <%= IIf(currentPage = "settings.asp", "active", "") %>">
                    <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                    <span>System Settings</span>
                </a>
                <% End If %>

                <div class="nav-section-label">Account</div>
                <a href="logout.asp" class="nav-item text-danger">
                    <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                    <span>Sign Out</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <span class="server-status-dot online"></span>
                <span>IIS ADODB / MySQL</span>
            </div>
        </aside>

        <!-- Main Wrapper -->
        <div class="app-main">
            <!-- Top Navbar -->
            <header class="app-topbar">
                <div class="topbar-left">
                    <button type="button" class="sidebar-toggle-btn" id="sidebarToggleBtn" aria-label="Toggle sidebar">
                        <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                    </button>
                    <div class="topbar-breadcrumb">
                        <span class="bc-app">Network Asset Management</span>
                        <span class="bc-sep">/</span>
                        <span class="bc-page"><%= HtmlEncode(pageTitle) %></span>
                    </div>
                </div>
                <div class="topbar-right">
                    <div class="topbar-org-pill">
                        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><path d="M3 21h18"></path><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"></path></svg>
                        <span><%= HtmlEncode(GetAuthDepartment()) %></span>
                    </div>
                    <div class="topbar-profile">
                        <span class="profile-name"><%= HtmlEncode(GetAuthUsername()) %></span>
                        <a href="logout.asp" class="btn btn-sm btn-outline-danger" title="Logout">
                            <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                            <span>Logout</span>
                        </a>
                    </div>
                </div>
            </header>

            <!-- Main Content Area -->
            <main class="content-container">
<%
' Helper function for inline conditional
Function IIf(cond, trueVal, falseVal)
    If cond Then IIf = trueVal Else IIf = falseVal
End Function
%>
