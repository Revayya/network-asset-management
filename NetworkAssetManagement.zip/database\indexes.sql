-- ==========================================================
-- Network Asset Management System
-- Indexes Optimization Script
-- Target Database: MySQL 5.5+ / 8.0+ / MariaDB
-- Compatibility: SQLyog Community Edition
-- ==========================================================

USE `network_asset_management`;

-- Optimize user lookups and role queries
CREATE INDEX IF NOT EXISTS `idx_users_username_active` ON `users` (`username`, `is_active`);

-- Optimize asset search & filtering by location, UOM, and availability
CREATE INDEX IF NOT EXISTS `idx_assets_search_composite` ON `assets` (`asset_number`, `asset_name`, `asset_location`);
CREATE INDEX IF NOT EXISTS `idx_assets_uom_available` ON `assets` (`uom`, `asset_available`);
CREATE INDEX IF NOT EXISTS `idx_assets_filter_location` ON `assets` (`asset_location`);
CREATE INDEX IF NOT EXISTS `idx_assets_date_range` ON `assets` (`created_at`);

-- Optimize usage report queries and search filters
CREATE INDEX IF NOT EXISTS `idx_usage_asset_datetime` ON `asset_usage` (`asset_id`, `usage_datetime`);
CREATE INDEX IF NOT EXISTS `idx_usage_dept_datetime` ON `asset_usage` (`department`, `usage_datetime`);
CREATE INDEX IF NOT EXISTS `idx_usage_user_datetime` ON `asset_usage` (`used_by`, `usage_datetime`);
CREATE INDEX IF NOT EXISTS `idx_usage_composite_report` ON `asset_usage` (`usage_datetime`, `department`, `asset_id`);

-- Optimize audit log queries by date and entity
CREATE INDEX IF NOT EXISTS `idx_audit_entity_lookup` ON `audit_logs` (`entity_type`, `entity_id`);
CREATE INDEX IF NOT EXISTS `idx_audit_user_action_time` ON `audit_logs` (`user_id`, `action`, `created_at`);
