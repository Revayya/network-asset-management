<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireAdmin()
Dim pageTitle
pageTitle = "System Settings"

' Gather system diagnostics
Dim conn, dbStatus, dbDriverUsed, dbVersion, errDetail
dbStatus = "Offline"
dbDriverUsed = "None"
dbVersion = "Unknown"
errDetail = ""

Set conn = GetDbConnection()
If Not conn Is Nothing Then
    dbStatus = "Connected (Healthy)"
    On Error Resume Next
    Dim rsVer
    Set rsVer = conn.Execute("SELECT VERSION() AS ver")
    If Not rsVer.EOF Then
        dbVersion = rsVer("ver")
    End If
    rsVer.Close
    Set rsVer = Nothing
    CloseDbConnection conn
Else
    dbStatus = "Disconnected"
    errDetail = g_LastDbError
End If
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Administrative Settings & Diagnostics</h1>
        <p>System configuration, database connectivity status, and server runtime parameters.</p>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 24px; margin-bottom: 24px;">
    <!-- System Diagnostics Card -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>
                <span>Database Connectivity & Engine</span>
            </h3>
        </div>
        <div class="card-body">
            <table class="data-table" style="font-size: 13px;">
                <tbody>
                    <tr>
                        <td style="width: 180px;"><strong>Status:</strong></td>
                        <td>
                            <% If dbStatus = "Connected (Healthy)" Then %>
                                <span class="badge badge-stock-in">&#10004; <%= dbStatus %></span>
                            <% Else %>
                                <span class="badge badge-stock-out">&#10008; <%= dbStatus %></span>
                            <% End If %>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Database Server:</strong></td>
                        <td class="font-mono"><%= HtmlEncode(DB_SERVER) %>:<%= HtmlEncode(DB_PORT) %></td>
                    </tr>
                    <tr>
                        <td><strong>Database Name:</strong></td>
                        <td class="font-mono"><%= HtmlEncode(DB_NAME) %></td>
                    </tr>
                    <tr>
                        <td><strong>Configured Driver:</strong></td>
                        <td class="font-mono"><%= HtmlEncode(DB_DRIVER) %></td>
                    </tr>
                    <tr>
                        <td><strong>MySQL Engine Version:</strong></td>
                        <td class="font-mono"><%= HtmlEncode(dbVersion) %></td>
                    </tr>
                    <% If errDetail <> "" Then %>
                    <tr>
                        <td><strong>Last Connection Error:</strong></td>
                        <td class="text-danger" style="font-size: 12px;"><%= HtmlEncode(errDetail) %></td>
                    </tr>
                    <% End If %>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Application Environment Card -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                <span>Runtime Environment</span>
            </h3>
        </div>
        <div class="card-body">
            <table class="data-table" style="font-size: 13px;">
                <tbody>
                    <tr>
                        <td style="width: 180px;"><strong>Application Name:</strong></td>
                        <td><%= HtmlEncode(APP_NAME) %></td>
                    </tr>
                    <tr>
                        <td><strong>Version:</strong></td>
                        <td class="font-mono"><%= HtmlEncode(APP_VERSION) %></td>
                    </tr>
                    <tr>
                        <td><strong>Session Inactivity Timeout:</strong></td>
                        <td><%= SESSION_TIMEOUT_MINS %> minutes</td>
                    </tr>
                    <tr>
                        <td><strong>Server Platform:</strong></td>
                        <td><%= HtmlEncode(Request.ServerVariables("SERVER_SOFTWARE")) %></td>
                    </tr>
                    <tr>
                        <td><strong>Server Local Time:</strong></td>
                        <td class="font-mono"><%= FormatDisplayDate(Now()) %></td>
                    </tr>
                    <tr>
                        <td><strong>Current User Session:</strong></td>
                        <td><%= HtmlEncode(GetAuthFullName()) %> (<strong class="badge badge-admin"><%= UCase(GetAuthRole()) %></strong>)</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Test Connection Action Card -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Database Diagnostic Tool</h3>
    </div>
    <div class="card-body">
        <p style="margin-bottom: 16px; font-size: 13px; color: var(--text-muted);">
            Run an on-demand database connection verification test using the active ODBC driver configuration.
        </p>
        <button type="button" class="btn btn-primary" onclick="window.location.reload()">
            <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><path d="M23 4v6h-6"></path><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
            <span>Re-test Database Connection</span>
        </button>
        <a href="test_db.asp" target="_blank" class="btn btn-secondary" style="margin-left: 8px;">
            <span>Open Standalone Diagnostic Page &rarr;</span>
        </a>
    </div>
</div>

<!--#include file="includes/footer.asp"-->
