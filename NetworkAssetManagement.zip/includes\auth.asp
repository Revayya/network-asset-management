<%
' ===================================================================
' Network Asset Management System
' Session Authentication Management (auth.asp)
' ===================================================================

Function IsUserLoggedIn()
    IsUserLoggedIn = False
    If Session("AUTH_USER_ID") <> "" And Not IsNull(Session("AUTH_USER_ID")) Then
        ' Check inactivity timeout
        Dim timeoutMins, lastAct, diffMins
        timeoutMins = 30
        On Error Resume Next
        If SESSION_TIMEOUT_MINS > 0 Then timeoutMins = SESSION_TIMEOUT_MINS
        On Error GoTo 0
        
        lastAct = Session("AUTH_LAST_ACTIVITY")
        If IsDate(lastAct) Then
            diffMins = DateDiff("n", CDate(lastAct), Now())
            If diffMins >= timeoutMins Then
                PerformLogout()
                Exit Function
            End If
        End If
        
        Session("AUTH_LAST_ACTIVITY") = Now()
        IsUserLoggedIn = True
    End If
End Function

Sub PerformLogin(userId, username, fullName, role, department, conn)
    Session("AUTH_USER_ID") = CLng(userId)
    Session("AUTH_USERNAME") = CStr(username)
    Session("AUTH_FULL_NAME") = CStr(fullName)
    Session("AUTH_ROLE") = LCase(CStr(role))
    Session("AUTH_DEPARTMENT") = CStr(department)
    Session("AUTH_LAST_ACTIVITY") = Now()
    Session.Timeout = 30
    
    ' Update last_login_at in database
    On Error Resume Next
    If Not conn Is Nothing Then
        Dim cmd
        Set cmd = Server.CreateObject("ADODB.Command")
        Set cmd.ActiveConnection = conn
        cmd.CommandText = "UPDATE users SET last_login_at = NOW() WHERE id = ?"
        cmd.CommandType = 1
        cmd.Parameters.Append cmd.CreateParameter("p_id", 3, 1, , CLng(userId))
        cmd.Execute
        Set cmd = Nothing
    End If
    On Error GoTo 0
End Sub

Sub PerformLogout()
    Session("AUTH_USER_ID") = ""
    Session("AUTH_USERNAME") = ""
    Session("AUTH_FULL_NAME") = ""
    Session("AUTH_ROLE") = ""
    Session("AUTH_DEPARTMENT") = ""
    Session("AUTH_LAST_ACTIVITY") = ""
    Session("CSRF_TOKEN") = ""
    Session.Abandon
End Sub

Function GetAuthUserId()
    If Session("AUTH_USER_ID") <> "" Then
        GetAuthUserId = CLng(Session("AUTH_USER_ID"))
    Else
        GetAuthUserId = 0
    End If
End Function

Function GetAuthUsername()
    GetAuthUsername = CStr(Session("AUTH_USERNAME"))
End Function

Function GetAuthFullName()
    GetAuthFullName = CStr(Session("AUTH_FULL_NAME"))
End Function

Function GetAuthRole()
    GetAuthRole = LCase(CStr(Session("AUTH_ROLE")))
End Function

Function GetAuthDepartment()
    GetAuthDepartment = CStr(Session("AUTH_DEPARTMENT"))
End Function
%>
