<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireLogin()
Dim pageTitle
pageTitle = "Asset Usage History"

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error: " & g_LastDbError
    Response.End
End If

' Filters
Dim qAsset, qUser, qDept, qLoc, qUom, qFromDate, qToDate
qAsset    = CleanInput(Request.QueryString("asset_query"))
qUser     = CleanInput(Request.QueryString("used_by"))
qDept     = CleanInput(Request.QueryString("department"))
qLoc      = CleanInput(Request.QueryString("location"))
qUom      = UCase(CleanInput(Request.QueryString("uom")))
qFromDate = CleanInput(Request.QueryString("from_date"))
qToDate   = CleanInput(Request.QueryString("to_date"))

' Pagination
Dim page, pageSize, offset
page = CLng(Request.QueryString("page"))
If page < 1 Then page = 1

pageSize = CLng(Request.QueryString("page_size"))
If pageSize < 1 Or pageSize > 100 Then pageSize = 10

offset = (page - 1) * pageSize

Dim whereClauses
whereClauses = " WHERE 1=1 "

If qAsset <> "" Then
    whereClauses = whereClauses & " AND (a.asset_number LIKE '%" & EscapeSql(qAsset) & "%' OR a.asset_name LIKE '%" & EscapeSql(qAsset) & "%') "
End If

If qUser <> "" Then
    whereClauses = whereClauses & " AND u.used_by LIKE '%" & EscapeSql(qUser) & "%' "
End If

If qDept <> "" Then
    whereClauses = whereClauses & " AND u.department = '" & EscapeSql(qDept) & "' "
End If

If qLoc <> "" Then
    whereClauses = whereClauses & " AND a.asset_location = '" & EscapeSql(qLoc) & "' "
End If

If qUom = "NO" Or qUom = "MTR" Then
    whereClauses = whereClauses & " AND u.uom = '" & EscapeSql(qUom) & "' "
End If

If IsValidDateString(qFromDate) Then
    whereClauses = whereClauses & " AND u.usage_datetime >= '" & EscapeSql(qFromDate) & " 00:00:00' "
End If

If IsValidDateString(qToDate) Then
    whereClauses = whereClauses & " AND u.usage_datetime <= '" & EscapeSql(qToDate) & " 23:59:59' "
End If

' Count
Dim totalRecords, totalPages, rsCount
totalRecords = 0
Set rsCount = conn.Execute("SELECT COUNT(*) AS c FROM asset_usage u JOIN assets a ON u.asset_id = a.id " & whereClauses)
If Not rsCount.EOF Then totalRecords = CLng(rsCount("c"))
rsCount.Close
Set rsCount = Nothing

If totalRecords > 0 Then
    totalPages = Int((totalRecords + pageSize - 1) / pageSize)
Else
    totalPages = 1
End If

' Fetch paginated rows
Dim rsUsage
Set rsUsage = conn.Execute("SELECT u.id, u.asset_id, a.asset_number, a.asset_name, a.asset_location, " & _
                          "a.asset_quantity, a.asset_available, u.quantity_used, u.uom, " & _
                          "u.used_by, u.department, u.short_description, u.usage_datetime " & _
                          "FROM asset_usage u JOIN assets a ON u.asset_id = a.id " & _
                          whereClauses & " ORDER BY u.id DESC LIMIT " & offset & ", " & pageSize)

Function BuildUsageQuery(targetPage)
    BuildUsageQuery = "asset_usage.asp?page=" & targetPage & _
                      "&page_size=" & pageSize & _
                      "&asset_query=" & Server.URLEncode(qAsset) & _
                      "&used_by=" & Server.URLEncode(qUser) & _
                      "&department=" & Server.URLEncode(qDept) & _
                      "&location=" & Server.URLEncode(qLoc) & _
                      "&uom=" & Server.URLEncode(qUom) & _
                      "&from_date=" & Server.URLEncode(qFromDate) & _
                      "&to_date=" & Server.URLEncode(qToDate)
End Function
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Asset Usage History & Allocations</h1>
        <p>Complete 13-column operational ledger recording every asset issuance and departmental assignment.</p>
    </div>
    <div class="page-header-actions">
        <a href="asset_issue.asp" class="btn btn-primary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>
            <span>Issue / Pick Asset</span>
        </a>

        <a href="export_csv.asp?report_type=usage_history&asset_query=<%= Server.URLEncode(qAsset) %>&used_by=<%= Server.URLEncode(qUser) %>&department=<%= Server.URLEncode(qDept) %>&location=<%= Server.URLEncode(qLoc) %>&uom=<%= Server.URLEncode(qUom) %>&from_date=<%= Server.URLEncode(qFromDate) %>&to_date=<%= Server.URLEncode(qToDate) %>" class="btn btn-secondary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
            <span>Export CSV</span>
        </a>
    </div>
</div>

<% If Request.QueryString("msg") = "issued" Then %>
    <div style="background-color: var(--success-light); color: var(--success); padding: 12px 18px; border-radius: var(--radius-md); margin-bottom: 20px; font-weight: 500;">
        &#10004; Asset issued successfully! Stock deducted and recorded in usage history.
    </div>
<% End If %>

<!-- Filters Form -->
<form method="GET" action="asset_usage.asp" class="filter-card">
    <div class="filter-grid">
        <div class="form-group" style="margin-bottom: 0;">
            <label for="fu_asset" class="form-label" style="font-size: 11px;">SEARCH ASSET</label>
            <input type="text" id="fu_asset" name="asset_query" class="form-control" placeholder="Number or Name..." value="<%= HtmlEncode(qAsset) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fu_user" class="form-label" style="font-size: 11px;">USED BY (EMPLOYEE)</label>
            <input type="text" id="fu_user" name="used_by" class="form-control" placeholder="Search person..." value="<%= HtmlEncode(qUser) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fu_dept" class="form-label" style="font-size: 11px;">DEPARTMENT</label>
            <input type="text" id="fu_dept" name="department" class="form-control" placeholder="Search department..." value="<%= HtmlEncode(qDept) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fu_loc" class="form-label" style="font-size: 11px;">LOCATION</label>
            <input type="text" id="fu_loc" name="location" class="form-control" placeholder="Location..." value="<%= HtmlEncode(qLoc) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fu_uom" class="form-label" style="font-size: 11px;">UOM</label>
            <select id="fu_uom" name="uom" class="form-select">
                <option value="">All Units</option>
                <option value="NO" <%= IIf(qUom = "NO", "selected", "") %>>NO</option>
                <option value="MTR" <%= IIf(qUom = "MTR", "selected", "") %>>MTR</option>
            </select>
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fu_from" class="form-label" style="font-size: 11px;">FROM DATE</label>
            <input type="date" id="fu_from" name="from_date" class="form-control" value="<%= HtmlEncode(qFromDate) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fu_to" class="form-label" style="font-size: 11px;">TO DATE</label>
            <input type="date" id="fu_to" name="to_date" class="form-control" value="<%= HtmlEncode(qToDate) %>">
        </div>

        <div class="filter-actions" style="margin-bottom: 0;">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="asset_usage.asp" class="btn btn-secondary">Reset</a>
            <select name="page_size" class="form-select" style="width: 80px;" onchange="this.form.submit()">
                <option value="10" <%= IIf(pageSize = 10, "selected", "") %>>10</option>
                <option value="25" <%= IIf(pageSize = 25, "selected", "") %>>25</option>
                <option value="50" <%= IIf(pageSize = 50, "selected", "") %>>50</option>
            </select>
        </div>
    </div>
</form>

<!-- Usage Table (13 Columns as Specified) -->
<div class="card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>TX ID</th>
                    <th>Asset ID</th>
                    <th>Asset #</th>
                    <th>Asset Name</th>
                    <th>Location</th>
                    <th>Total Qty</th>
                    <th>Available</th>
                    <th>Quantity Used</th>
                    <th>UOM</th>
                    <th>Used By</th>
                    <th>Department</th>
                    <th>Usage Datetime</th>
                    <th>Short Description</th>
                </tr>
            </thead>
            <tbody>
                <% If rsUsage Is Nothing Or rsUsage.EOF Then %>
                    <tr><td colspan="13" class="empty-state"><p>No usage records match your search criteria.</p></td></tr>
                <% Else %>
                    <% Do While Not rsUsage.EOF %>
                    <tr>
                        <td class="font-mono text-muted">#TX-<%= rsUsage("id") %></td>
                        <td class="font-mono text-muted">#<%= rsUsage("asset_id") %></td>
                        <td><strong class="font-mono text-primary"><a href="asset_details.asp?id=<%= rsUsage("asset_id") %>"><%= HtmlEncode(rsUsage("asset_number")) %></a></strong></td>
                        <td><strong><%= HtmlEncode(rsUsage("asset_name")) %></strong></td>
                        <td><span class="text-muted"><%= HtmlEncode(rsUsage("asset_location")) %></span></td>
                        <td><%= FormatDisplayQuantity(rsUsage("asset_quantity"), rsUsage("uom")) %></td>
                        <td class="text-success font-bold"><%= FormatDisplayQuantity(rsUsage("asset_available"), rsUsage("uom")) %></td>
                        <td class="text-danger font-bold" style="font-size: 14px;">-<%= FormatDisplayQuantity(rsUsage("quantity_used"), rsUsage("uom")) %></td>
                        <td>
                            <span class="badge <%= IIf(rsUsage("uom") = "MTR", "badge-uom-mtr", "badge-uom-no") %>"><%= HtmlEncode(rsUsage("uom")) %></span>
                        </td>
                        <td><strong><%= HtmlEncode(rsUsage("used_by")) %></strong></td>
                        <td><span class="badge" style="background:#f1f5f9; color:#334155;"><%= HtmlEncode(rsUsage("department")) %></span></td>
                        <td class="text-muted font-mono" style="font-size: 11px;"><%= FormatDisplayDate(rsUsage("usage_datetime")) %></td>
                        <td title="<%= HtmlEncode(rsUsage("short_description")) %>">
                            <div style="max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                <%= HtmlEncode(rsUsage("short_description")) %>
                            </div>
                        </td>
                    </tr>
                    <% rsUsage.MoveNext %>
                    <% Loop %>
                <% End If %>
            </tbody>
        </table>
    </div>

    <!-- Server-side Pagination -->
    <div class="pagination-toolbar">
        <div class="pagination-info">
            Showing <strong><%= IIf(totalRecords > 0, offset + 1, 0) %></strong> to <strong><%= IIf(offset + pageSize > totalRecords, totalRecords, offset + pageSize) %></strong> of <strong><%= totalRecords %></strong> transactions
        </div>
        <div class="pagination-controls">
            <% If page > 1 Then %>
                <a href="<%= BuildUsageQuery(page - 1) %>" class="page-btn">&laquo;</a>
            <% Else %>
                <button class="page-btn" disabled>&laquo;</button>
            <% End If %>

            <% For p = 1 To totalPages %>
                <% If p = page Then %>
                    <span class="page-btn active"><%= p %></span>
                <% ElseIf p <= 5 Or p = totalPages Or (p >= page - 2 And p <= page + 2) Then %>
                    <a href="<%= BuildUsageQuery(p) %>" class="page-btn"><%= p %></a>
                <% End If %>
            <% Next %>

            <% If page < totalPages Then %>
                <a href="<%= BuildUsageQuery(page + 1) %>" class="page-btn">&raquo;</a>
            <% Else %>
                <button class="page-btn" disabled>&raquo;</button>
            <% End If %>
        </div>
    </div>
</div>

<%
If Not rsUsage Is Nothing Then
    rsUsage.Close
    Set rsUsage = Nothing
End If
CloseDbConnection conn
%>

<!--#include file="includes/footer.asp"-->
