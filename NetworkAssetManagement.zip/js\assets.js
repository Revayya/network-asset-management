/**
 * Network Asset Management System
 * Asset Management UI Helpers (assets.js)
 */

document.addEventListener('DOMContentLoaded', function() {
    const addAssetForm = document.getElementById('addAssetForm');
    const addAssetQtyInput = document.getElementById('addAssetQuantity');
    const addAssetAvailInput = document.getElementById('addAssetAvailable');

    // Auto-sync available stock with total quantity on asset creation
    if (addAssetQtyInput && addAssetAvailInput) {
        addAssetQtyInput.addEventListener('input', function() {
            const val = parseFloat(this.value) || 0;
            addAssetAvailInput.value = val >= 0 ? val : 0;
        });
    }

    if (addAssetForm) {
        addAssetForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            const assetNumber = document.getElementById('addAssetNumber').value.trim();
            const assetName = document.getElementById('addAssetName').value.trim();
            const assetLocation = document.getElementById('addAssetLocation').value.trim();
            const assetQuantity = parseFloat(document.getElementById('addAssetQuantity').value);
            const uom = document.getElementById('addAssetUom').value;

            if (!assetNumber || !assetName || !assetLocation || isNaN(assetQuantity) || assetQuantity < 0 || !uom) {
                showToast('Please fill all required fields.', 'warning');
                return;
            }

            const submitBtn = document.getElementById('btnSubmitAddAsset');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Saving...';
            }

            const res = await apiFetch('asset_add.asp?ajax=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    asset_number: assetNumber,
                    asset_name: assetName,
                    asset_location: assetLocation,
                    asset_quantity: assetQuantity,
                    uom: uom
                })
            });

            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Save Asset';
            }

            if (res.success) {
                showToast('Asset created successfully!', 'success');
                closeModal('addAssetModal');
                setTimeout(() => window.location.reload(), 600);
            } else {
                showToast(res.message || 'Failed to create asset.', 'error');
            }
        });
    }
});
