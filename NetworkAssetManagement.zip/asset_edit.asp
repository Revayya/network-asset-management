<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireAdmin()

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error: " & g_LastDbError
    Response.End
End If

Dim errorMessage, assetId
errorMessage = ""
assetId = CleanInput(Request("id"))

If Not IsNumeric(assetId) Or CLng(assetId) <= 0 Then
    CloseDbConnection conn
    Response.Redirect "assets.asp?msg=invalid_id"
    Response.End
End If

' Handle POST Update Submission
If Request.ServerVariables("REQUEST_METHOD") = "POST" Then
    Dim body
    body = ReadRequestBody()

    Dim assetName, assetLocation, assetQuantity, assetAvailable, uom
    assetName      = GetRequestField("asset_name", body)
    assetLocation  = GetRequestField("asset_location", body)
    assetQuantity  = GetRequestField("asset_quantity", body)
    assetAvailable = GetRequestField("asset_available", body)
    uom            = UCase(GetRequestField("uom", body))

    If assetName = "" Or assetLocation = "" Then
        errorMessage = "Asset Name and Location are required."
    ElseIf Not IsNumeric(assetQuantity) Or Not IsNumeric(assetAvailable) Then
        errorMessage = "Quantity and Available stock must be numbers."
    Else
        Dim qtyNum, availNum
        qtyNum = CDbl(assetQuantity)
        availNum = CDbl(assetAvailable)

        If qtyNum < 0 Or availNum < 0 Then
            errorMessage = "Stock quantities cannot be negative."
        ElseIf availNum > qtyNum Then
            errorMessage = "Available stock (" & availNum & ") cannot exceed total stock (" & qtyNum & ")."
        ElseIf Not IsValidUOM(uom) Then
            errorMessage = "Unit of Measurement must be 'NO' or 'MTR'."
        Else
            On Error Resume Next
            ' Update
            Dim cmdUpd
            Set cmdUpd = Server.CreateObject("ADODB.Command")
            Set cmdUpd.ActiveConnection = conn
            cmdUpd.CommandText = "UPDATE assets SET asset_name = ?, asset_location = ?, asset_quantity = ?, asset_available = ?, uom = ?, updated_at = NOW() WHERE id = ?"
            cmdUpd.CommandType = 1
            cmdUpd.Parameters.Append cmdUpd.CreateParameter("p_name", 200, 1, 150, assetName)
            cmdUpd.Parameters.Append cmdUpd.CreateParameter("p_loc", 200, 1, 100, assetLocation)
            cmdUpd.Parameters.Append cmdUpd.CreateParameter("p_qty", 131, 1, , qtyNum)
            cmdUpd.Parameters.Append cmdUpd.CreateParameter("p_avail", 131, 1, , availNum)
            cmdUpd.Parameters.Append cmdUpd.CreateParameter("p_uom", 200, 1, 10, uom)
            cmdUpd.Parameters.Append cmdUpd.CreateParameter("p_id", 3, 1, , CLng(assetId))
            cmdUpd.Execute

            If Err.Number <> 0 Then
                errorMessage = "Database update error: " & Err.Description
            Else
                LogAudit conn, GetAuthUserId(), "ASSET_UPDATE", "ASSET", CLng(assetId), "Updated asset #" & assetId & " (" & assetName & ") Qty: " & qtyNum & ", Avail: " & availNum
                CloseDbConnection conn

                If InStr(LCase(Request.ServerVariables("HTTP_ACCEPT")), "application/json") > 0 Or Request.QueryString("ajax") = "1" Then
                    Response.Clear
                    Response.ContentType = "application/json; charset=utf-8"
                    Response.Write "{""success"":true,""message"":""Asset updated successfully!""}"
                    Response.End
                Else
                    Response.Redirect "assets.asp?msg=updated"
                    Response.End
                End If
            End If
            Set cmdUpd = Nothing
            On Error GoTo 0
        End If
    End If

    If InStr(LCase(Request.ServerVariables("HTTP_ACCEPT")), "application/json") > 0 Or Request.QueryString("ajax") = "1" Then
        Response.Clear
        Response.ContentType = "application/json; charset=utf-8"
        Response.Status = "400 Bad Request"
        Response.Write "{""success"":false,""message"":""" & Replace(errorMessage, """", "\""") & """}"
        Response.End
    End If
End If

' Fetch current asset data for GET form render
Dim cmdFetch, rsFetch
Set cmdFetch = Server.CreateObject("ADODB.Command")
Set cmdFetch.ActiveConnection = conn
cmdFetch.CommandText = "SELECT * FROM assets WHERE id = ?"
cmdFetch.CommandType = 1
cmdFetch.Parameters.Append cmdFetch.CreateParameter("p_id", 3, 1, , CLng(assetId))
Set rsFetch = cmdFetch.Execute

If rsFetch.EOF Then
    rsFetch.Close
    Set rsFetch = Nothing
    Set cmdFetch = Nothing
    CloseDbConnection conn
    Response.Redirect "assets.asp?msg=not_found"
    Response.End
End If

Dim fNum, fName, fLoc, fQty, fAvail, fUom
fNum   = rsFetch("asset_number")
fName  = rsFetch("asset_name")
fLoc   = rsFetch("asset_location")
fQty   = rsFetch("asset_quantity")
fAvail = rsFetch("asset_available")
fUom   = rsFetch("uom")

rsFetch.Close
Set rsFetch = Nothing
Set cmdFetch = Nothing
CloseDbConnection conn

Dim pageTitle
pageTitle = "Edit Asset #" & fNum
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Edit Network Asset</h1>
        <p>Update equipment metadata and validate stock corrections.</p>
    </div>
    <div class="page-header-actions">
        <a href="assets.asp" class="btn btn-secondary">&larr; Back to Assets</a>
    </div>
</div>

<div class="card" style="max-width: 650px;">
    <div class="card-body">
        <% If errorMessage <> "" Then %>
            <div class="form-error" style="background-color: var(--danger-light); padding: 10px 14px; border-radius: var(--radius-md); margin-bottom: 20px;">
                <%= HtmlEncode(errorMessage) %>
            </div>
        <% End If %>

        <form method="POST" action="asset_edit.asp?id=<%= assetId %>">
            <input type="hidden" name="id" value="<%= assetId %>">
            <input type="hidden" name="csrf_token" value="<%= GetCsrfToken() %>">

            <div class="form-group">
                <label class="form-label">Asset Number</label>
                <input type="text" class="form-control" value="<%= HtmlEncode(fNum) %>" readonly style="background:#f1f5f9;">
                <div class="form-text">Asset numbers cannot be changed once assigned.</div>
            </div>

            <div class="form-group">
                <label for="asset_name" class="form-label required">Asset Name</label>
                <input type="text" id="asset_name" name="asset_name" class="form-control" value="<%= HtmlEncode(fName) %>" required>
            </div>

            <div class="form-group">
                <label for="asset_location" class="form-label required">Physical Location</label>
                <input type="text" id="asset_location" name="asset_location" class="form-control" value="<%= HtmlEncode(fLoc) %>" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label for="asset_quantity" class="form-label required">Total Quantity</label>
                    <input type="number" id="asset_quantity" name="asset_quantity" class="form-control" step="any" min="0" value="<%= fQty %>" required>
                </div>

                <div class="form-group">
                    <label for="asset_available" class="form-label required">Available Stock</label>
                    <input type="number" id="asset_available" name="asset_available" class="form-control" step="any" min="0" value="<%= fAvail %>" required>
                </div>
            </div>

            <div class="form-group">
                <label for="uom" class="form-label required">Unit of Measurement (UOM)</label>
                <select id="uom" name="uom" class="form-select" required>
                    <option value="NO" <%= IIf(fUom = "NO", "selected", "") %>>NO (Discrete Units)</option>
                    <option value="MTR" <%= IIf(fUom = "MTR", "selected", "") %>>MTR (Meters)</option>
                </select>
            </div>

            <div style="display: flex; gap: 10px; margin-top: 24px;">
                <button type="submit" class="btn btn-primary btn-lg">Save Changes</button>
                <a href="assets.asp" class="btn btn-secondary btn-lg">Cancel</a>
            </div>
        </form>
    </div>
</div>

<!--#include file="includes/footer.asp"-->
