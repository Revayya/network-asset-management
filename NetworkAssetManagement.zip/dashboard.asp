<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireLogin()
Dim pageTitle
pageTitle = "Dashboard"

Dim conn
Set conn = GetDbConnection()

' 1. Aggregate Statistics
Dim totalAssetTypes, totalQty, totalAvail, totalInUse, totalTransactions
totalAssetTypes = 0: totalQty = 0: totalAvail = 0: totalInUse = 0: totalTransactions = 0

If Not conn Is Nothing Then
    On Error Resume Next
    Dim rsStats
    Set rsStats = conn.Execute("SELECT COUNT(*) AS total_types, " & _
                               "COALESCE(SUM(asset_quantity), 0) AS sum_qty, " & _
                               "COALESCE(SUM(asset_available), 0) AS sum_avail, " & _
                               "COALESCE(SUM(asset_quantity - asset_available), 0) AS sum_in_use " & _
                               "FROM assets")
    If Not rsStats.EOF Then
        totalAssetTypes = rsStats("total_types")
        totalQty        = rsStats("sum_qty")
        totalAvail      = rsStats("sum_avail")
        totalInUse      = rsStats("sum_in_use")
    End If
    rsStats.Close
    Set rsStats = Nothing

    Dim rsTxCount
    Set rsTxCount = conn.Execute("SELECT COUNT(*) AS total_tx FROM asset_usage")
    If Not rsTxCount.EOF Then totalTransactions = rsTxCount("total_tx")
    rsTxCount.Close
    Set rsTxCount = Nothing

    ' 2. Recent Assets
    Dim rsRecentAssets
    Set rsRecentAssets = conn.Execute("SELECT id, asset_number, asset_name, asset_location, " & _
                                      "asset_quantity, asset_available, uom, created_at " & _
                                      "FROM assets ORDER BY created_at DESC, id DESC LIMIT 5")

    ' 3. Recent Usage
    Dim rsRecentUsage
    Set rsRecentUsage = conn.Execute("SELECT u.id, u.asset_id, a.asset_number, a.asset_name, " & _
                                     "u.quantity_used, u.uom, u.used_by, u.department, " & _
                                     "u.short_description, u.usage_datetime " & _
                                     "FROM asset_usage u " & _
                                     "JOIN assets a ON u.asset_id = a.id " & _
                                     "ORDER BY u.usage_datetime DESC, u.id DESC LIMIT 5")
    On Error GoTo 0
End If
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Operations Dashboard</h1>
        <p>Live inventory overview, active stock levels, and network asset consumption.</p>
    </div>
    <div class="page-header-actions">
        <a href="asset_issue.asp" class="btn btn-primary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>
            <span>Issue / Pick Asset</span>
        </a>

        <% If IsAdmin() Then %>
        <a href="asset_add.asp" class="btn btn-secondary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            <span>Add Asset</span>
        </a>
        <% End If %>
    </div>
</div>

<!-- KPI Summary Cards -->
<div class="kpi-grid">
    <div class="kpi-card">
        <div class="kpi-info">
            <span class="kpi-label">Asset Types</span>
            <div class="kpi-value"><%= totalAssetTypes %></div>
            <span class="kpi-subtext">Active catalog items</span>
        </div>
        <div class="kpi-icon-wrapper kpi-icon-blue">
            <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <span class="kpi-label">Total Quantity</span>
            <div class="kpi-value"><%= CDbl(totalQty) %></div>
            <span class="kpi-subtext">Catalog total stock</span>
        </div>
        <div class="kpi-icon-wrapper kpi-icon-indigo">
            <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <span class="kpi-label">Available Stock</span>
            <div class="kpi-value text-success"><%= CDbl(totalAvail) %></div>
            <span class="kpi-subtext">Ready for issuance</span>
        </div>
        <div class="kpi-icon-wrapper kpi-icon-green">
            <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <span class="kpi-label">Quantity In Use</span>
            <div class="kpi-value text-primary"><%= CDbl(totalInUse) %></div>
            <span class="kpi-subtext">Allocated to field/depts</span>
        </div>
        <div class="kpi-icon-wrapper kpi-icon-amber">
            <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <span class="kpi-label">Usage Transactions</span>
            <div class="kpi-value"><%= totalTransactions %></div>
            <span class="kpi-subtext">Total issue records</span>
        </div>
        <div class="kpi-icon-wrapper kpi-icon-rose">
            <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
        </div>
    </div>
</div>

<!-- Two-Column Recent Activity Layout -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 24px; margin-bottom: 24px;">
    <!-- Recently Added Assets -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line></svg>
                <span>Recently Added Assets</span>
            </div>
            <a href="assets.asp" class="btn btn-sm btn-secondary">View All Assets &rarr;</a>
        </div>
        <div class="table-responsive" style="border: none;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Asset #</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Available</th>
                    </tr>
                </thead>
                <tbody>
                    <% If rsRecentAssets Is Nothing Or rsRecentAssets.EOF Then %>
                        <tr><td colspan="4" class="empty-state"><p>No assets in database</p></td></tr>
                    <% Else %>
                        <% Do While Not rsRecentAssets.EOF %>
                        <tr>
                            <td><strong class="font-mono text-primary"><a href="asset_details.asp?id=<%= rsRecentAssets("id") %>"><%= HtmlEncode(rsRecentAssets("asset_number")) %></a></strong></td>
                            <td><%= HtmlEncode(rsRecentAssets("asset_name")) %></td>
                            <td class="text-muted"><%= HtmlEncode(rsRecentAssets("asset_location")) %></td>
                            <td class="font-bold text-success"><%= FormatDisplayQuantity(rsRecentAssets("asset_available"), rsRecentAssets("uom")) %></td>
                        </tr>
                        <% rsRecentAssets.MoveNext %>
                        <% Loop %>
                    <% End If %>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Recent Usage Transactions -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 14 14"></polyline></svg>
                <span>Recent Asset Transactions</span>
            </div>
            <a href="asset_usage.asp" class="btn btn-sm btn-secondary">Full History &rarr;</a>
        </div>
        <div class="table-responsive" style="border: none;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Asset</th>
                        <th>Used By</th>
                        <th>Dept</th>
                        <th>Qty Used</th>
                    </tr>
                </thead>
                <tbody>
                    <% If rsRecentUsage Is Nothing Or rsRecentUsage.EOF Then %>
                        <tr><td colspan="4" class="empty-state"><p>No usage records recorded</p></td></tr>
                    <% Else %>
                        <% Do While Not rsRecentUsage.EOF %>
                        <tr>
                            <td><strong><%= HtmlEncode(rsRecentUsage("asset_name")) %></strong></td>
                            <td><%= HtmlEncode(rsRecentUsage("used_by")) %></td>
                            <td><span class="badge" style="background:#f1f5f9; color:#475569;"><%= HtmlEncode(rsRecentUsage("department")) %></span></td>
                            <td class="text-danger font-bold">-<%= FormatDisplayQuantity(rsRecentUsage("quantity_used"), rsRecentUsage("uom")) %></td>
                        </tr>
                        <% rsRecentUsage.MoveNext %>
                        <% Loop %>
                    <% End If %>
                </tbody>
            </table>
        </div>
    </div>
</div>

<%
If Not rsRecentAssets Is Nothing Then
    rsRecentAssets.Close
    Set rsRecentAssets = Nothing
End If
If Not rsRecentUsage Is Nothing Then
    rsRecentUsage.Close
    Set rsRecentUsage = Nothing
End If
CloseDbConnection conn
%>

<!--#include file="includes/footer.asp"-->
