<%
' ===================================================================
-- Network Asset Management System
-- Configuration Template (config.example.asp)
-- Copy this file to "config.asp" and update credentials for your server
' ===================================================================

Const DB_SERVER   = "localhost"
Const DB_PORT     = "3306"
Const DB_NAME     = "network_asset_management"
Const DB_USER     = "root"
Const DB_PASSWORD = "YourSecurePasswordHere"

' Preferred ODBC Driver Name:
' Standard Options:
'   "MySQL ODBC 5.1 Driver"
'   "MySQL ODBC 8.0 Unicode Driver"
'   "MySQL ODBC 8.0 ANSI Driver"
Const DB_DRIVER   = "MySQL ODBC 5.1 Driver"

' Application Settings
Const APP_NAME    = "Network Asset Management System"
Const APP_VERSION = "2.0.0"
Const APP_ENV     = "production" ' "development" or "production"

' Security and Session
Const SESSION_TIMEOUT_MINS = 30
Const APP_SECRET_SALT      = "NAM_SECURE_SALT_9f82a1c0"
%>
