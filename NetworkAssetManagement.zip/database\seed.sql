-- ==========================================================
-- Network Asset Management System
-- Seed Data Script
-- Target Database: MySQL 5.5+ / 8.0+ / MariaDB
-- Compatibility: SQLyog Community Edition
-- Initial Accounts:
--   1. admin (Password: Admin@12345) - Role: admin
--   2. user  (Password: User@12345)  - Role: user
--   3. jdoe  (Password: User@12345)  - Role: user
-- Password Hash Format: <salt>$<SHA256(salt + password)>
-- ==========================================================

USE `network_asset_management`;

-- ----------------------------------------------------------
-- 1. Insert Initial Users
-- ----------------------------------------------------------
INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `role`, `department`, `is_active`, `created_at`) VALUES
(1, 'admin', 'e4f8b9c1d2e3f4a5b6c7d8e9f0a1b2c3$064305e47457dea469d4c13318be20eeb724edd232a88557c561adbcb2597913', 'System Administrator', 'admin', 'IT Infrastructure', 1, NOW()),
(2, 'user',  'a1b2c3d4e5f60718293a4b5c6d7e8f90$7ba8fc359b0b3eb48076bcbdcb49a4dce8611890373ca85773fe82589fe900ec', 'Network Technician',   'user',  'Network Operations', 1, NOW()),
(3, 'jdoe',  'a1b2c3d4e5f60718293a4b5c6d7e8f90$7ba8fc359b0b3eb48076bcbdcb49a4dce8611890373ca85773fe82589fe900ec', 'John Doe',             'user',  'Security Operations', 1, NOW())
ON DUPLICATE KEY UPDATE `full_name` = VALUES(`full_name`);

-- ----------------------------------------------------------
-- 2. Insert Initial Network Assets
-- Covers enterprise networking equipment (UOM: NO) and cabling (UOM: MTR)
-- Note: asset_available is accurately synchronized with initial usage
-- ----------------------------------------------------------
INSERT INTO `assets` (`id`, `asset_number`, `asset_name`, `asset_location`, `asset_quantity`, `asset_available`, `uom`, `created_by`, `created_at`) VALUES
(1, 'NET-SW-9300',  'Cisco Catalyst 9300 48-Port PoE+ Switch', 'Server Room Rack A1',  10.00,  7.00, 'NO',  1, NOW() - INTERVAL 10 DAY),
(2, 'NET-RT-4451',  'Cisco ISR 4451 Integrated Router',        'Data Center Rack B2',   5.00,  4.00, 'NO',  1, NOW() - INTERVAL 9 DAY),
(3, 'NET-FW-P600',  'Fortinet FortiGate 600E Next-Gen Firewall','Core Rack C1',          4.00,  4.00, 'NO',  1, NOW() - INTERVAL 8 DAY),
(4, 'NET-AP-9130',  'Cisco Catalyst 9130AX Series Wi-Fi 6 AP', 'IT Warehouse Shelf 3', 30.00, 22.00, 'NO',  1, NOW() - INTERVAL 7 DAY),
(5, 'NET-SFP-10G',  '10GBASE-SR SFP+ Optical Transceiver',     'Accessories Cabinet 2', 50.00, 38.00, 'NO',  1, NOW() - INTERVAL 6 DAY),
(6, 'NET-CAB-C6U',  'Cat6 UTP Solid Bare Copper Bulk Cable',   'Cable Storage Bay 1', 1000.00, 650.00, 'MTR', 1, NOW() - INTERVAL 5 DAY),
(7, 'NET-CAB-SMF',  'Single-Mode OS2 12-Core Fiber Optic Cable','Cable Storage Bay 2',  500.00, 320.00, 'MTR', 1, NOW() - INTERVAL 4 DAY),
(8, 'NET-PP-48P',   'Cat6 48-Port 1U Loaded Patch Panel',      'Server Room Rack A2',  12.00, 10.00, 'NO',  1, NOW() - INTERVAL 3 DAY),
(9, 'NET-PDU-30A',  'APC Switched Rack PDU 30A 208V',          'Data Center Rack B1',   8.00,  8.00, 'NO',  1, NOW() - INTERVAL 2 DAY),
(10,'NET-CONSOLE',  'Opengear 16-Port Terminal Server',        'Management Rack M1',    3.00,  3.00, 'NO',  1, NOW() - INTERVAL 1 DAY)
ON DUPLICATE KEY UPDATE `asset_name` = VALUES(`asset_name`);

-- ----------------------------------------------------------
-- 3. Insert Realistic Asset Usage Records
-- Reflects stock issued out to departments and personnel
-- ----------------------------------------------------------
INSERT INTO `asset_usage` (`id`, `asset_id`, `quantity_used`, `uom`, `used_by`, `department`, `short_description`, `issued_by_user_id`, `usage_datetime`, `created_at`) VALUES
(1, 1,  2.00, 'NO',  'Michael Scott',   'Floor 3 Expansion',   'Installed in Floor 3 IDF switch rack for VOIP phones', 1, NOW() - INTERVAL 6 DAY, NOW() - INTERVAL 6 DAY),
(2, 1,  1.00, 'NO',  'Sarah Connor',    'Security Operations', 'Dedicated switch for Security CCTV surveillance VLAN', 1, NOW() - INTERVAL 4 DAY, NOW() - INTERVAL 4 DAY),
(3, 2,  1.00, 'NO',  'David Miller',    'WAN Infrastructure',  'Redundant router replacement for Branch Office WAN link', 1, NOW() - INTERVAL 5 DAY, NOW() - INTERVAL 5 DAY),
(4, 4,  8.00, 'NO',  'Network Technician', 'Facilities & Wi-Fi',  'Deployed 8 APs across Building B conference rooms', 2, NOW() - INTERVAL 3 DAY, NOW() - INTERVAL 3 DAY),
(5, 5, 12.00, 'NO',  'Alex Mercer',     'Server Engineering',  '10G uplinks from VM hosts to Core switch stack', 1, NOW() - INTERVAL 2 DAY, NOW() - INTERVAL 2 DAY),
(6, 6, 350.00,'MTR', 'Network Technician', 'Field Engineering',  'Network cabling run for new engineering workbenches', 2, NOW() - INTERVAL 2 DAY, NOW() - INTERVAL 2 DAY),
(7, 7, 180.00,'MTR', 'Elena Gilbert',   'Fiber Optics Team',   'Backbone fiber run between Data Center and Block C IDF', 1, NOW() - INTERVAL 1 DAY, NOW() - INTERVAL 1 DAY),
(8, 8,  2.00, 'NO',  'John Doe',        'Infrastructure Team', 'Installed in Block C IDF for floor data termination', 3, NOW() - INTERVAL 1 DAY, NOW() - INTERVAL 1 DAY)
ON DUPLICATE KEY UPDATE `used_by` = VALUES(`used_by`);

-- ----------------------------------------------------------
-- 4. Insert Initial Audit Trail
-- ----------------------------------------------------------
INSERT INTO `audit_logs` (`user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES
(1, 'SYSTEM_INIT', 'SYSTEM', 0, 'Initial database schema and seed data deployed', '127.0.0.1', NOW() - INTERVAL 10 DAY),
(1, 'USER_CREATE', 'USER', 1, 'Created primary administrator account [admin]', '127.0.0.1', NOW() - INTERVAL 10 DAY),
(1, 'USER_CREATE', 'USER', 2, 'Created standard user account [user]', '127.0.0.1', NOW() - INTERVAL 10 DAY),
(1, 'ASSET_CREATE', 'ASSET', 1, 'Added asset NET-SW-9300 (Qty: 10 NO)', '127.0.0.1', NOW() - INTERVAL 10 DAY),
(1, 'ASSET_ISSUE', 'USAGE', 1, 'Issued 2 NO of NET-SW-9300 to Michael Scott', '127.0.0.1', NOW() - INTERVAL 6 DAY),
(2, 'ASSET_ISSUE', 'USAGE', 4, 'Issued 8 NO of NET-AP-9130 to Network Technician', '192.168.1.45', NOW() - INTERVAL 3 DAY),
(2, 'ASSET_ISSUE', 'USAGE', 6, 'Issued 350 MTR of NET-CAB-C6U to Network Technician', '192.168.1.45', NOW() - INTERVAL 2 DAY);

-- ----------------------------------------------------------
-- 5. Insert Application Settings
-- ----------------------------------------------------------
INSERT INTO `app_settings` (`setting_key`, `setting_value`, `description`, `updated_at`) VALUES
('organization_name', 'Enterprise Network Operations', 'Organization or department display name', NOW()),
('session_timeout_minutes', '30', 'Session inactivity timeout in minutes', NOW()),
('low_stock_threshold_no', '3', 'Low stock alert threshold for discrete items (NO)', NOW()),
('low_stock_threshold_mtr', '100', 'Low stock alert threshold for cables (MTR)', NOW()),
('default_page_size', '10', 'Default rows per page in tables', NOW())
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);
