<%
' ===================================================================
' Network Asset Management System
' Database Connection Provider (db_connection.asp)
' ADODB & MySQL ODBC Connection Management with Driver Auto-Detection
' ===================================================================

' ADODB Parameter Direction and Data Type Constants
Const adParamInput    = 1
Const adCmdText       = 1
Const adInteger       = 3
Const adDouble        = 5
Const adCurrency      = 6
Const adDate          = 7
Const adBoolean       = 11
Const adVarChar       = 200
Const adLongVarChar   = 201
Const adNumeric       = 131

Dim g_LastDbError
g_LastDbError = ""

' Build connection string for a given driver
Function BuildConnectionString(driverName, serverHost, serverPort, dbName, dbUser, dbPass)
    Dim connStr
    connStr = "Driver={" & driverName & "};" & _
              "Server=" & serverHost & ";" & _
              "Port=" & serverPort & ";" & _
              "Database=" & dbName & ";" & _
              "User=" & dbUser & ";" & _
              "Password=" & dbPass & ";" & _
              "Option=3;"
    BuildConnectionString = connStr
End Function

' Open and return an ADODB.Connection
Function GetDbConnection()
    Dim conn, connStr, drivers(4), i, connected, lastErr
    
    ' Default configuration fallbacks if constants not yet imported
    Dim sHost, sPort, sName, sUser, sPass, preferredDriver
    sHost = "localhost": sPort = "3306": sName = "network_asset_management"
    sUser = "root": sPass = "": preferredDriver = "MySQL ODBC 5.1 Driver"
    
    On Error Resume Next
    If DB_SERVER <> "" Then sHost = DB_SERVER
    If DB_PORT <> "" Then sPort = DB_PORT
    If DB_NAME <> "" Then sName = DB_NAME
    If DB_USER <> "" Then sUser = DB_USER
    If DB_PASSWORD <> "" Then sPass = DB_PASSWORD
    If DB_DRIVER <> "" Then preferredDriver = DB_DRIVER
    On Error GoTo 0
    
    ' Priority list of drivers to try
    drivers(0) = preferredDriver
    drivers(1) = "MySQL ODBC 5.1 Driver"
    drivers(2) = "MySQL ODBC 8.0 Unicode Driver"
    drivers(3) = "MySQL ODBC 8.0 ANSI Driver"
    drivers(4) = "MySQL ODBC 26.7 Unicode Driver"
    
    connected = False
    lastErr = ""
    
    For i = 0 To UBound(drivers)
        If drivers(i) <> "" Then
            connStr = BuildConnectionString(drivers(i), sHost, sPort, sName, sUser, sPass)
            
            On Error Resume Next
            Set conn = Server.CreateObject("ADODB.Connection")
            conn.ConnectionTimeout = 10
            conn.CommandTimeout = 30
            conn.Open connStr
            
            If Err.Number = 0 And conn.State = 1 Then
                connected = True
                On Error GoTo 0
                Exit For
            Else
                lastErr = "Driver [" & drivers(i) & "]: " & Err.Description
                Set conn = Nothing
                Err.Clear
            End If
            On Error GoTo 0
        End If
    Next
    
    If connected Then
        g_LastDbError = ""
        Set GetDbConnection = conn
    Else
        g_LastDbError = lastErr
        Set GetDbConnection = Nothing
    End If
End Function

' Safely close connection
Sub CloseDbConnection(ByRef conn)
    On Error Resume Next
    If Not conn Is Nothing Then
        If conn.State = 1 Then
            conn.Close
        End If
        Set conn = Nothing
    End If
    On Error GoTo 0
End Sub

' Sanitizes SQL string literals (Defense in Depth)
Function EscapeSql(strVal)
    If IsNull(strVal) Or IsEmpty(strVal) Then
        EscapeSql = ""
    Else
        EscapeSql = Replace(CStr(strVal), "'", "''")
        EscapeSql = Replace(EscapeSql, "\", "\\")
    End If
End Function
%>
