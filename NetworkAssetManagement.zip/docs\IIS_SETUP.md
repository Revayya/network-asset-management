# Network Asset Management System
## Microsoft IIS Configuration & Troubleshooting Guide

This guide details configuring Microsoft Internet Information Services (IIS) to host the Classic ASP application with high performance, secure session management, and robust ODBC integration.

---

## 1. Enabling Classic ASP in IIS

Classic ASP is a native feature in Windows IIS but is turned off by default on modern Windows versions.

### Windows 10 & 11 Setup:
1. Press `Win + R`, type `optionalfeatures.exe`, and press Enter.
2. In the Windows Features dialog, navigate to:
   ```
   Internet Information Services
     └─ World Wide Web Services
         └─ Application Development Features
             ├─ [x] ASP (Classic ASP)
             └─ [x] ISAPI Extensions
   ```
3. Click **OK** and allow the installer to complete.

### Windows Server (2012 / 2016 / 2019 / 2022) Setup:
1. Open **Server Manager**.
2. Click **Manage** &rarr; **Add Roles and Features**.
3. Under **Server Roles**, expand:
   `Web Server (IIS)` &rarr; `Web Server` &rarr; `Application Development`
4. Check **ASP** and finish the installation.

---

## 2. Enabling Parent Paths & Session Limits

In Classic ASP, reusable include files in subfolders reference parent paths (e.g. `<!--#include file="../config/config.asp"-->`). Parent Paths must be enabled.

### Via Command Line (Fastest):
Open an Administrator Command Prompt or PowerShell:
```cmd
%windir%\system32\inetsrv\appcmd.exe set config /section:asp /enableParentPaths:True
```

### Via IIS Manager GUI:
1. Open **IIS Manager** (`inetmgr`).
2. Select your Web Server node or the `NetworkAssetManagement` site.
3. In the center pane, double-click **ASP**.
4. Under **Behavior**, change **Enable Parent Paths** from `False` to `True`.
5. Under **Services**, verify **Session Properties** &rarr; **Time-out** is set to `00:30:00` (30 minutes).
6. Under **Debugging Properties**, set **Send Errors To Browser** to `True` during testing (set to `False` in production).
7. Click **Apply** in the right-hand Actions pane.

---

## 3. Creating the IIS Site and Application Pool

1. In IIS Manager, right-click **Sites** &rarr; **Add Website...**
   - **Site name:** `NetAssetSystem`
   - **Physical path:** `C:\Users\hp\.gemini\antigravity\scratch\NetworkAssetManagement`
   - **Port:** `8080` (or `80`)
2. Navigate to **Application Pools**:
   - Right-click `NetAssetSystem` pool &rarr; **Advanced Settings...**
   - **.NET CLR Version:** `No Managed Code` (Classic ASP does not require the .NET CLR)
   - **Enable 32-Bit Applications:** `False` (for 64-bit MySQL ODBC)
   - **Managed Pipeline Mode:** `Classic` or `Integrated` (both work with ASP)
   - **Idle Time-out (minutes):** `0` (prevents worker process shutdown during business hours)
3. Grant NTFS folder permissions to the IIS worker identity:
   ```powershell
   icacls "C:\Users\hp\.gemini\antigravity\scratch\NetworkAssetManagement" /grant "IIS_IUSRS:(OI)(CI)RX"
   icacls "C:\Users\hp\.gemini\antigravity\scratch\NetworkAssetManagement" /grant "IUSR:(OI)(CI)RX"
   ```

---

## 4. Troubleshooting Common IIS & ADODB Errors

| Error Code / Symptom | Root Cause | Resolution |
| :--- | :--- | :--- |
| **ASP 0131 / Disallowed Parent Path** | IIS disabled the `..` path operator in `#include` directives. | Run: `appcmd.exe set config /section:asp /enableParentPaths:True` |
| **HTTP 500.19 / Internal Server Error** | Missing IIS role or incorrect web.config read permissions. | Ensure `IIS_IUSRS` has Read permission on the site folder. |
| **ADODB.Connection: Data source name not found** | ODBC driver name specified in `config.asp` does not match installed driver. | Verify with `Get-OdbcDriver -Name "*MySQL*"`. Ensure 64-bit driver is installed. |
| **Architecture mismatch (32-bit vs 64-bit)** | 32-bit driver installed but App Pool is 64-bit, or vice versa. | In App Pool Advanced Settings, match `Enable 32-Bit Applications` to driver bitness. |
| **Authentication failed for user 'root'@'localhost'** | MySQL password incorrect or user authentication plugin incompatible. | Update password in `config/config.asp` or run `ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'pass';` |
| **Access Denied / Blank Page** | IIS Anonymous Authentication not pointing to IUSR. | In IIS Manager &rarr; Authentication &rarr; Anonymous Authentication &rarr; Edit &rarr; Select `Application pool identity` or `IUSR`. |
