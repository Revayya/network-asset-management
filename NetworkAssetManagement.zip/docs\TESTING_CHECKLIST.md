# Network Asset Management System
## Quality Assurance & Testing Checklist

Use this structured test checklist to verify system functionality, security enforcement, database integrity, and concurrency handling.

---

## 1. Authentication & Session Validation

- [ ] **Valid Admin Login:**
  - Enter username `admin` and password `Admin@12345`.
  - Expected: Successfully logs in, redirects to `dashboard.asp`, topbar displays `System Administrator` with `ADMIN` badge, full navigation menu accessible.
- [ ] **Valid User Login:**
  - Enter username `user` and password `User@12345`.
  - Expected: Successfully logs in, topbar displays `Network Technician` with `USER` badge, admin links (Reports, User Management, Audit Logs, Settings) hidden.
- [ ] **Invalid Password:**
  - Enter username `admin` with wrong password.
  - Expected: Access rejected with clear error alert: *"Invalid username or password"*. Failed attempt recorded in audit log.
- [ ] **Inactive Account Rejection:**
  - Deactivate a user via User Management, then attempt to log in with that user.
  - Expected: Login blocked with message: *"This account is inactive"*.
- [ ] **Session Expiration:**
  - Wait 30 minutes of inactivity or test with reduced session timeout.
  - Expected: Session invalidates, user redirected to `login.asp?msg=session_expired`.
- [ ] **Direct Unauthorized URL Access:**
  - Open an incognito browser window and navigate directly to `http://localhost:8080/reports.asp` or `http://localhost:8080/users.asp`.
  - Expected: Server intercepts request and redirects to `login.asp`.
- [ ] **User Role Direct URL Enforcement:**
  - Log in as standard user `user`, then manually navigate to `http://localhost:8080/users.asp`.
  - Expected: Server-side RBAC blocks access and redirects to `dashboard.asp?msg=access_denied`.

---

## 2. Asset Management & Integrity

- [ ] **Add New Asset:**
  - As Admin, click **Add Asset**. Enter `NET-RT-1001`, `Edge Gateway Router`, `Rack D4`, Quantity `5`, UOM `NO`.
  - Expected: Available quantity auto-initialized to `5`. Asset saved and displayed in table without full page refresh.
- [ ] **Duplicate Asset Number Rejection:**
  - Attempt to add another asset with the existing number `NET-RT-1001`.
  - Expected: Server returns HTTP 409 Conflict with error message: *"Asset Number already exists"*.
- [ ] **UOM Dropdown Options:**
  - Verify dropdown allows only `NO` and `MTR`.
  - Expected: Bad values rejected on client and server.
- [ ] **Negative Quantity Prevention:**
  - Attempt to create asset with Quantity `-5`.
  - Expected: Validation error displayed, submission blocked.
- [ ] **Edit Asset Details:**
  - Click **Edit** on an existing asset. Update location and name.
  - Expected: Changes saved successfully and recorded in `audit_logs` with before-and-after values.

---

## 3. Stock Issuance & Concurrency Protection

- [ ] **Issue Available Asset:**
  - Click **Use Asset** on `NET-SW-9300` (available stock: 7 NO). Enter Quantity `2`, Used By `Alice Smith`, Dept `DevOps`, Description `Switch for staging lab`.
  - Expected: Available quantity reduces from 7 to 5. Total quantity remains 10. Transaction recorded in Usage History.
- [ ] **Insufficient Stock Rejection:**
  - Attempt to issue 10 units when only 5 units are available.
  - Expected: Client validation blocks input; server transaction rejects checkout if bypassed.
- [ ] **Concurrent Checkout Safety:**
  - Open two separate browser tabs on the same asset having 1 unit available. Submit issue request of 1 unit in both simultaneously.
  - Expected: Exactly one transaction succeeds (reducing stock to 0); the second receives an atomic lock rollback notification: *"Insufficient stock available"*.
- [ ] **Zero / Negative Usage Rejection:**
  - Attempt to enter quantity `0` or `-2` in the issue form.
  - Expected: Form rejected with validation warning: *"Quantity used must be greater than zero"*.
- [ ] **Automatic Server Timestamp:**
  - Check the usage record in the database.
  - Expected: `usage_datetime` reflects the true server clock timestamp.

---

## 4. Search, Filtering, and Reports

- [ ] **Live Search by Asset Number / Name:**
  - Type `9300` into search box.
  - Expected: Table filters instantly to show matching Cisco Catalyst 9300 switch.
- [ ] **Filter by Location & UOM:**
  - Filter by `Server Room Rack A1` and UOM `NO`.
  - Expected: Displays only matching equipment matching both criteria.
- [ ] **Date Range Filter:**
  - Select From Date and To Date spanning the last 7 days.
  - Expected: Real database query executes, filtering table rows.
- [ ] **Pagination Navigation:**
  - Change page size to 10. Click next page buttons.
  - Expected: Table navigates smoothly between pages with correct record counts.
- [ ] **CSV Export:**
  - Click **Export CSV** on Asset Management and Usage History pages.
  - Expected: Browser downloads RFC 4180-compliant `.csv` file with exact active filter records and correct column headers.
- [ ] **Analytical Reports (Admin):**
  - Navigate to Reports & Analytics. Click **Department Usage** and **Low Stock**.
  - Expected: Aggregated SQL queries generate accurate group totals without double-counting stock.

---

## 5. UI & Responsiveness

- [ ] **Desktop Display:**
  - View at 1920x1080 and 1366x768.
  - Expected: Fixed sidebar, clean topbar, card grid neatly aligned.
- [ ] **Mobile & Tablet Display:**
  - Resize browser to 375px width (iPhone / Android) and 768px (iPad).
  - Expected: Sidebar collapses into off-canvas drawer with hamburger toggle button; tables support smooth horizontal scrolling; modals scale responsively.
- [ ] **Keyboard Accessibility:**
  - Press `ESC` when any modal is open.
  - Expected: Modal closes immediately.
