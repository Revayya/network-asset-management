            </main>
            
            <!-- Global Footer -->
            <footer class="app-footer">
                <div class="footer-left">
                    <span>Network Asset Management System &bull; Enterprise Operations Core</span>
                </div>
                <div class="footer-right">
                    <span>Classic ASP / MySQL ODBC &bull; v2.0</span>
                </div>
            </footer>
        </div>
    </div>

    <!-- Backdrop for mobile drawer -->
    <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

    <!-- Global Toast Container -->
    <div class="toast-container" id="toastContainer" aria-live="polite"></div>

    <!-- Global Confirmation Modal -->
    <div class="modal-overlay" id="confirmModal" style="display: none;">
        <div class="modal-card modal-sm">
            <div class="modal-header">
                <h3 class="modal-title" id="confirmModalTitle">Confirm Action</h3>
                <button type="button" class="modal-close" onclick="closeConfirmModal()">&times;</button>
            </div>
            <div class="modal-body" id="confirmModalBody">
                Are you sure you want to proceed with this operation?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeConfirmModal()">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmModalBtn">Confirm</button>
            </div>
        </div>
    </div>

    <!-- Global Script Config -->
    <script>
        window.NAM_CONFIG = {
            userId: <%= GetAuthUserId() %>,
            username: "<%= EscapeJson(GetAuthUsername()) %>",
            fullName: "<%= EscapeJson(GetAuthFullName()) %>",
            role: "<%= EscapeJson(GetAuthRole()) %>",
            department: "<%= EscapeJson(GetAuthDepartment()) %>",
            csrfToken: "<%= GetCsrfToken() %>"
        };
    </script>
    <script src="js/app.js"></script>
    <script src="js/filters.js"></script>
</body>
</html>
