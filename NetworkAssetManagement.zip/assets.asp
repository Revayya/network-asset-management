<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireLogin()
Dim pageTitle
pageTitle = "Asset Management"

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error: " & g_LastDbError
    Response.End
End If

' Filter inputs
Dim qAssetNumber, qAssetName, qLocation, qUom, qStockStatus, qFromDate, qToDate
qAssetNumber = CleanInput(Request.QueryString("asset_number"))
qAssetName   = CleanInput(Request.QueryString("asset_name"))
qLocation    = CleanInput(Request.QueryString("location"))
qUom         = UCase(CleanInput(Request.QueryString("uom")))
qStockStatus = CleanInput(Request.QueryString("stock_status"))
qFromDate    = CleanInput(Request.QueryString("from_date"))
qToDate      = CleanInput(Request.QueryString("to_date"))

' Pagination
Dim page, pageSize, offset
page = CLng(Request.QueryString("page"))
If page < 1 Then page = 1

pageSize = CLng(Request.QueryString("page_size"))
If pageSize < 1 Or pageSize > 100 Then pageSize = 10

offset = (page - 1) * pageSize

' Build SQL WHERE
Dim whereClauses
whereClauses = " WHERE 1=1 "

If qAssetNumber <> "" Then whereClauses = whereClauses & " AND asset_number LIKE '%" & EscapeSql(qAssetNumber) & "%' "
If qAssetName <> "" Then whereClauses = whereClauses & " AND asset_name LIKE '%" & EscapeSql(qAssetName) & "%' "
If qLocation <> "" Then whereClauses = whereClauses & " AND asset_location = '" & EscapeSql(qLocation) & "' "
If qUom = "NO" Or qUom = "MTR" Then whereClauses = whereClauses & " AND uom = '" & EscapeSql(qUom) & "' "

If qStockStatus = "in_stock" Then
    whereClauses = whereClauses & " AND asset_available > 0 "
ElseIf qStockStatus = "low_stock" Then
    whereClauses = whereClauses & " AND asset_available > 0 AND asset_available <= 5 "
ElseIf qStockStatus = "out_of_stock" Then
    whereClauses = whereClauses & " AND asset_available <= 0 "
End If

If IsValidDateString(qFromDate) Then whereClauses = whereClauses & " AND created_at >= '" & EscapeSql(qFromDate) & " 00:00:00' "
If IsValidDateString(qToDate) Then whereClauses = whereClauses & " AND created_at <= '" & EscapeSql(qToDate) & " 23:59:59' "

' Count total
Dim totalRecords, totalPages, rsCount
totalRecords = 0
Set rsCount = conn.Execute("SELECT COUNT(*) AS c FROM assets " & whereClauses)
If Not rsCount.EOF Then totalRecords = CLng(rsCount("c"))
rsCount.Close
Set rsCount = Nothing

If totalRecords > 0 Then
    totalPages = Int((totalRecords + pageSize - 1) / pageSize)
Else
    totalPages = 1
End If

' Select paginated records
Dim rsAssets
Set rsAssets = conn.Execute("SELECT id, asset_number, asset_name, asset_location, " & _
                            "asset_quantity, asset_available, uom, created_at " & _
                            "FROM assets " & whereClauses & _
                            "ORDER BY id DESC LIMIT " & offset & ", " & pageSize)

' Query string builder for pagination links
Function BuildQuery(targetPage)
    BuildQuery = "assets.asp?page=" & targetPage & _
                 "&page_size=" & pageSize & _
                 "&asset_number=" & Server.URLEncode(qAssetNumber) & _
                 "&asset_name=" & Server.URLEncode(qAssetName) & _
                 "&location=" & Server.URLEncode(qLocation) & _
                 "&uom=" & Server.URLEncode(qUom) & _
                 "&stock_status=" & Server.URLEncode(qStockStatus) & _
                 "&from_date=" & Server.URLEncode(qFromDate) & _
                 "&to_date=" & Server.URLEncode(qToDate)
End Function

' Feedback messages
Dim feedbackMsg
feedbackMsg = ""
If Request.QueryString("msg") = "added" Then feedbackMsg = "Asset registered successfully!"
If Request.QueryString("msg") = "updated" Then feedbackMsg = "Asset changes saved successfully!"
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Network Asset Inventory</h1>
        <p>Enterprise catalog of networking equipment, switches, routers, firewalls, and bulk cabling.</p>
    </div>
    <div class="page-header-actions">
        <a href="asset_issue.asp" class="btn btn-primary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>
            <span>Issue Asset</span>
        </a>

        <% If IsAdmin() Then %>
        <a href="asset_add.asp" class="btn btn-success">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            <span>Add Asset</span>
        </a>
        <% End If %>

        <a href="export_csv.asp?report_type=assets&asset_number=<%= Server.URLEncode(qAssetNumber) %>&asset_name=<%= Server.URLEncode(qAssetName) %>&location=<%= Server.URLEncode(qLocation) %>&uom=<%= Server.URLEncode(qUom) %>&stock_status=<%= Server.URLEncode(qStockStatus) %>" class="btn btn-secondary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
            <span>Export CSV</span>
        </a>
    </div>
</div>

<% If feedbackMsg <> "" Then %>
    <div style="background-color: var(--success-light); color: var(--success); padding: 12px 18px; border-radius: var(--radius-md); margin-bottom: 20px; font-weight: 500;">
        &#10004; <%= HtmlEncode(feedbackMsg) %>
    </div>
<% End If %>

<!-- Search & Filter Form -->
<form method="GET" action="assets.asp" class="filter-card">
    <div class="filter-grid">
        <div class="form-group" style="margin-bottom: 0;">
            <label for="f_num" class="form-label" style="font-size: 11px;">ASSET NUMBER</label>
            <input type="text" id="f_num" name="asset_number" class="form-control" placeholder="Search number..." value="<%= HtmlEncode(qAssetNumber) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="f_name" class="form-label" style="font-size: 11px;">ASSET NAME</label>
            <input type="text" id="f_name" name="asset_name" class="form-control" placeholder="Search name..." value="<%= HtmlEncode(qAssetName) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="f_loc" class="form-label" style="font-size: 11px;">LOCATION</label>
            <input type="text" id="f_loc" name="location" class="form-control" placeholder="Filter location..." value="<%= HtmlEncode(qLocation) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="f_uom" class="form-label" style="font-size: 11px;">UOM</label>
            <select id="f_uom" name="uom" class="form-select">
                <option value="">All Units</option>
                <option value="NO" <%= IIf(qUom = "NO", "selected", "") %>>NO (Discrete)</option>
                <option value="MTR" <%= IIf(qUom = "MTR", "selected", "") %>>MTR (Meters)</option>
            </select>
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="f_stock" class="form-label" style="font-size: 11px;">STOCK STATUS</label>
            <select id="f_stock" name="stock_status" class="form-select">
                <option value="">All Statuses</option>
                <option value="in_stock" <%= IIf(qStockStatus = "in_stock", "selected", "") %>>Available (> 0)</option>
                <option value="low_stock" <%= IIf(qStockStatus = "low_stock", "selected", "") %>>Low Stock (<= 5)</option>
                <option value="out_of_stock" <%= IIf(qStockStatus = "out_of_stock", "selected", "") %>>Out of Stock (0)</option>
            </select>
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="f_from" class="form-label" style="font-size: 11px;">FROM DATE</label>
            <input type="date" id="f_from" name="from_date" class="form-control" value="<%= HtmlEncode(qFromDate) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="f_to" class="form-label" style="font-size: 11px;">TO DATE</label>
            <input type="date" id="f_to" name="to_date" class="form-control" value="<%= HtmlEncode(qToDate) %>">
        </div>

        <div class="filter-actions" style="margin-bottom: 0;">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="assets.asp" class="btn btn-secondary">Reset</a>
            <select name="page_size" class="form-select" style="width: 80px;" onchange="this.form.submit()">
                <option value="10" <%= IIf(pageSize = 10, "selected", "") %>>10</option>
                <option value="25" <%= IIf(pageSize = 25, "selected", "") %>>25</option>
                <option value="50" <%= IIf(pageSize = 50, "selected", "") %>>50</option>
            </select>
        </div>
    </div>
</form>

<!-- Assets Data Table -->
<div class="card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 50px;">ID</th>
                    <th>Asset Number</th>
                    <th>Asset Name</th>
                    <th>Location</th>
                    <th>Total Qty</th>
                    <th>Available Stock</th>
                    <th>Added Date</th>
                    <th>UOM</th>
                    <th style="text-align: right; min-width: 180px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <% If rsAssets Is Nothing Or rsAssets.EOF Then %>
                    <tr><td colspan="9" class="empty-state"><p>No assets found matching filter criteria.</p></td></tr>
                <% Else %>
                    <% Do While Not rsAssets.EOF %>
                    <% 
                    Dim curAvail: curAvail = CDbl(rsAssets("asset_available"))
                    Dim stockBadge
                    If curAvail <= 0 Then
                        stockBadge = "<span class='badge badge-stock-out'>Out of Stock</span>"
                    ElseIf curAvail <= 5 Then
                        stockBadge = "<span class='badge badge-stock-low'>Low Stock</span>"
                    Else
                        stockBadge = "<span class='badge badge-stock-in'>Available</span>"
                    End If
                    %>
                    <tr>
                        <td class="font-mono text-muted">#<%= rsAssets("id") %></td>
                        <td><strong class="font-mono text-primary"><a href="asset_details.asp?id=<%= rsAssets("id") %>"><%= HtmlEncode(rsAssets("asset_number")) %></a></strong></td>
                        <td><strong><%= HtmlEncode(rsAssets("asset_name")) %></strong></td>
                        <td><span class="text-muted"><%= HtmlEncode(rsAssets("asset_location")) %></span></td>
                        <td><strong><%= FormatDisplayQuantity(rsAssets("asset_quantity"), rsAssets("uom")) %></strong></td>
                        <td>
                            <span class="font-bold <%= IIf(curAvail > 0, "text-success", "text-danger") %>">
                                <%= FormatDisplayQuantity(curAvail, rsAssets("uom")) %>
                            </span>
                            <%= stockBadge %>
                        </td>
                        <td class="text-muted font-mono" style="font-size: 11px;"><%= FormatDisplayDate(rsAssets("created_at")) %></td>
                        <td>
                            <span class="badge <%= IIf(rsAssets("uom") = "MTR", "badge-uom-mtr", "badge-uom-no") %>"><%= HtmlEncode(rsAssets("uom")) %></span>
                        </td>
                        <td style="text-align: right;">
                            <div style="display: flex; gap: 4px; justify-content: flex-end; flex-wrap: wrap;">
                                <a href="asset_details.asp?id=<%= rsAssets("id") %>" class="btn btn-sm btn-secondary">Details</a>
                                <% If curAvail > 0 Then %>
                                <a href="asset_issue.asp?asset_id=<%= rsAssets("id") %>" class="btn btn-sm btn-primary">Use Asset</a>
                                <% End If %>
                                <% If IsAdmin() Then %>
                                <a href="asset_edit.asp?id=<%= rsAssets("id") %>" class="btn btn-sm btn-secondary">Edit</a>
                                <% End If %>
                            </div>
                        </td>
                    </tr>
                    <% rsAssets.MoveNext %>
                    <% Loop %>
                <% End If %>
            </tbody>
        </table>
    </div>

    <!-- Server-side Pagination Toolbar -->
    <div class="pagination-toolbar">
        <div class="pagination-info">
            Showing <strong><%= IIf(totalRecords > 0, offset + 1, 0) %></strong> to <strong><%= IIf(offset + pageSize > totalRecords, totalRecords, offset + pageSize) %></strong> of <strong><%= totalRecords %></strong> entries
        </div>
        <div class="pagination-controls">
            <% If page > 1 Then %>
                <a href="<%= BuildQuery(page - 1) %>" class="page-btn">&laquo;</a>
            <% Else %>
                <button class="page-btn" disabled>&laquo;</button>
            <% End If %>

            <% For p = 1 To totalPages %>
                <% If p = page Then %>
                    <span class="page-btn active"><%= p %></span>
                <% ElseIf p <= 5 Or p = totalPages Or (p >= page - 2 And p <= page + 2) Then %>
                    <a href="<%= BuildQuery(p) %>" class="page-btn"><%= p %></a>
                <% End If %>
            <% Next %>

            <% If page < totalPages Then %>
                <a href="<%= BuildQuery(page + 1) %>" class="page-btn">&raquo;</a>
            <% Else %>
                <button class="page-btn" disabled>&raquo;</button>
            <% End If %>
        </div>
    </div>
</div>

<%
If Not rsAssets Is Nothing Then
    rsAssets.Close
    Set rsAssets = Nothing
End If
CloseDbConnection conn
%>

<!--#include file="includes/footer.asp"-->
