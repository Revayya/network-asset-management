-- ==========================================================
-- Network Asset Management System
-- Database Schema Script
-- Target Database: MySQL 5.5+ / 8.0+ / MariaDB
-- Compatibility: SQLyog Community Edition & MySQL ODBC 5.1 / 8.0
-- ==========================================================

CREATE DATABASE IF NOT EXISTS `network_asset_management`
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE `network_asset_management`;

-- ----------------------------------------------------------
-- 1. Table: users
-- Stores administrative and standard user accounts
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
DROP TABLE IF EXISTS `asset_returns`;
DROP TABLE IF EXISTS `asset_usage`;
DROP TABLE IF EXISTS `assets`;
DROP TABLE IF EXISTS `app_settings`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `role` ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    `department` VARCHAR(100) DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `last_login_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_username` (`username`),
    KEY `idx_users_role` (`role`),
    KEY `idx_users_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 2. Table: assets
-- Stores network hardware and infrastructure assets
-- ----------------------------------------------------------
CREATE TABLE `assets` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `asset_number` VARCHAR(50) NOT NULL,
    `asset_name` VARCHAR(150) NOT NULL,
    `asset_location` VARCHAR(100) NOT NULL,
    `asset_quantity` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `asset_available` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `uom` ENUM('NO', 'MTR') NOT NULL DEFAULT 'NO',
    `created_by` INT NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_assets_asset_number` (`asset_number`),
    KEY `idx_assets_name` (`asset_name`),
    KEY `idx_assets_location` (`asset_location`),
    KEY `idx_assets_created_at` (`created_at`),
    KEY `idx_assets_created_by` (`created_by`),
    CONSTRAINT `fk_assets_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 3. Table: asset_usage
-- Records every asset issuance / checkout transaction
-- ----------------------------------------------------------
CREATE TABLE `asset_usage` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `asset_id` INT NOT NULL,
    `quantity_used` DECIMAL(12,2) NOT NULL,
    `uom` ENUM('NO', 'MTR') NOT NULL,
    `used_by` VARCHAR(100) NOT NULL,
    `department` VARCHAR(100) NOT NULL,
    `short_description` VARCHAR(255) NOT NULL,
    `issued_by_user_id` INT NOT NULL,
    `usage_datetime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_usage_asset_id` (`asset_id`),
    KEY `idx_usage_used_by` (`used_by`),
    KEY `idx_usage_department` (`department`),
    KEY `idx_usage_datetime` (`usage_datetime`),
    KEY `idx_usage_issued_by` (`issued_by_user_id`),
    CONSTRAINT `fk_usage_asset` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_usage_issued_by` FOREIGN KEY (`issued_by_user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 4. Table: asset_returns
-- Records returned stock from previous issuance transactions
-- ----------------------------------------------------------
CREATE TABLE `asset_returns` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `usage_id` INT NOT NULL,
    `asset_id` INT NOT NULL,
    `quantity_returned` DECIMAL(12,2) NOT NULL,
    `returned_by` VARCHAR(100) NOT NULL,
    `received_by_user_id` INT NOT NULL,
    `return_reason` VARCHAR(255) DEFAULT NULL,
    `return_datetime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_returns_usage_id` (`usage_id`),
    KEY `idx_returns_asset_id` (`asset_id`),
    KEY `idx_returns_datetime` (`return_datetime`),
    KEY `idx_returns_received_by` (`received_by_user_id`),
    CONSTRAINT `fk_returns_usage` FOREIGN KEY (`usage_id`) REFERENCES `asset_usage` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_returns_asset` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_returns_received_by` FOREIGN KEY (`received_by_user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 5. Table: audit_logs
-- Immutable security and activity audit trail
-- ----------------------------------------------------------
CREATE TABLE `audit_logs` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `user_id` INT DEFAULT NULL,
    `action` VARCHAR(50) NOT NULL,
    `entity_type` VARCHAR(50) NOT NULL,
    `entity_id` INT DEFAULT NULL,
    `details` TEXT DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_audit_user_id` (`user_id`),
    KEY `idx_audit_action` (`action`),
    KEY `idx_audit_created_at` (`created_at`),
    CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 6. Table: app_settings
-- System-wide application settings and preferences
-- ----------------------------------------------------------
CREATE TABLE `app_settings` (
    `setting_key` VARCHAR(50) NOT NULL,
    `setting_value` VARCHAR(255) NOT NULL,
    `description` VARCHAR(255) DEFAULT NULL,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
