# Network Asset Management System (NetAsset Core)

Enterprise-grade Network Asset Management System built for organizations to manage IT infrastructure, switches, routers, firewalls, optical transceivers, and network cabling stock.

Built using **Classic ASP (VBScript)** running on **Microsoft IIS** backed by **MySQL (SQLyog compatible)** with a responsive, framework-free **HTML5/CSS3/Vanilla JS** user interface.

---

## Key Highlights

- **Real Working Web Application:** Fully functional forms, server-side ASP data processing, live table filtering, real database pagination, and CSV streaming. Zero dummy mockups or incomplete templates.
- **Enterprise Role-Based Access Control (RBAC):** Strict server-side permission enforcement distinguishing **Administrator** and **Standard User** privileges.
- **Atomic Stock Concurrency:** Safe database transactions (`conn.BeginTrans ... conn.CommitTrans`) preventing two operators from consuming the same remaining hardware stock simultaneously.
- **Dual UOM Support:** Full support for discrete equipment (**NO**) and continuous cabling / fiber optics (**MTR**).
- **Security & Integrity:** Cryptographic salted SHA-256 password hashing, parameterized SQL queries against SQL injection, CSRF validation, XSS escaping, and an immutable security audit ledger.
- **Framework-Free Performance:** Pure vanilla CSS and JavaScript with responsive desktop, tablet, and mobile off-canvas drawer navigation.

---

## Directory Structure

```
NetworkAssetManagement/
├── index.asp                   # Gateway routing to dashboard or login
├── login.asp                   # Authentication page
├── logout.asp                  # Secure session termination
├── dashboard.asp               # Main KPI overview & recent activity
├── assets.asp                  # Asset management catalog with filters & pagination
├── asset_add.asp               # Add new asset form & action handler
├── asset_edit.asp              # Edit asset details & stock correction handler
├── asset_details.asp           # Individual asset specs & usage ledger
├── asset_usage.asp             # 13-column asset usage history ledger
├── asset_issue.asp             # Atomic stock issuance & issue form
├── reports.asp                 # Multi-tab analytical reporting suite (Admin only)
├── users.asp                   # User accounts & RBAC management (Admin only)
├── audit_logs.asp              # Security audit trail (Admin only)
├── settings.asp                # Runtime diagnostics & environment info
├── export_csv.asp              # Streaming RFC 4180 CSV export
├── test_db.asp                 # Standalone database connectivity tester
│
├── config/
│   ├── config.asp              # Active database & system configuration
│   └── config.example.asp      # Configuration template with placeholders
│
├── includes/
│   ├── db_connection.asp       # ADODB connection with multi-driver failover
│   ├── crypto.asp              # Salted SHA-256 password hashing & verification
│   ├── common.asp              # Sanitization, audit logger, and CSRF utilities
│   ├── validation.asp          # Server-side input & business rule validators
│   ├── auth.asp                # Session manager & timeout handlers
│   ├── permissions.asp         # Server-side RBAC enforcement
│   ├── header.asp              # Shared layout head, topbar, and sidebar
│   └── footer.asp              # Shared layout footer, modals, and scripts
│
├── css/
│   ├── style.css               # Core design system, tables, modals, toasts
│   ├── dashboard.css           # Sidebar, topbar, KPI cards, filter toolbars
│   └── responsive.css          # Tablet & mobile responsive breakpoints
│
├── js/
│   ├── app.js                  # Modals, toasts, drawer, fetch wrapper
│   ├── assets.js               # Add asset modal helpers & stock auto-sync
│   ├── asset_usage.js          # Issue modal helpers & validation
│   └── filters.js              # Debouncing, pagination, CSV downloads
│
├── database/
│   ├── schema.sql              # Table definitions, foreign keys, constraints
│   ├── indexes.sql             # Performance indexes
│   ├── seed.sql                # Initial users, realistic assets, and usage data
│   └── setup_all.sql           # All-in-one setup script for SQLyog or CLI
│
└── docs/
    ├── INSTALLATION.md         # Step-by-step Windows & IIS installation guide
    ├── DATABASE_SETUP.md       # Relational schema & SQLyog import guide
    ├── IIS_SETUP.md            # IIS configuration & troubleshooting
    ├── USER_GUIDE.md           # End-user & administrator operation guide
    └── TESTING_CHECKLIST.md    # Quality assurance & verification checklist
```

---

## Quick Start Guide

### 1. Database Setup (SQLyog or MySQL CLI)
Execute `database/setup_all.sql` in SQLyog or via MySQL CLI:
```bash
mysql -u root -p < database/setup_all.sql
```

### 2. Configure Credentials
Edit `config/config.asp` to set your MySQL server password and port:
```vbscript
Const DB_SERVER   = "localhost"
Const DB_PORT     = "3306"
Const DB_NAME     = "network_asset_management"
Const DB_USER     = "root"
Const DB_PASSWORD = "YourPasswordHere"
Const DB_DRIVER   = "MySQL ODBC 5.1 Driver"
```

### 3. Deploy in IIS
1. Enable **ASP** in Windows Features under IIS Application Development Features.
2. Enable **Parent Paths**:
   ```cmd
   %windir%\system32\inetsrv\appcmd.exe set config /section:asp /enableParentPaths:True
   ```
3. Create a Website pointing to the project folder on port `8080`.
4. Open your browser:
   - Diagnostic tester: `http://localhost:8080/test_db.asp`
   - Application login: `http://localhost:8080/login.asp`

---

## Initial Accounts

| Role | Username | Initial Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin` | `Admin@12345` | Complete system access, asset management, reports, user accounts, audit trail, settings |
| **Standard User** | `user` | `User@12345` | View inventory, view asset details, issue/pick assets, view usage history |
| **Standard User** | `jdoe` | `User@12345` | View inventory, issue/pick assets, view usage history |
