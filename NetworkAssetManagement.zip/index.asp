<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/auth.asp"-->
<%
' Entry point: Redirect based on authentication state
If IsUserLoggedIn() Then
    Response.Redirect "dashboard.asp"
Else
    Response.Redirect "login.asp"
End If
Response.End
%>
