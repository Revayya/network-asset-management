<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireAdmin()
Dim pageTitle
pageTitle = "Reports & Analytics"

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error: " & g_LastDbError
    Response.End
End If

Dim reportType, fromDate, toDate, dateFilter
reportType = CleanInput(Request.QueryString("report_type"))
If reportType = "" Then reportType = "inventory"
fromDate   = CleanInput(Request.QueryString("from_date"))
toDate     = CleanInput(Request.QueryString("to_date"))

dateFilter = ""
If IsValidDateString(fromDate) Then dateFilter = dateFilter & " AND usage_datetime >= '" & EscapeSql(fromDate) & " 00:00:00' "
If IsValidDateString(toDate) Then dateFilter = dateFilter & " AND usage_datetime <= '" & EscapeSql(toDate) & " 23:59:59' "

Dim reportTitle, sqlReport, rsReport
reportTitle = "Current Network Asset Inventory"

Select Case reportType
    Case "inventory"
        reportTitle = "Current Master Inventory Report"
        sqlReport = "SELECT id, asset_number, asset_name, asset_location, asset_quantity, asset_available, uom, created_at FROM assets ORDER BY asset_number ASC"

    Case "low_stock"
        reportTitle = "Low Stock & Depleted Assets Alert Report"
        sqlReport = "SELECT id, asset_number, asset_name, asset_location, asset_quantity, asset_available, uom FROM assets WHERE asset_available <= 5 ORDER BY asset_available ASC"

    Case "dept_usage"
        reportTitle = "Department-Wise Asset Consumption Breakdown"
        sqlReport = "SELECT department, COUNT(*) AS tx_count, SUM(quantity_used) AS total_qty FROM asset_usage WHERE 1=1 " & dateFilter & " GROUP BY department ORDER BY total_qty DESC"

    Case "employee_usage"
        reportTitle = "Employee-Wise Asset Allocation Report"
        sqlReport = "SELECT used_by, department, COUNT(*) AS tx_count, SUM(quantity_used) AS total_qty FROM asset_usage WHERE 1=1 " & dateFilter & " GROUP BY used_by, department ORDER BY total_qty DESC"

    Case "date_usage"
        reportTitle = "Daily Asset Consumption Timeline"
        sqlReport = "SELECT DATE_FORMAT(usage_datetime, '%Y-%m-%d') AS usage_date, COUNT(*) AS tx_count, SUM(quantity_used) AS total_qty FROM asset_usage WHERE 1=1 " & dateFilter & " GROUP BY DATE_FORMAT(usage_datetime, '%Y-%m-%d') ORDER BY usage_date DESC"

    Case "asset_totals"
        reportTitle = "Asset Lifetime Consumption & Issuance Totals"
        sqlReport = "SELECT a.id, a.asset_number, a.asset_name, a.uom, a.asset_quantity, a.asset_available, COALESCE(SUM(u.quantity_used), 0) AS total_issued " & _
                    "FROM assets a LEFT JOIN asset_usage u ON a.id = u.asset_id GROUP BY a.id, a.asset_number, a.asset_name, a.uom, a.asset_quantity, a.asset_available ORDER BY total_issued DESC"
End Select

Set rsReport = conn.Execute(sqlReport)
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Reports & Inventory Intelligence</h1>
        <p>Comprehensive stock audit reports, department consumption metrics, and asset usage summaries.</p>
    </div>
    <div class="page-header-actions">
        <a href="export_csv.asp?report_type=<%= Server.URLEncode(reportType) %>&from_date=<%= Server.URLEncode(fromDate) %>&to_date=<%= Server.URLEncode(toDate) %>" class="btn btn-primary">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
            <span>Export Active Report to CSV</span>
        </a>
    </div>
</div>

<!-- Report Navigation Tabs -->
<div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px;">
    <a href="reports.asp?report_type=inventory" class="btn <%= IIf(reportType = "inventory", "btn-primary", "btn-secondary") %>">Current Inventory</a>
    <a href="reports.asp?report_type=low_stock" class="btn <%= IIf(reportType = "low_stock", "btn-primary", "btn-secondary") %>">Low Stock Alert</a>
    <a href="reports.asp?report_type=dept_usage" class="btn <%= IIf(reportType = "dept_usage", "btn-primary", "btn-secondary") %>">Department Usage</a>
    <a href="reports.asp?report_type=employee_usage" class="btn <%= IIf(reportType = "employee_usage", "btn-primary", "btn-secondary") %>">Employee Usage</a>
    <a href="reports.asp?report_type=date_usage" class="btn <%= IIf(reportType = "date_usage", "btn-primary", "btn-secondary") %>">Daily Breakdown</a>
    <a href="reports.asp?report_type=asset_totals" class="btn <%= IIf(reportType = "asset_totals", "btn-primary", "btn-secondary") %>">Asset Totals</a>
</div>

<!-- Date Filter Form -->
<form method="GET" action="reports.asp" class="filter-card">
    <input type="hidden" name="report_type" value="<%= HtmlEncode(reportType) %>">
    <div style="display: flex; align-items: flex-end; gap: 14px; flex-wrap: wrap;">
        <div class="form-group" style="margin-bottom: 0;">
            <label for="rf_from" class="form-label" style="font-size: 11px;">FROM DATE</label>
            <input type="date" id="rf_from" name="from_date" class="form-control" value="<%= HtmlEncode(fromDate) %>">
        </div>
        <div class="form-group" style="margin-bottom: 0;">
            <label for="rf_to" class="form-label" style="font-size: 11px;">TO DATE</label>
            <input type="date" id="rf_to" name="to_date" class="form-control" value="<%= HtmlEncode(toDate) %>">
        </div>
        <button type="submit" class="btn btn-primary">Apply Date Filter</button>
        <a href="reports.asp?report_type=<%= Server.URLEncode(reportType) %>" class="btn btn-secondary">Clear Dates</a>
    </div>
</form>

<!-- Report Output Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><%= reportTitle %></h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <% Select Case reportType %>
                <% Case "inventory" %>
                    <thead>
                        <tr>
                            <th>Asset #</th>
                            <th>Asset Name</th>
                            <th>Location</th>
                            <th>Total Quantity</th>
                            <th>Available Stock</th>
                            <th>UOM</th>
                            <th>Added Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% If rsReport.EOF Then %>
                            <tr><td colspan="7" class="empty-state"><p>No assets in database</p></td></tr>
                        <% Else %>
                            <% Do While Not rsReport.EOF %>
                            <tr>
                                <td><strong class="font-mono text-primary"><a href="asset_details.asp?id=<%= rsReport("id") %>"><%= HtmlEncode(rsReport("asset_number")) %></a></strong></td>
                                <td><%= HtmlEncode(rsReport("asset_name")) %></td>
                                <td><%= HtmlEncode(rsReport("asset_location")) %></td>
                                <td><strong><%= FormatDisplayQuantity(rsReport("asset_quantity"), rsReport("uom")) %></strong></td>
                                <td class="font-bold text-success"><%= FormatDisplayQuantity(rsReport("asset_available"), rsReport("uom")) %></td>
                                <td><span class="badge <%= IIf(rsReport("uom") = "MTR", "badge-uom-mtr", "badge-uom-no") %>"><%= HtmlEncode(rsReport("uom")) %></span></td>
                                <td class="text-muted font-mono" style="font-size: 11px;"><%= FormatDisplayDate(rsReport("created_at")) %></td>
                            </tr>
                            <% rsReport.MoveNext %>
                            <% Loop %>
                        <% End If %>
                    </tbody>

                <% Case "low_stock" %>
                    <thead>
                        <tr>
                            <th>Asset #</th>
                            <th>Asset Name</th>
                            <th>Location</th>
                            <th>Total Quantity</th>
                            <th>Available Stock</th>
                            <th>Status Alert</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% If rsReport.EOF Then %>
                            <tr><td colspan="6" class="empty-state text-success"><p>All assets currently have healthy stock levels!</p></td></tr>
                        <% Else %>
                            <% Do While Not rsReport.EOF %>
                            <% Dim av: av = CDbl(rsReport("asset_available")) %>
                            <tr>
                                <td><strong class="font-mono text-danger"><a href="asset_details.asp?id=<%= rsReport("id") %>"><%= HtmlEncode(rsReport("asset_number")) %></a></strong></td>
                                <td><%= HtmlEncode(rsReport("asset_name")) %></td>
                                <td><%= HtmlEncode(rsReport("asset_location")) %></td>
                                <td><%= FormatDisplayQuantity(rsReport("asset_quantity"), rsReport("uom")) %></td>
                                <td class="font-bold text-danger"><%= FormatDisplayQuantity(av, rsReport("uom")) %></td>
                                <td>
                                    <% If av <= 0 Then %>
                                        <span class="badge badge-stock-out">Depleted (0)</span>
                                    <% Else %>
                                        <span class="badge badge-stock-low">Low Stock (<= 5)</span>
                                    <% End If %>
                                </td>
                            </tr>
                            <% rsReport.MoveNext %>
                            <% Loop %>
                        <% End If %>
                    </tbody>

                <% Case "dept_usage" %>
                    <thead>
                        <tr>
                            <th>Department</th>
                            <th>Transaction Count</th>
                            <th>Total Quantity Consumed</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% If rsReport.EOF Then %>
                            <tr><td colspan="3" class="empty-state"><p>No usage recorded in selected period</p></td></tr>
                        <% Else %>
                            <% Dim dTxTotal, dQtyTotal: dTxTotal = 0: dQtyTotal = 0 %>
                            <% Do While Not rsReport.EOF %>
                            <% dTxTotal = dTxTotal + CLng(rsReport("tx_count")): dQtyTotal = dQtyTotal + CDbl(rsReport("total_qty")) %>
                            <tr>
                                <td><strong><%= HtmlEncode(rsReport("department")) %></strong></td>
                                <td><span class="badge" style="background:#e0f2fe; color:#0369a1;"><%= rsReport("tx_count") %> transactions</span></td>
                                <td class="text-primary font-bold"><%= rsReport("total_qty") %></td>
                            </tr>
                            <% rsReport.MoveNext %>
                            <% Loop %>
                            <tr style="background:#f8fafc; font-weight:700;">
                                <td>Total</td>
                                <td><%= dTxTotal %> transactions</td>
                                <td class="text-primary"><%= dQtyTotal %></td>
                            </tr>
                        <% End If %>
                    </tbody>

                <% Case "employee_usage" %>
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Department</th>
                            <th>Transactions</th>
                            <th>Total Quantity Issued</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% If rsReport.EOF Then %>
                            <tr><td colspan="4" class="empty-state"><p>No employee allocations recorded in selected period</p></td></tr>
                        <% Else %>
                            <% Do While Not rsReport.EOF %>
                            <tr>
                                <td><strong><%= HtmlEncode(rsReport("used_by")) %></strong></td>
                                <td><%= HtmlEncode(rsReport("department")) %></td>
                                <td><%= rsReport("tx_count") %></td>
                                <td class="text-primary font-bold"><%= rsReport("total_qty") %></td>
                            </tr>
                            <% rsReport.MoveNext %>
                            <% Loop %>
                        <% End If %>
                    </tbody>

                <% Case "date_usage" %>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Transactions Count</th>
                            <th>Total Quantity Issued</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% If rsReport.EOF Then %>
                            <tr><td colspan="3" class="empty-state"><p>No usage recorded in selected period</p></td></tr>
                        <% Else %>
                            <% Do While Not rsReport.EOF %>
                            <tr>
                                <td class="font-mono font-bold"><%= HtmlEncode(rsReport("usage_date")) %></td>
                                <td><%= rsReport("tx_count") %> transactions</td>
                                <td class="text-primary font-bold"><%= rsReport("total_qty") %></td>
                            </tr>
                            <% rsReport.MoveNext %>
                            <% Loop %>
                        <% End If %>
                    </tbody>

                <% Case "asset_totals" %>
                    <thead>
                        <tr>
                            <th>Asset #</th>
                            <th>Asset Name</th>
                            <th>Total Catalog Qty</th>
                            <th>Available Stock</th>
                            <th>Historical Issued Qty</th>
                            <th>UOM</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% If rsReport.EOF Then %>
                            <tr><td colspan="6" class="empty-state"><p>No asset transactions found</p></td></tr>
                        <% Else %>
                            <% Do While Not rsReport.EOF %>
                            <tr>
                                <td><strong class="font-mono text-primary"><a href="asset_details.asp?id=<%= rsReport("id") %>"><%= HtmlEncode(rsReport("asset_number")) %></a></strong></td>
                                <td><%= HtmlEncode(rsReport("asset_name")) %></td>
                                <td><%= FormatDisplayQuantity(rsReport("asset_quantity"), rsReport("uom")) %></td>
                                <td class="text-success font-bold"><%= FormatDisplayQuantity(rsReport("asset_available"), rsReport("uom")) %></td>
                                <td class="text-danger font-bold"><%= rsReport("total_issued") %></td>
                                <td><span class="badge <%= IIf(rsReport("uom") = "MTR", "badge-uom-mtr", "badge-uom-no") %>"><%= HtmlEncode(rsReport("uom")) %></span></td>
                            </tr>
                            <% rsReport.MoveNext %>
                            <% Loop %>
                        <% End If %>
                    </tbody>
            <% End Select %>
        </table>
    </div>
</div>

<%
rsReport.Close
Set rsReport = Nothing
CloseDbConnection conn
%>

<!--#include file="includes/footer.asp"-->
