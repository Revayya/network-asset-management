<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/auth.asp"-->
<%
' Terminate user session and record audit event
If IsUserLoggedIn() Then
    Dim conn
    Set conn = GetDbConnection()
    If Not conn Is Nothing Then
        LogAudit conn, GetAuthUserId(), "USER_LOGOUT", "AUTH", GetAuthUserId(), "User logged out"
        CloseDbConnection conn
    End If
    PerformLogout()
End If

Response.Redirect "login.asp?msg=logged_out"
Response.End
%>
