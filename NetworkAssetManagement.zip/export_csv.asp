<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
' Streaming RFC 4180-compliant CSV Export
Response.Clear
Response.Buffer = True

RequireLogin()

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error."
    Response.End
End If

On Error Resume Next

Dim exportType, filename
exportType = CleanInput(Request.QueryString("report_type"))
If exportType = "" Then exportType = "usage_history"

filename = exportType & "_" & Year(Now()) & Right("0" & Month(Now()), 2) & Right("0" & Day(Now()), 2) & ".csv"

Response.ContentType = "text/csv; charset=utf-8"
Response.AddHeader "Content-Disposition", "attachment; filename=""" & filename & """"

Function EscapeCsvCell(val)
    If IsNull(val) Or IsEmpty(val) Then
        EscapeCsvCell = """" & """"
        Exit Function
    End If
    Dim s
    s = CStr(val)
    s = Replace(s, """", """""")
    EscapeCsvCell = """" & s & """"
End Function

Select Case exportType
    Case "assets", "inventory"
        Dim qNum, qName, qLoc, qUom, qStock, whereAssets
        qNum   = CleanInput(Request.QueryString("asset_number"))
        qName  = CleanInput(Request.QueryString("asset_name"))
        qLoc   = CleanInput(Request.QueryString("location"))
        qUom   = UCase(CleanInput(Request.QueryString("uom")))
        qStock = CleanInput(Request.QueryString("stock_status"))
        
        whereAssets = " WHERE 1=1 "
        If qNum <> "" Then whereAssets = whereAssets & " AND asset_number LIKE '%" & EscapeSql(qNum) & "%' "
        If qName <> "" Then whereAssets = whereAssets & " AND asset_name LIKE '%" & EscapeSql(qName) & "%' "
        If qLoc <> "" Then whereAssets = whereAssets & " AND asset_location = '" & EscapeSql(qLoc) & "' "
        If qUom = "NO" Or qUom = "MTR" Then whereAssets = whereAssets & " AND uom = '" & EscapeSql(qUom) & "' "
        If qStock = "in_stock" Then whereAssets = whereAssets & " AND asset_available > 0 "
        If qStock = "out_of_stock" Then whereAssets = whereAssets & " AND asset_available <= 0 "
        
        Response.Write "Asset ID,Asset Number,Asset Name,Location,Total Quantity,Available Quantity,UOM,Added Date" & vbCrLf
        
        Dim rsA
        Set rsA = conn.Execute("SELECT id, asset_number, asset_name, asset_location, asset_quantity, asset_available, uom, created_at FROM assets " & whereAssets & " ORDER BY id DESC")
        Do While Not rsA.EOF
            Response.Write EscapeCsvCell(rsA("id")) & "," & _
                           EscapeCsvCell(rsA("asset_number")) & "," & _
                           EscapeCsvCell(rsA("asset_name")) & "," & _
                           EscapeCsvCell(rsA("asset_location")) & "," & _
                           EscapeCsvCell(rsA("asset_quantity")) & "," & _
                           EscapeCsvCell(rsA("asset_available")) & "," & _
                           EscapeCsvCell(rsA("uom")) & "," & _
                           EscapeCsvCell(rsA("created_at")) & vbCrLf
            rsA.MoveNext
        Loop
        rsA.Close
        Set rsA = Nothing

    Case "usage_history"
        Dim qAsset, qUser, qDept, qLocU, qUomU, qFromU, qToU, whereUsage
        qAsset = CleanInput(Request.QueryString("asset_query"))
        qUser  = CleanInput(Request.QueryString("used_by"))
        qDept  = CleanInput(Request.QueryString("department"))
        qLocU  = CleanInput(Request.QueryString("location"))
        qUomU  = UCase(CleanInput(Request.QueryString("uom")))
        qFromU = CleanInput(Request.QueryString("from_date"))
        qToU   = CleanInput(Request.QueryString("to_date"))

        whereUsage = " WHERE 1=1 "
        If qAsset <> "" Then whereUsage = whereUsage & " AND (a.asset_number LIKE '%" & EscapeSql(qAsset) & "%' OR a.asset_name LIKE '%" & EscapeSql(qAsset) & "%') "
        If qUser <> "" Then whereUsage = whereUsage & " AND u.used_by LIKE '%" & EscapeSql(qUser) & "%' "
        If qDept <> "" Then whereUsage = whereUsage & " AND u.department = '" & EscapeSql(qDept) & "' "
        If qLocU <> "" Then whereUsage = whereUsage & " AND a.asset_location = '" & EscapeSql(qLocU) & "' "
        If qUomU = "NO" Or qUomU = "MTR" Then whereUsage = whereUsage & " AND u.uom = '" & EscapeSql(qUomU) & "' "
        If IsValidDateString(qFromU) Then whereUsage = whereUsage & " AND u.usage_datetime >= '" & EscapeSql(qFromU) & " 00:00:00' "
        If IsValidDateString(qToU) Then whereUsage = whereUsage & " AND u.usage_datetime <= '" & EscapeSql(qToU) & " 23:59:59' "

        Response.Write "Transaction ID,Asset ID,Asset Number,Asset Name,Location,Total Asset Qty,Available Qty,Quantity Used,UOM,Used By,Department,Usage Datetime,Description" & vbCrLf

        Dim rsU
        Set rsU = conn.Execute("SELECT u.id, u.asset_id, a.asset_number, a.asset_name, a.asset_location, " & _
                               "a.asset_quantity, a.asset_available, u.quantity_used, u.uom, " & _
                               "u.used_by, u.department, u.usage_datetime, u.short_description " & _
                               "FROM asset_usage u JOIN assets a ON u.asset_id = a.id " & whereUsage & " ORDER BY u.id DESC")
        Do While Not rsU.EOF
            Response.Write EscapeCsvCell(rsU("id")) & "," & _
                           EscapeCsvCell(rsU("asset_id")) & "," & _
                           EscapeCsvCell(rsU("asset_number")) & "," & _
                           EscapeCsvCell(rsU("asset_name")) & "," & _
                           EscapeCsvCell(rsU("asset_location")) & "," & _
                           EscapeCsvCell(rsU("asset_quantity")) & "," & _
                           EscapeCsvCell(rsU("asset_available")) & "," & _
                           EscapeCsvCell(rsU("quantity_used")) & "," & _
                           EscapeCsvCell(rsU("uom")) & "," & _
                           EscapeCsvCell(rsU("used_by")) & "," & _
                           EscapeCsvCell(rsU("department")) & "," & _
                           EscapeCsvCell(rsU("usage_datetime")) & "," & _
                           EscapeCsvCell(rsU("short_description")) & vbCrLf
            rsU.MoveNext
        Loop
        rsU.Close
        Set rsU = Nothing

    Case "low_stock"
        Response.Write "Asset ID,Asset Number,Asset Name,Location,Total Quantity,Available Stock,UOM" & vbCrLf
        Dim rsLS
        Set rsLS = conn.Execute("SELECT id, asset_number, asset_name, asset_location, asset_quantity, asset_available, uom FROM assets WHERE asset_available <= 5 ORDER BY asset_available ASC")
        Do While Not rsLS.EOF
            Response.Write EscapeCsvCell(rsLS("id")) & "," & _
                           EscapeCsvCell(rsLS("asset_number")) & "," & _
                           EscapeCsvCell(rsLS("asset_name")) & "," & _
                           EscapeCsvCell(rsLS("asset_location")) & "," & _
                           EscapeCsvCell(rsLS("asset_quantity")) & "," & _
                           EscapeCsvCell(rsLS("asset_available")) & "," & _
                           EscapeCsvCell(rsLS("uom")) & vbCrLf
            rsLS.MoveNext
        Loop
        rsLS.Close
        Set rsLS = Nothing

    Case "dept_usage"
        Response.Write "Department,Transactions Count,Total Quantity Consumed" & vbCrLf
        Dim rsDU
        Set rsDU = conn.Execute("SELECT department, COUNT(*) AS tx_count, SUM(quantity_used) AS total_qty FROM asset_usage GROUP BY department ORDER BY total_qty DESC")
        Do While Not rsDU.EOF
            Response.Write EscapeCsvCell(rsDU("department")) & "," & _
                           EscapeCsvCell(rsDU("tx_count")) & "," & _
                           EscapeCsvCell(rsDU("total_qty")) & vbCrLf
            rsDU.MoveNext
        Loop
        rsDU.Close
        Set rsDU = Nothing

    Case Else
        Response.Write "Export format not supported."
End Select

CloseDbConnection conn
Response.End
%>
