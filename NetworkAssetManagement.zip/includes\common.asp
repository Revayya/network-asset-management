<%
' ===================================================================
' Network Asset Management System
' Common Functions, Audit Logger, Security Utilities (common.asp)
' ===================================================================

Function HtmlEncode(val)
    If IsNull(val) Or IsEmpty(val) Then
        HtmlEncode = ""
    Else
        HtmlEncode = Server.HTMLEncode(CStr(val))
    End If
End Function

Function FormatDisplayDate(dtVal)
    If IsNull(dtVal) Or IsEmpty(dtVal) Or Not IsDate(dtVal) Then
        FormatDisplayDate = "-"
        Exit Function
    End If
    Dim d
    d = CDate(dtVal)
    FormatDisplayDate = Year(d) & "-" & _
                        Right("0" & Month(d), 2) & "-" & _
                        Right("0" & Day(d), 2) & " " & _
                        Right("0" & Hour(d), 2) & ":" & _
                        Right("0" & Minute(d), 2) & ":" & _
                        Right("0" & Second(d), 2)
End Function

Function FormatDisplayQuantity(qty, uom)
    If IsNull(qty) Or Not IsNumeric(qty) Then
        FormatDisplayQuantity = "0 " & uom
        Exit Function
    End If
    Dim q
    q = CDbl(qty)
    If UCase(Trim(uom)) = "NO" Then
        ' Display whole numbers cleanly for NO
        If q = Fix(q) Then
            FormatDisplayQuantity = FormatNumber(q, 0, , , True) & " NO"
        Else
            FormatDisplayQuantity = FormatNumber(q, 2, , , True) & " NO"
        End If
    Else
        FormatDisplayQuantity = FormatNumber(q, 2, , , True) & " MTR"
    End If
End Function

Function GetClientIp()
    Dim ip
    ip = Request.ServerVariables("HTTP_X_FORWARDED_FOR")
    If ip = "" Then
        ip = Request.ServerVariables("REMOTE_ADDR")
    End If
    If ip = "" Then ip = "127.0.0.1"
    GetClientIp = Left(ip, 45)
End Function

Function GetCsrfToken()
    If Session("CSRF_TOKEN") = "" Then
        Dim chars, token, i, idx
        chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        token = ""
        Randomize
        For i = 1 To 32
            idx = Int(Rnd * Len(chars)) + 1
            token = token & Mid(chars, idx, 1)
        Next
        Session("CSRF_TOKEN") = token
    End If
    GetCsrfToken = Session("CSRF_TOKEN")
End Function

Function VerifyCsrfToken(submittedToken)
    Dim expected
    expected = Session("CSRF_TOKEN")
    If expected <> "" And submittedToken <> "" And expected = submittedToken Then
        VerifyCsrfToken = True
    Else
        VerifyCsrfToken = False
    End If
End Function

Sub LogAudit(conn, userId, action, entityType, entityId, details)
    On Error Resume Next
    If conn Is Nothing Then Exit Sub
    If conn.State <> 1 Then Exit Sub
    
    Dim cmd, ip
    ip = GetClientIp()
    
    Set cmd = Server.CreateObject("ADODB.Command")
    Set cmd.ActiveConnection = conn
    cmd.CommandText = "INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address, created_at) " & _
                      "VALUES (?, ?, ?, ?, ?, ?, NOW())"
    cmd.CommandType = 1 ' adCmdText
    
    ' Parameter types: 3 = adInteger, 200 = adVarChar, 201 = adLongVarChar
    If IsNull(userId) Or userId = "" Or Not IsNumeric(userId) Then
        cmd.Parameters.Append cmd.CreateParameter("p_user_id", 3, 1, , Null)
    Else
        cmd.Parameters.Append cmd.CreateParameter("p_user_id", 3, 1, , CLng(userId))
    End If
    
    cmd.Parameters.Append cmd.CreateParameter("p_action", 200, 1, 50, Left(CStr(action), 50))
    cmd.Parameters.Append cmd.CreateParameter("p_entity_type", 200, 1, 50, Left(CStr(entityType), 50))
    
    If IsNull(entityId) Or entityId = "" Or Not IsNumeric(entityId) Then
        cmd.Parameters.Append cmd.CreateParameter("p_entity_id", 3, 1, , Null)
    Else
        cmd.Parameters.Append cmd.CreateParameter("p_entity_id", 3, 1, , CLng(entityId))
    End If
    
    cmd.Parameters.Append cmd.CreateParameter("p_details", 200, 1, 1000, Left(CStr(details), 1000))
    cmd.Parameters.Append cmd.CreateParameter("p_ip", 200, 1, 45, ip)
    
    cmd.Execute
    Set cmd = Nothing
    On Error GoTo 0
End Sub

' Reads the raw request body as a UTF-8 text string (for JSON payloads)
Function ReadRequestBody()
    On Error Resume Next
    Dim byteCount, stm
    byteCount = Request.TotalBytes
    If byteCount <= 0 Then
        ReadRequestBody = ""
        Exit Function
    End If
    
    Set stm = Server.CreateObject("ADODB.Stream")
    stm.Type = 1 ' adTypeBinary
    stm.Open
    stm.Write Request.BinaryRead(byteCount)
    stm.Position = 0
    stm.Type = 2 ' adTypeText
    stm.Charset = "utf-8"
    ReadRequestBody = stm.ReadText
    stm.Close
    Set stm = Nothing
    If Err.Number <> 0 Then
        Err.Clear
        ReadRequestBody = ""
    End If
    On Error GoTo 0
End Function

' Extracts a value from a simple JSON string by key name
Function GetJsonValue(jsonStr, keyName)
    GetJsonValue = ""
    If jsonStr = "" Then Exit Function
    
    Dim posKey, posColon, posStart, posEnd, ch
    posKey = InStr(1, jsonStr, """" & keyName & """", 1)
    If posKey = 0 Then Exit Function
    
    posColon = InStr(posKey + Len(keyName) + 2, jsonStr, ":")
    If posColon = 0 Then Exit Function
    
    posStart = posColon + 1
    Do While posStart <= Len(jsonStr) And (Mid(jsonStr, posStart, 1) = " " Or Mid(jsonStr, posStart, 1) = vbTab Or Mid(jsonStr, posStart, 1) = vbCr Or Mid(jsonStr, posStart, 1) = vbLf)
        posStart = posStart + 1
    Loop
    If posStart > Len(jsonStr) Then Exit Function
    
    ch = Mid(jsonStr, posStart, 1)
    If ch = """" Then
        posStart = posStart + 1
        posEnd = InStr(posStart, jsonStr, """")
        Do While posEnd > 0 And Mid(jsonStr, posEnd - 1, 1) = "\"
            posEnd = InStr(posEnd + 1, jsonStr, """")
        Loop
        If posEnd > 0 Then
            GetJsonValue = Replace(Mid(jsonStr, posStart, posEnd - posStart), "\""", """")
        End If
    Else
        posEnd = posStart
        Do While posEnd <= Len(jsonStr)
            ch = Mid(jsonStr, posEnd, 1)
            If ch = "," Or ch = "}" Or ch = "]" Or ch = " " Or ch = vbCr Or ch = vbLf Then
                Exit Do
            End If
            posEnd = posEnd + 1
        Loop
        GetJsonValue = Trim(Mid(jsonStr, posStart, posEnd - posStart))
    End If
End Function

' Unifies parameter retrieval from JSON body, Form POST, or QueryString
Function GetRequestField(fieldName, jsonBody)
    Dim val
    If jsonBody <> "" Then
        val = GetJsonValue(jsonBody, fieldName)
    End If
    If val = "" Then
        val = Request.Form(fieldName)
    End If
    If val = "" Then
        val = Request.QueryString(fieldName)
    End If
    GetRequestField = CleanInput(val)
End Function
%>
