/**
 * Network Asset Management System
 * Core Application Framework (app.js)
 * Vanilla JavaScript - Zero framework dependencies
 */

document.addEventListener('DOMContentLoaded', function() {
    initSidebar();
});

/**
 * Mobile sidebar drawer toggle
 */
function initSidebar() {
    const toggleBtn = document.getElementById('sidebarToggleBtn');
    const closeBtn = document.getElementById('sidebarCloseBtn');
    const sidebar = document.getElementById('appSidebar');
    const backdrop = document.getElementById('sidebarBackdrop');

    if (toggleBtn && sidebar && backdrop) {
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.add('open');
            backdrop.classList.add('active');
        });
    }

    function closeSidebar() {
        if (sidebar) sidebar.classList.remove('open');
        if (backdrop) backdrop.classList.remove('active');
    }

    if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
    if (backdrop) backdrop.addEventListener('click', closeSidebar);
}

/**
 * Toast Notification System
 * @param {string} message 
 * @param {'success'|'error'|'warning'|'info'} type 
 * @param {number} duration 
 */
function showToast(message, type = 'info', duration = 4000) {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let iconSvg = '';
    if (type === 'success') {
        iconSvg = '<svg viewBox="0 0 24 24" width="20" height="20" stroke="#10b981" stroke-width="2" fill="none"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';
    } else if (type === 'error') {
        iconSvg = '<svg viewBox="0 0 24 24" width="20" height="20" stroke="#ef4444" stroke-width="2" fill="none"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>';
    } else if (type === 'warning') {
        iconSvg = '<svg viewBox="0 0 24 24" width="20" height="20" stroke="#f59e0b" stroke-width="2" fill="none"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
    } else {
        iconSvg = '<svg viewBox="0 0 24 24" width="20" height="20" stroke="#2563eb" stroke-width="2" fill="none"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';
    }

    toast.innerHTML = `
        <div class="toast-icon">${iconSvg}</div>
        <div class="toast-content">${escapeHtml(message)}</div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

/**
 * Modal Management
 */
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        // force reflow
        void modal.offsetWidth;
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }, 200);
    }
}

// Global modal backdrop close listener
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        closeModal(e.target.id);
    }
});

// ESC key closes top modal
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const activeModals = document.querySelectorAll('.modal-overlay.active');
        if (activeModals.length > 0) {
            closeModal(activeModals[activeModals.length - 1].id);
        }
    }
});

/**
 * Global Confirmation Dialog
 */
let confirmCallback = null;

function showConfirmDialog(title, message, onConfirm) {
    const modal = document.getElementById('confirmModal');
    const titleEl = document.getElementById('confirmModalTitle');
    const bodyEl = document.getElementById('confirmModalBody');
    const btnEl = document.getElementById('confirmModalBtn');

    if (!modal) {
        if (confirm(message)) onConfirm();
        return;
    }

    titleEl.textContent = title || 'Confirm Action';
    bodyEl.textContent = message;
    confirmCallback = onConfirm;

    btnEl.onclick = function() {
        closeConfirmModal();
        if (typeof confirmCallback === 'function') {
            confirmCallback();
        }
    };

    openModal('confirmModal');
}

function closeConfirmModal() {
    closeModal('confirmModal');
    confirmCallback = null;
}

/**
 * Universal API Fetch Wrapper with CSRF and error management
 */
async function apiFetch(url, options = {}) {
    const csrfToken = window.NAM_CONFIG ? window.NAM_CONFIG.csrfToken : '';
    const headers = options.headers || {};

    if (!headers['X-CSRF-Token']) {
        headers['X-CSRF-Token'] = csrfToken;
    }
    if (!headers['Accept']) {
        headers['Accept'] = 'application/json';
    }

    options.headers = headers;
    options.credentials = 'same-origin';

    try {
        const response = await fetch(url, options);
        
        if (response.status === 401) {
            showToast('Session expired. Redirecting to login...', 'error');
            setTimeout(() => {
                window.location.href = 'login.asp?msg=session_expired';
            }, 1500);
            return { success: false, message: 'Session expired' };
        }

        const data = await response.json();
        return data;
    } catch (err) {
        console.error('Fetch error:', err);
        return {
            success: false,
            message: 'Network or server communication error. Please try again.'
        };
    }
}

/**
 * String HTML escape helper
 */
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

/**
 * Format quantity with Unit of Measurement
 */
function formatQtyUom(qty, uom) {
    const val = parseFloat(qty) || 0;
    if (String(uom).toUpperCase() === 'NO') {
        return Math.floor(val) === val ? `${Math.floor(val)} NO` : `${val.toFixed(2)} NO`;
    }
    return `${val.toFixed(2)} MTR`;
}
