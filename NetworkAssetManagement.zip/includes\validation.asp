<%
' ===================================================================
' Network Asset Management System
' Server-Side Input Validation and Sanitization (validation.asp)
' ===================================================================

Function CleanInput(val)
    If IsNull(val) Or IsEmpty(val) Then
        CleanInput = ""
    Else
        Dim s
        s = Trim(CStr(val))
        ' Strip null bytes
        s = Replace(s, Chr(0), "")
        CleanInput = s
    End If
End Function

Function IsValidUOM(uom)
    Dim u
    u = UCase(Trim(uom))
    If u = "NO" Or u = "MTR" Then
        IsValidUOM = True
    Else
        IsValidUOM = False
    End If
End Function

Function IsValidNumber(val, allowZero)
    IsValidNumber = False
    If Not IsNumeric(val) Then Exit Function
    Dim num
    num = CDbl(val)
    If allowZero Then
        If num >= 0 Then IsValidNumber = True
    Else
        If num > 0 Then IsValidNumber = True
    End If
End Function

Function IsValidDateString(dateStr)
    IsValidDateString = False
    If CleanInput(dateStr) = "" Then Exit Function
    
    On Error Resume Next
    Dim d
    d = CDate(dateStr)
    If Err.Number = 0 Then
        ' Also check reasonable 4-digit year range
        If Year(d) >= 1990 And Year(d) <= 2099 Then
            IsValidDateString = True
        End If
    End If
    On Error GoTo 0
End Function

Function IsValidUsername(username)
    IsValidUsername = False
    Dim u, i, ch, asciiCode
    u = CleanInput(username)
    If Len(u) < 3 Or Len(u) > 50 Then Exit Function
    
    ' Allow alphanumeric, underscore, dot, hyphen
    For i = 1 To Len(u)
        ch = Mid(u, i, 1)
        asciiCode = Asc(ch)
        If Not ((asciiCode >= 48 And asciiCode <= 57) Or _
                (asciiCode >= 65 And asciiCode <= 90) Or _
                (asciiCode >= 97 And asciiCode <= 122) Or _
                ch = "_" Or ch = "." Or ch = "-") Then
            Exit Function
        End If
    Next
    IsValidUsername = True
End Function
%>
