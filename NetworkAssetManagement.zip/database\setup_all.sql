-- ==========================================================
-- Network Asset Management System
-- Combined All-In-One Database Setup Script
-- Executes Schema, Indexes, and Seed Data in Order
-- Run in SQLyog, MySQL Workbench, or mysql CLI:
--   mysql -u root -p < setup_all.sql
-- ==========================================================

CREATE DATABASE IF NOT EXISTS `network_asset_management`
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE `network_asset_management`;

SET FOREIGN_KEY_CHECKS = 0;

-- Drop existing tables
DROP TABLE IF EXISTS `audit_logs`;
DROP TABLE IF EXISTS `asset_returns`;
DROP TABLE IF EXISTS `asset_usage`;
DROP TABLE IF EXISTS `assets`;
DROP TABLE IF EXISTS `app_settings`;
DROP TABLE IF EXISTS `users`;

SET FOREIGN_KEY_CHECKS = 1;

-- 1. Create Tables
CREATE TABLE `users` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `role` ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    `department` VARCHAR(100) DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `last_login_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_username` (`username`),
    KEY `idx_users_role` (`role`),
    KEY `idx_users_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `assets` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `asset_number` VARCHAR(50) NOT NULL,
    `asset_name` VARCHAR(150) NOT NULL,
    `asset_location` VARCHAR(100) NOT NULL,
    `asset_quantity` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `asset_available` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `uom` ENUM('NO', 'MTR') NOT NULL DEFAULT 'NO',
    `created_by` INT NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_assets_asset_number` (`asset_number`),
    KEY `idx_assets_name` (`asset_name`),
    KEY `idx_assets_location` (`asset_location`),
    KEY `idx_assets_created_at` (`created_at`),
    KEY `idx_assets_created_by` (`created_by`),
    CONSTRAINT `fk_assets_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `asset_usage` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `asset_id` INT NOT NULL,
    `quantity_used` DECIMAL(12,2) NOT NULL,
    `uom` ENUM('NO', 'MTR') NOT NULL,
    `used_by` VARCHAR(100) NOT NULL,
    `department` VARCHAR(100) NOT NULL,
    `short_description` VARCHAR(255) NOT NULL,
    `issued_by_user_id` INT NOT NULL,
    `usage_datetime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_usage_asset_id` (`asset_id`),
    KEY `idx_usage_used_by` (`used_by`),
    KEY `idx_usage_department` (`department`),
    KEY `idx_usage_datetime` (`usage_datetime`),
    KEY `idx_usage_issued_by` (`issued_by_user_id`),
    CONSTRAINT `fk_usage_asset` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_usage_issued_by` FOREIGN KEY (`issued_by_user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `asset_returns` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `usage_id` INT NOT NULL,
    `asset_id` INT NOT NULL,
    `quantity_returned` DECIMAL(12,2) NOT NULL,
    `returned_by` VARCHAR(100) NOT NULL,
    `received_by_user_id` INT NOT NULL,
    `return_reason` VARCHAR(255) DEFAULT NULL,
    `return_datetime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_returns_usage_id` (`usage_id`),
    KEY `idx_returns_asset_id` (`asset_id`),
    KEY `idx_returns_datetime` (`return_datetime`),
    KEY `idx_returns_received_by` (`received_by_user_id`),
    CONSTRAINT `fk_returns_usage` FOREIGN KEY (`usage_id`) REFERENCES `asset_usage` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_returns_asset` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_returns_received_by` FOREIGN KEY (`received_by_user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `audit_logs` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `user_id` INT DEFAULT NULL,
    `action` VARCHAR(50) NOT NULL,
    `entity_type` VARCHAR(50) NOT NULL,
    `entity_id` INT DEFAULT NULL,
    `details` TEXT DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_audit_user_id` (`user_id`),
    KEY `idx_audit_action` (`action`),
    KEY `idx_audit_created_at` (`created_at`),
    CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `app_settings` (
    `setting_key` VARCHAR(50) NOT NULL,
    `setting_value` VARCHAR(255) NOT NULL,
    `description` VARCHAR(255) DEFAULT NULL,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Insert Initial Seed Data
INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `role`, `department`, `is_active`, `created_at`) VALUES
(1, 'admin', 'e4f8b9c1d2e3f4a5b6c7d8e9f0a1b2c3$064305e47457dea469d4c13318be20eeb724edd232a88557c561adbcb2597913', 'System Administrator', 'admin', 'IT Infrastructure', 1, NOW()),
(2, 'user',  'a1b2c3d4e5f60718293a4b5c6d7e8f90$7ba8fc359b0b3eb48076bcbdcb49a4dce8611890373ca85773fe82589fe900ec', 'Network Technician',   'user',  'Network Operations', 1, NOW()),
(3, 'jdoe',  'a1b2c3d4e5f60718293a4b5c6d7e8f90$7ba8fc359b0b3eb48076bcbdcb49a4dce8611890373ca85773fe82589fe900ec', 'John Doe',             'user',  'Security Operations', 1, NOW());

INSERT INTO `assets` (`id`, `asset_number`, `asset_name`, `asset_location`, `asset_quantity`, `asset_available`, `uom`, `created_by`, `created_at`) VALUES
(1, 'NET-SW-9300',  'Cisco Catalyst 9300 48-Port PoE+ Switch', 'Server Room Rack A1',  10.00,  7.00, 'NO',  1, NOW() - INTERVAL 10 DAY),
(2, 'NET-RT-4451',  'Cisco ISR 4451 Integrated Router',        'Data Center Rack B2',   5.00,  4.00, 'NO',  1, NOW() - INTERVAL 9 DAY),
(3, 'NET-FW-P600',  'Fortinet FortiGate 600E Next-Gen Firewall','Core Rack C1',          4.00,  4.00, 'NO',  1, NOW() - INTERVAL 8 DAY),
(4, 'NET-AP-9130',  'Cisco Catalyst 9130AX Series Wi-Fi 6 AP', 'IT Warehouse Shelf 3', 30.00, 22.00, 'NO',  1, NOW() - INTERVAL 7 DAY),
(5, 'NET-SFP-10G',  '10GBASE-SR SFP+ Optical Transceiver',     'Accessories Cabinet 2', 50.00, 38.00, 'NO',  1, NOW() - INTERVAL 6 DAY),
(6, 'NET-CAB-C6U',  'Cat6 UTP Solid Bare Copper Bulk Cable',   'Cable Storage Bay 1', 1000.00, 650.00, 'MTR', 1, NOW() - INTERVAL 5 DAY),
(7, 'NET-CAB-SMF',  'Single-Mode OS2 12-Core Fiber Optic Cable','Cable Storage Bay 2',  500.00, 320.00, 'MTR', 1, NOW() - INTERVAL 4 DAY),
(8, 'NET-PP-48P',   'Cat6 48-Port 1U Loaded Patch Panel',      'Server Room Rack A2',  12.00, 10.00, 'NO',  1, NOW() - INTERVAL 3 DAY),
(9, 'NET-PDU-30A',  'APC Switched Rack PDU 30A 208V',          'Data Center Rack B1',   8.00,  8.00, 'NO',  1, NOW() - INTERVAL 2 DAY),
(10,'NET-CONSOLE',  'Opengear 16-Port Terminal Server',        'Management Rack M1',    3.00,  3.00, 'NO',  1, NOW() - INTERVAL 1 DAY);

INSERT INTO `asset_usage` (`id`, `asset_id`, `quantity_used`, `uom`, `used_by`, `department`, `short_description`, `issued_by_user_id`, `usage_datetime`, `created_at`) VALUES
(1, 1,  2.00, 'NO',  'Michael Scott',   'Floor 3 Expansion',   'Installed in Floor 3 IDF switch rack for VOIP phones', 1, NOW() - INTERVAL 6 DAY, NOW() - INTERVAL 6 DAY),
(2, 1,  1.00, 'NO',  'Sarah Connor',    'Security Operations', 'Dedicated switch for Security CCTV surveillance VLAN', 1, NOW() - INTERVAL 4 DAY, NOW() - INTERVAL 4 DAY),
(3, 2,  1.00, 'NO',  'David Miller',    'WAN Infrastructure',  'Redundant router replacement for Branch Office WAN link', 1, NOW() - INTERVAL 5 DAY, NOW() - INTERVAL 5 DAY),
(4, 4,  8.00, 'NO',  'Network Technician', 'Facilities & Wi-Fi',  'Deployed 8 APs across Building B conference rooms', 2, NOW() - INTERVAL 3 DAY, NOW() - INTERVAL 3 DAY),
(5, 5, 12.00, 'NO',  'Alex Mercer',     'Server Engineering',  '10G uplinks from VM hosts to Core switch stack', 1, NOW() - INTERVAL 2 DAY, NOW() - INTERVAL 2 DAY),
(6, 6, 350.00,'MTR', 'Network Technician', 'Field Engineering',  'Network cabling run for new engineering workbenches', 2, NOW() - INTERVAL 2 DAY, NOW() - INTERVAL 2 DAY),
(7, 7, 180.00,'MTR', 'Elena Gilbert',   'Fiber Optics Team',   'Backbone fiber run between Data Center and Block C IDF', 1, NOW() - INTERVAL 1 DAY, NOW() - INTERVAL 1 DAY),
(8, 8,  2.00, 'NO',  'John Doe',        'Infrastructure Team', 'Installed in Block C IDF for floor data termination', 3, NOW() - INTERVAL 1 DAY, NOW() - INTERVAL 1 DAY);

INSERT INTO `audit_logs` (`user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `created_at`) VALUES
(1, 'SYSTEM_INIT', 'SYSTEM', 0, 'Initial database schema and seed data deployed', '127.0.0.1', NOW() - INTERVAL 10 DAY),
(1, 'USER_CREATE', 'USER', 1, 'Created primary administrator account [admin]', '127.0.0.1', NOW() - INTERVAL 10 DAY),
(1, 'USER_CREATE', 'USER', 2, 'Created standard user account [user]', '127.0.0.1', NOW() - INTERVAL 10 DAY),
(1, 'ASSET_CREATE', 'ASSET', 1, 'Added asset NET-SW-9300 (Qty: 10 NO)', '127.0.0.1', NOW() - INTERVAL 10 DAY),
(1, 'ASSET_ISSUE', 'USAGE', 1, 'Issued 2 NO of NET-SW-9300 to Michael Scott', '127.0.0.1', NOW() - INTERVAL 6 DAY),
(2, 'ASSET_ISSUE', 'USAGE', 4, 'Issued 8 NO of NET-AP-9130 to Network Technician', '192.168.1.45', NOW() - INTERVAL 3 DAY),
(2, 'ASSET_ISSUE', 'USAGE', 6, 'Issued 350 MTR of NET-CAB-C6U to Network Technician', '192.168.1.45', NOW() - INTERVAL 2 DAY);

INSERT INTO `app_settings` (`setting_key`, `setting_value`, `description`, `updated_at`) VALUES
('organization_name', 'Enterprise Network Operations', 'Organization or department display name', NOW()),
('session_timeout_minutes', '30', 'Session inactivity timeout in minutes', NOW()),
('low_stock_threshold_no', '3', 'Low stock alert threshold for discrete items (NO)', NOW()),
('low_stock_threshold_mtr', '100', 'Low stock alert threshold for cables (MTR)', NOW()),
('default_page_size', '10', 'Default rows per page in tables', NOW());
