<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireLogin()

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error: " & g_LastDbError
    Response.End
End If

Dim errorMessage, preselectedAssetId
errorMessage = ""
preselectedAssetId = CleanInput(Request("asset_id"))

' Handle POST Issue Request
If Request.ServerVariables("REQUEST_METHOD") = "POST" Then
    Dim body
    body = ReadRequestBody()

    Dim assetId, qtyUsedStr, usedBy, department, shortDesc
    assetId    = GetRequestField("asset_id", body)
    qtyUsedStr = GetRequestField("quantity_used", body)
    usedBy     = GetRequestField("used_by", body)
    department = GetRequestField("department", body)
    shortDesc  = GetRequestField("short_description", body)

    If Not IsNumeric(assetId) Or CLng(assetId) <= 0 Then
        errorMessage = "Please select a valid network asset."
    ElseIf Not IsNumeric(qtyUsedStr) Or CDbl(qtyUsedStr) <= 0 Then
        errorMessage = "Quantity used must be greater than zero."
    ElseIf usedBy = "" Or department = "" Or shortDesc = "" Then
        errorMessage = "Employee Name, Department, and Description are required."
    Else
        Dim qtyUsed
        qtyUsed = CDbl(qtyUsedStr)

        ' Begin Atomic Transaction
        On Error Resume Next
        conn.BeginTrans

        ' Check and atomically decrement available stock
        Dim cmdStock, rowsAffected
        Set cmdStock = Server.CreateObject("ADODB.Command")
        Set cmdStock.ActiveConnection = conn
        cmdStock.CommandText = "UPDATE assets SET asset_available = asset_available - ?, updated_at = NOW() " & _
                               "WHERE id = ? AND asset_available >= ?"
        cmdStock.CommandType = 1
        cmdStock.Parameters.Append cmdStock.CreateParameter("p_dec", 131, 1, , qtyUsed)
        cmdStock.Parameters.Append cmdStock.CreateParameter("p_id", 3, 1, , CLng(assetId))
        cmdStock.Parameters.Append cmdStock.CreateParameter("p_chk", 131, 1, , qtyUsed)
        cmdStock.Execute rowsAffected

        If Err.Number <> 0 Or rowsAffected <= 0 Then
            conn.RollbackTrans
            Set cmdStock = Nothing
            If Err.Number <> 0 Then
                errorMessage = "Database error: " & Err.Description
            Else
                errorMessage = "Insufficient stock available! Another technician may have checked out this item simultaneously."
            End If
        Else
            Set cmdStock = Nothing

            ' Fetch asset details for transaction
            Dim cmdGetA, rsA, aUom, aNum, remainingAvail
            Set cmdGetA = Server.CreateObject("ADODB.Command")
            Set cmdGetA.ActiveConnection = conn
            cmdGetA.CommandText = "SELECT asset_number, asset_available, uom FROM assets WHERE id = ?"
            cmdGetA.CommandType = 1
            cmdGetA.Parameters.Append cmdGetA.CreateParameter("p_id", 3, 1, , CLng(assetId))
            Set rsA = cmdGetA.Execute

            aNum = rsA("asset_number")
            aUom = rsA("uom")
            remainingAvail = rsA("asset_available")
            rsA.Close
            Set rsA = Nothing
            Set cmdGetA = Nothing

            ' Insert into asset_usage
            Dim cmdInsertUsage
            Set cmdInsertUsage = Server.CreateObject("ADODB.Command")
            Set cmdInsertUsage.ActiveConnection = conn
            cmdInsertUsage.CommandText = "INSERT INTO asset_usage (asset_id, quantity_used, uom, used_by, department, " & _
                                         "short_description, issued_by_user_id, usage_datetime, created_at) " & _
                                         "VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())"
            cmdInsertUsage.CommandType = 1
            cmdInsertUsage.Parameters.Append cmdInsertUsage.CreateParameter("p_aid", 3, 1, , CLng(assetId))
            cmdInsertUsage.Parameters.Append cmdInsertUsage.CreateParameter("p_q", 131, 1, , qtyUsed)
            cmdInsertUsage.Parameters.Append cmdInsertUsage.CreateParameter("p_uom", 200, 1, 10, aUom)
            cmdInsertUsage.Parameters.Append cmdInsertUsage.CreateParameter("p_by", 200, 1, 100, usedBy)
            cmdInsertUsage.Parameters.Append cmdInsertUsage.CreateParameter("p_dept", 200, 1, 100, department)
            cmdInsertUsage.Parameters.Append cmdInsertUsage.CreateParameter("p_desc", 200, 1, 255, Left(shortDesc, 255))
            cmdInsertUsage.Parameters.Append cmdInsertUsage.CreateParameter("p_uid", 3, 1, , GetAuthUserId())
            cmdInsertUsage.Execute
            Set cmdInsertUsage = Nothing

            ' Get new TX ID
            Dim newTxId, rsTx
            newTxId = 0
            Set rsTx = conn.Execute("SELECT LAST_INSERT_ID() AS tx")
            If Not rsTx.EOF Then newTxId = CLng(rsTx("tx"))
            rsTx.Close
            Set rsTx = Nothing

            ' Audit log
            LogAudit conn, GetAuthUserId(), "ASSET_ISSUE", "USAGE", newTxId, _
                     "Issued " & qtyUsed & " " & aUom & " of " & aNum & " to " & usedBy & " (" & department & "). Remaining: " & remainingAvail

            ' Commit
            conn.CommitTrans
            CloseDbConnection conn

            If InStr(LCase(Request.ServerVariables("HTTP_ACCEPT")), "application/json") > 0 Or Request.QueryString("ajax") = "1" Then
                Response.Clear
                Response.ContentType = "application/json; charset=utf-8"
                Response.Write "{""success"":true,""message"":""Asset issued successfully!"",""data"":{""transaction_id"":" & newTxId & ",""remaining"":" & remainingAvail & "}}"
                Response.End
            Else
                Response.Redirect "asset_usage.asp?msg=issued"
                Response.End
            End If
        End If
        On Error GoTo 0
    End If

    If InStr(LCase(Request.ServerVariables("HTTP_ACCEPT")), "application/json") > 0 Or Request.QueryString("ajax") = "1" Then
        Response.Clear
        Response.ContentType = "application/json; charset=utf-8"
        Response.Status = "400 Bad Request"
        Response.Write "{""success"":false,""message"":""" & Replace(errorMessage, """", "\""") & """}"
        Response.End
    End If
End If

' Fetch available assets for dropdown
Dim rsAvail
Set rsAvail = conn.Execute("SELECT id, asset_number, asset_name, asset_location, asset_available, uom " & _
                           "FROM assets WHERE asset_available > 0 ORDER BY asset_number ASC")

Dim pageTitle
pageTitle = "Issue Network Asset"
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Issue / Pick Network Asset</h1>
        <p>Allocate equipment or bulk cabling to staff and departments with atomic inventory tracking.</p>
    </div>
    <div class="page-header-actions">
        <a href="asset_usage.asp" class="btn btn-secondary">&larr; Usage History</a>
    </div>
</div>

<div class="card" style="max-width: 680px;">
    <div class="card-body">
        <% If errorMessage <> "" Then %>
            <div class="form-error" style="background-color: var(--danger-light); padding: 10px 14px; border-radius: var(--radius-md); margin-bottom: 20px;">
                <%= HtmlEncode(errorMessage) %>
            </div>
        <% End If %>

        <form method="POST" action="asset_issue.asp" id="issueForm">
            <input type="hidden" name="csrf_token" value="<%= GetCsrfToken() %>">

            <div class="form-group">
                <label for="asset_id" class="form-label required">Select Asset</label>
                <select id="asset_id" name="asset_id" class="form-select" required onchange="onAssetSelected(this)">
                    <option value="">-- Choose an available asset --</option>
                    <% Do While Not rsAvail.EOF %>
                        <% Dim isSel: isSel = (CStr(rsAvail("id")) = CStr(preselectedAssetId)) %>
                        <option value="<%= rsAvail("id") %>" 
                                data-number="<%= HtmlEncode(rsAvail("asset_number")) %>"
                                data-name="<%= HtmlEncode(rsAvail("asset_name")) %>"
                                data-loc="<%= HtmlEncode(rsAvail("asset_location")) %>"
                                data-avail="<%= rsAvail("asset_available") %>"
                                data-uom="<%= rsAvail("uom") %>"
                                <%= IIf(isSel, "selected", "") %>>
                            <%= HtmlEncode(rsAvail("asset_number")) %> - <%= HtmlEncode(rsAvail("asset_name")) %> (<%= FormatDisplayQuantity(rsAvail("asset_available"), rsAvail("uom")) %> available)
                        </option>
                        <% rsAvail.MoveNext %>
                    <% Loop %>
                </select>
            </div>

            <!-- Auto-populated Asset Details Box -->
            <div style="background-color: #f8fafc; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; margin-bottom: 18px;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 13px;">
                    <div><span class="text-muted">Asset Number:</span> <strong id="dispNum" class="font-mono text-primary">-</strong></div>
                    <div><span class="text-muted">Location:</span> <strong id="dispLoc">-</strong></div>
                    <div><span class="text-muted">Asset Name:</span> <strong id="dispName">-</strong></div>
                    <div>
                        <span class="text-muted">Available Stock:</span> 
                        <strong id="dispAvail" class="text-success" style="font-size: 15px;">-</strong>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="quantity_used" class="form-label required">Quantity to Issue</label>
                <input type="number" id="quantity_used" name="quantity_used" class="form-control" step="any" min="0.01" placeholder="Enter amount to checkout" required>
                <div class="form-text" id="dispMaxHelp">Enter amount &le; available stock.</div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label for="used_by" class="form-label required">Used By (Employee Name)</label>
                    <input type="text" id="used_by" name="used_by" class="form-control" placeholder="Full name of recipient" required value="<%= HtmlEncode(GetAuthFullName()) %>">
                </div>

                <div class="form-group">
                    <label for="department" class="form-label required">Department</label>
                    <input type="text" id="department" name="department" class="form-control" placeholder="e.g. Network Operations" required value="<%= HtmlEncode(GetAuthDepartment()) %>">
                </div>
            </div>

            <div class="form-group">
                <label for="short_description" class="form-label required">Usage Purpose / Work Order</label>
                <textarea id="short_description" name="short_description" class="form-control" rows="3" maxlength="255" placeholder="Specify rack location, IDF switch port, or deployment justification..." required></textarea>
                <div class="form-text">Maximum 255 characters.</div>
            </div>

            <div style="display: flex; gap: 10px; margin-top: 24px;">
                <button type="submit" class="btn btn-primary btn-lg" id="btnSubmitIssue">Submit Usage Request</button>
                <a href="asset_usage.asp" class="btn btn-secondary btn-lg">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
function onAssetSelected(sel) {
    const opt = sel.options[sel.selectedIndex];
    if (!opt || !opt.value) {
        document.getElementById('dispNum').textContent = '-';
        document.getElementById('dispLoc').textContent = '-';
        document.getElementById('dispName').textContent = '-';
        document.getElementById('dispAvail').textContent = '-';
        document.getElementById('dispMaxHelp').textContent = 'Enter amount <= available stock.';
        return;
    }
    const num = opt.getAttribute('data-number');
    const name = opt.getAttribute('data-name');
    const loc = opt.getAttribute('data-loc');
    const avail = parseFloat(opt.getAttribute('data-avail')) || 0;
    const uom = opt.getAttribute('data-uom');

    document.getElementById('dispNum').textContent = num;
    document.getElementById('dispLoc').textContent = loc;
    document.getElementById('dispName').textContent = name;
    document.getElementById('dispAvail').textContent = `${avail} ${uom}`;
    document.getElementById('dispMaxHelp').textContent = `Max available: ${avail} ${uom}`;
    document.getElementById('quantity_used').max = avail;
}

document.addEventListener('DOMContentLoaded', function() {
    const sel = document.getElementById('asset_id');
    if (sel && sel.value) onAssetSelected(sel);
});
</script>

<%
rsAvail.Close
Set rsAvail = Nothing
CloseDbConnection conn
%>

<!--#include file="includes/footer.asp"-->
