# Network Asset Management System
## End-User & Administrator Guide

This guide describes how to operate the Network Asset Management portal for day-to-day network inventory management, equipment checkouts, tracking, and audit reporting.

---

## 1. User Roles & Permission Matrix

| Feature / Action | Administrator (`admin`) | Standard User (`user`) |
| :--- | :---: | :---: |
| Log in securely with session management | Yes | Yes |
| View Operations Dashboard & KPI Cards | Yes | Yes |
| Search, filter, and view network assets | Yes | Yes |
| View detailed asset specifications | Yes | Yes |
| Issue / Check out stock (`Use Asset` form) | Yes | Yes |
| View complete asset usage history | Yes | Yes |
| Add new network assets | Yes | No |
| Edit existing assets & stock adjustments | Yes | No |
| Access Reports & Analytics | Yes | No |
| Export inventory & usage data to CSV | Yes | Yes |
| Manage user accounts & reset passwords | Yes | No |
| View security audit logs | Yes | No |
| Access system settings & diagnostics | Yes | No |

---

## 2. Managing Network Assets

### Adding a New Asset (Admin Only)
1. In the sidebar, click **Asset Management**.
2. Click the green **Add Asset** button in the top right.
3. Fill in the modal form:
   - **Asset Number:** Unique barcode or enterprise ID (e.g. `NET-SW-9300`).
   - **Asset Name:** Hardware model or cable type (e.g. `Cisco Catalyst 9300 48-Port Switch`).
   - **Physical Location:** Data center rack, IDF room, or shelf (e.g. `Server Room Rack A1`).
   - **Total Quantity:** The initial stock quantity acquired (numeric value >= 0).
   - *Note:* The system automatically initializes **Asset Available** equal to the total quantity to preserve stock integrity.
   - **Unit of Measurement (UOM):** Choose `NO` for discrete equipment or `MTR` for cables.
4. Click **Save Asset**. The table updates immediately without reloading the entire page.

### Editing an Asset & Stock Corrections (Admin Only)
1. Locate the asset in the Asset Management table.
2. Click the **Edit** button in the Actions column.
3. Update asset name, physical location, or stock adjustments.
   - *Stock Rule:* You cannot set available stock higher than total stock.
   - *Audit Trail:* Every modification is permanently logged with previous and updated values.
4. Click **Save Changes**.

---

## 3. Issuing Stock (`Pick Asset` / `Use Asset`)

Both standard users and administrators can issue available network items for deployments, projects, or maintenance.

1. Click **Issue / Pick Asset** from either the Dashboard or the Asset Management page (or click **Use Asset** directly next to any available asset in the table).
2. The modal form will open:
   - **Select Asset:** Choose an item with available stock from the dropdown.
   - The asset number, description, rack location, UOM, and currently available stock will populate automatically.
   - **Quantity to Issue:** Enter the desired quantity.
     *Client and server enforce that this quantity cannot exceed the available stock.*
   - **Used By (Employee Name):** Enter the receiving technician's name (pre-filled with your name).
   - **Department:** Enter the destination department or team.
   - **Usage Description / Purpose:** Provide the rack slot, ticket ID, or operational reason.
3. Click **Submit Usage Request**.
4. The system executes an atomic transaction:
   - Deducts the issued quantity from `asset_available`.
   - Preserves `asset_quantity` total.
   - Adds a timestamped record to the Usage History.
   - Records an immutable audit log entry.

---

## 4. Reports & CSV Export (Admin Only)

1. In the sidebar, click **Reports & Analytics**.
2. Select any report tab:
   - **Current Inventory:** Master list of all hardware assets and their current balance.
   - **Low Stock & Depleted:** Highlights assets with stock &le; 5 or completely out of stock.
   - **Department Usage:** Aggregated consumption breakdown per department.
   - **Employee Usage:** Totals issued per individual employee.
   - **Daily Breakdown:** Timeline of daily hardware consumption.
   - **Asset Totals:** Lifetime issue counts per equipment model.
3. Select an optional **From Date** and **To Date** to filter transactions, then click **Apply Date Filter**.
4. Click **Export Active Report to CSV** to download a spreadsheet-ready file.

---

## 5. User Account Management (Admin Only)

1. In the sidebar, click **User Management**.
2. View existing users, assigned roles, and last login timestamps.
3. **Add User:** Click **Add User**, enter credentials, full name, role (`admin` or `user`), and department. Passwords are automatically hashed with salted SHA-256 before storage.
4. **Deactivate User:** Click **Deactivate** to prevent an account from logging in without deleting historical audit records.
5. **Reset Password:** Click **Reset Pass** to provide a new password for any user.
