<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireAdmin()

Dim errorMessage, successMessage
errorMessage = ""
successMessage = ""

' Handle POST Submission
If Request.ServerVariables("REQUEST_METHOD") = "POST" Then
    Dim conn
    Set conn = GetDbConnection()
    If conn Is Nothing Then
        errorMessage = "Database connection error: " & g_LastDbError
    Else
        Dim body
        body = ReadRequestBody()

        Dim assetNumber, assetName, assetLocation, assetQuantity, uom
        assetNumber   = GetRequestField("asset_number", body)
        assetName     = GetRequestField("asset_name", body)
        assetLocation = GetRequestField("asset_location", body)
        assetQuantity = GetRequestField("asset_quantity", body)
        uom           = UCase(GetRequestField("uom", body))

        ' Validations
        If assetNumber = "" Or assetName = "" Or assetLocation = "" Then
            errorMessage = "Asset Number, Name, and Location are required."
        ElseIf Not IsNumeric(assetQuantity) Or CDbl(assetQuantity) < 0 Then
            errorMessage = "Asset Quantity must be a valid non-negative number."
        ElseIf Not IsValidUOM(uom) Then
            errorMessage = "Unit of Measurement (UOM) must be 'NO' or 'MTR'."
        Else
            Dim qtyNum
            qtyNum = CDbl(assetQuantity)

            On Error Resume Next
            ' Check duplicate asset number
            Dim cmdCheck, rsCheck
            Set cmdCheck = Server.CreateObject("ADODB.Command")
            Set cmdCheck.ActiveConnection = conn
            cmdCheck.CommandText = "SELECT id FROM assets WHERE asset_number = ?"
            cmdCheck.CommandType = 1
            cmdCheck.Parameters.Append cmdCheck.CreateParameter("p_num", 200, 1, 50, assetNumber)
            Set rsCheck = cmdCheck.Execute

            If Not rsCheck.EOF Then
                errorMessage = "Asset Number '" & assetNumber & "' already exists. Please choose a unique number."
                rsCheck.Close
                Set rsCheck = Nothing
                Set cmdCheck = Nothing
            Else
                rsCheck.Close
                Set rsCheck = Nothing
                Set cmdCheck = Nothing

                ' Insert asset (asset_available initialized equal to asset_quantity)
                Dim cmdInsert
                Set cmdInsert = Server.CreateObject("ADODB.Command")
                Set cmdInsert.ActiveConnection = conn
                cmdInsert.CommandText = "INSERT INTO assets (asset_number, asset_name, asset_location, asset_quantity, asset_available, uom, created_by, created_at) " & _
                                        "VALUES (?, ?, ?, ?, ?, ?, ?, NOW())"
                cmdInsert.CommandType = 1
                cmdInsert.Parameters.Append cmdInsert.CreateParameter("p_num", 200, 1, 50, assetNumber)
                cmdInsert.Parameters.Append cmdInsert.CreateParameter("p_name", 200, 1, 150, assetName)
                cmdInsert.Parameters.Append cmdInsert.CreateParameter("p_loc", 200, 1, 100, assetLocation)
                cmdInsert.Parameters.Append cmdInsert.CreateParameter("p_qty", 131, 1, , qtyNum)
                cmdInsert.Parameters.Append cmdInsert.CreateParameter("p_avail", 131, 1, , qtyNum)
                cmdInsert.Parameters.Append cmdInsert.CreateParameter("p_uom", 200, 1, 10, uom)
                cmdInsert.Parameters.Append cmdInsert.CreateParameter("p_user", 3, 1, , GetAuthUserId())

                cmdInsert.Execute

                If Err.Number <> 0 Then
                    errorMessage = "Database error: " & Err.Description
                Else
                    ' Audit log
                    Dim rsId, newId
                    newId = 0
                    Set rsId = conn.Execute("SELECT LAST_INSERT_ID() AS nid")
                    If Not rsId.EOF Then newId = CLng(rsId("nid"))
                    rsId.Close
                    Set rsId = Nothing

                    LogAudit conn, GetAuthUserId(), "ASSET_CREATE", "ASSET", newId, "Created asset " & assetNumber & " (" & assetName & ") with Qty: " & qtyNum & " " & uom
                    
                    CloseDbConnection conn

                    ' Check if AJAX call
                    If InStr(LCase(Request.ServerVariables("HTTP_ACCEPT")), "application/json") > 0 Or Request.QueryString("ajax") = "1" Then
                        Response.Clear
                        Response.ContentType = "application/json; charset=utf-8"
                        Response.Write "{""success"":true,""message"":""Asset created successfully!"",""data"":{""id"":" & newId & "}}"
                        Response.End
                    Else
                        Response.Redirect "assets.asp?msg=added"
                        Response.End
                    End If
                End If
                Set cmdInsert = Nothing
            End If
            On Error GoTo 0
        End If
        CloseDbConnection conn
    End If

    ' If AJAX and had an error, return JSON error
    If InStr(LCase(Request.ServerVariables("HTTP_ACCEPT")), "application/json") > 0 Or Request.QueryString("ajax") = "1" Then
        Response.Clear
        Response.ContentType = "application/json; charset=utf-8"
        Response.Status = "400 Bad Request"
        Response.Write "{""success"":false,""message"":""" & Replace(errorMessage, """", "\""") & """,""data"":null}"
        Response.End
    End If
End If

Dim pageTitle
pageTitle = "Add New Asset"
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>Add Network Asset</h1>
        <p>Register a new hardware device, switch, router, or bulk cabling stock into inventory.</p>
    </div>
    <div class="page-header-actions">
        <a href="assets.asp" class="btn btn-secondary">&larr; Back to Assets</a>
    </div>
</div>

<div class="card" style="max-width: 650px;">
    <div class="card-body">
        <% If errorMessage <> "" Then %>
            <div class="form-error" style="background-color: var(--danger-light); padding: 10px 14px; border-radius: var(--radius-md); margin-bottom: 20px;">
                <%= HtmlEncode(errorMessage) %>
            </div>
        <% End If %>

        <form method="POST" action="asset_add.asp">
            <input type="hidden" name="csrf_token" value="<%= GetCsrfToken() %>">

            <div class="form-group">
                <label for="asset_number" class="form-label required">Asset Number</label>
                <input type="text" id="asset_number" name="asset_number" class="form-control" placeholder="e.g. NET-SW-9300" required value="<%= HtmlEncode(Request.Form("asset_number")) %>">
                <div class="form-text">Unique asset identification code.</div>
            </div>

            <div class="form-group">
                <label for="asset_name" class="form-label required">Asset Name</label>
                <input type="text" id="asset_name" name="asset_name" class="form-control" placeholder="e.g. Cisco Catalyst 9300 48-Port Switch" required value="<%= HtmlEncode(Request.Form("asset_name")) %>">
            </div>

            <div class="form-group">
                <label for="asset_location" class="form-label required">Physical Location</label>
                <input type="text" id="asset_location" name="asset_location" class="form-control" placeholder="e.g. Server Room Rack A1" required value="<%= HtmlEncode(Request.Form("asset_location")) %>">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label for="asset_quantity" class="form-label required">Asset Quantity</label>
                    <input type="number" id="asset_quantity" name="asset_quantity" class="form-control" step="any" min="0" placeholder="0" required value="<%= HtmlEncode(Request.Form("asset_quantity")) %>">
                </div>

                <div class="form-group">
                    <label for="asset_available" class="form-label required">Asset Available</label>
                    <input type="number" id="asset_available" class="form-control" readonly title="Automatically initialized to Asset Quantity">
                    <div class="form-text">Auto-initialized to total quantity</div>
                </div>
            </div>

            <div class="form-group">
                <label for="uom" class="form-label required">Unit of Measurement (UOM)</label>
                <select id="uom" name="uom" class="form-select" required>
                    <option value="NO">NO (Discrete Units / Equipment)</option>
                    <option value="MTR">MTR (Meters - Cable / Fiber)</option>
                </select>
            </div>

            <div style="display: flex; gap: 10px; margin-top: 24px;">
                <button type="submit" class="btn btn-primary btn-lg">Save Asset</button>
                <a href="assets.asp" class="btn btn-secondary btn-lg">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const qtyInput = document.getElementById('asset_quantity');
    const availInput = document.getElementById('asset_available');
    if (qtyInput && availInput) {
        qtyInput.addEventListener('input', function() {
            const v = parseFloat(this.value) || 0;
            availInput.value = v >= 0 ? v : 0;
        });
    }
});
</script>

<!--#include file="includes/footer.asp"-->
