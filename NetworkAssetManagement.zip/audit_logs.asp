<!--#include file="config/config.asp"-->
<!--#include file="includes/db_connection.asp"-->
<!--#include file="includes/crypto.asp"-->
<!--#include file="includes/common.asp"-->
<!--#include file="includes/validation.asp"-->
<!--#include file="includes/auth.asp"-->
<!--#include file="includes/permissions.asp"-->
<%
RequireAdmin()
Dim pageTitle
pageTitle = "Audit Logs"

Dim conn
Set conn = GetDbConnection()
If conn Is Nothing Then
    Response.Write "Database connection error: " & g_LastDbError
    Response.End
End If

Dim qAction, qEntity, qFromDate, qToDate
qAction   = CleanInput(Request.QueryString("action"))
qEntity   = CleanInput(Request.QueryString("entity_type"))
qFromDate = CleanInput(Request.QueryString("from_date"))
qToDate   = CleanInput(Request.QueryString("to_date"))

Dim page, pageSize, offset
page = CLng(Request.QueryString("page"))
If page < 1 Then page = 1

pageSize = CLng(Request.QueryString("page_size"))
If pageSize < 1 Or pageSize > 100 Then pageSize = 15

offset = (page - 1) * pageSize

Dim whereClauses
whereClauses = " WHERE 1=1 "

If qAction <> "" Then whereClauses = whereClauses & " AND a.action = '" & EscapeSql(qAction) & "' "
If qEntity <> "" Then whereClauses = whereClauses & " AND a.entity_type = '" & EscapeSql(qEntity) & "' "
If IsValidDateString(qFromDate) Then whereClauses = whereClauses & " AND a.created_at >= '" & EscapeSql(qFromDate) & " 00:00:00' "
If IsValidDateString(qToDate) Then whereClauses = whereClauses & " AND a.created_at <= '" & EscapeSql(qToDate) & " 23:59:59' "

Dim totalRecords, totalPages, rsCount
totalRecords = 0
Set rsCount = conn.Execute("SELECT COUNT(*) AS c FROM audit_logs a " & whereClauses)
If Not rsCount.EOF Then totalRecords = CLng(rsCount("c"))
rsCount.Close
Set rsCount = Nothing

If totalRecords > 0 Then
    totalPages = Int((totalRecords + pageSize - 1) / pageSize)
Else
    totalPages = 1
End If

Dim rsLogs
Set rsLogs = conn.Execute("SELECT a.id, a.user_id, a.action, a.entity_type, a.entity_id, " & _
                          "a.details, a.ip_address, a.created_at, COALESCE(u.username, 'System') AS username " & _
                          "FROM audit_logs a LEFT JOIN users u ON a.user_id = u.id " & _
                          whereClauses & " ORDER BY a.id DESC LIMIT " & offset & ", " & pageSize)

Function BuildAuditQuery(targetPage)
    BuildAuditQuery = "audit_logs.asp?page=" & targetPage & _
                      "&page_size=" & pageSize & _
                      "&action=" & Server.URLEncode(qAction) & _
                      "&entity_type=" & Server.URLEncode(qEntity) & _
                      "&from_date=" & Server.URLEncode(qFromDate) & _
                      "&to_date=" & Server.URLEncode(qToDate)
End Function
%>
<!--#include file="includes/header.asp"-->

<div class="page-header">
    <div class="page-title-group">
        <h1>System Security & Activity Audit Trail</h1>
        <p>Immutable operational logging tracking logins, stock issuance, asset modifications, and administrative operations.</p>
    </div>
</div>

<!-- Filters Form -->
<form method="GET" action="audit_logs.asp" class="filter-card">
    <div class="filter-grid">
        <div class="form-group" style="margin-bottom: 0;">
            <label for="fa_act" class="form-label" style="font-size: 11px;">ACTION</label>
            <input type="text" id="fa_act" name="action" class="form-control" placeholder="e.g. ASSET_ISSUE" value="<%= HtmlEncode(qAction) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fa_ent" class="form-label" style="font-size: 11px;">ENTITY TYPE</label>
            <select id="fa_ent" name="entity_type" class="form-select">
                <option value="">All Entities</option>
                <option value="ASSET" <%= IIf(qEntity = "ASSET", "selected", "") %>>ASSET</option>
                <option value="USAGE" <%= IIf(qEntity = "USAGE", "selected", "") %>>USAGE</option>
                <option value="USER" <%= IIf(qEntity = "USER", "selected", "") %>>USER</option>
                <option value="AUTH" <%= IIf(qEntity = "AUTH", "selected", "") %>>AUTH</option>
                <option value="SYSTEM" <%= IIf(qEntity = "SYSTEM", "selected", "") %>>SYSTEM</option>
            </select>
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fa_from" class="form-label" style="font-size: 11px;">FROM DATE</label>
            <input type="date" id="fa_from" name="from_date" class="form-control" value="<%= HtmlEncode(qFromDate) %>">
        </div>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="fa_to" class="form-label" style="font-size: 11px;">TO DATE</label>
            <input type="date" id="fa_to" name="to_date" class="form-control" value="<%= HtmlEncode(qToDate) %>">
        </div>

        <div class="filter-actions" style="margin-bottom: 0;">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="audit_logs.asp" class="btn btn-secondary">Reset</a>
            <select name="page_size" class="form-select" style="width: 80px;" onchange="this.form.submit()">
                <option value="15" <%= IIf(pageSize = 15, "selected", "") %>>15</option>
                <option value="30" <%= IIf(pageSize = 30, "selected", "") %>>30</option>
                <option value="50" <%= IIf(pageSize = 50, "selected", "") %>>50</option>
            </select>
        </div>
    </div>
</form>

<!-- Audit Table -->
<div class="card">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 60px;">Log ID</th>
                    <th>Timestamp</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Entity</th>
                    <th>Details</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody>
                <% If rsLogs Is Nothing Or rsLogs.EOF Then %>
                    <tr><td colspan="7" class="empty-state"><p>No audit events match your filter criteria.</p></td></tr>
                <% Else %>
                    <% Do While Not rsLogs.EOF %>
                    <% 
                    Dim actBadgeClass: actBadgeClass = "badge-stock-in"
                    If InStr(rsLogs("action"), "FAIL") > 0 Or InStr(rsLogs("action"), "DELETE") > 0 Then
                        actBadgeClass = "badge-stock-out"
                    ElseIf InStr(rsLogs("action"), "UPDATE") > 0 Or InStr(rsLogs("action"), "RESET") > 0 Then
                        actBadgeClass = "badge-stock-low"
                    End If
                    %>
                    <tr>
                        <td class="font-mono text-muted">#<%= rsLogs("id") %></td>
                        <td class="font-mono text-muted" style="font-size: 11px;"><%= FormatDisplayDate(rsLogs("created_at")) %></td>
                        <td><strong><%= HtmlEncode(rsLogs("username")) %></strong></td>
                        <td><span class="badge <%= actBadgeClass %>"><%= HtmlEncode(rsLogs("action")) %></span></td>
                        <td><span class="badge" style="background:#e2e8f0; color:#334155;"><%= HtmlEncode(rsLogs("entity_type")) %></span></td>
                        <td><%= HtmlEncode(IIf(IsNull(rsLogs("details")), "-", rsLogs("details"))) %></td>
                        <td class="font-mono text-muted" style="font-size: 11px;"><%= HtmlEncode(IIf(IsNull(rsLogs("ip_address")), "-", rsLogs("ip_address"))) %></td>
                    </tr>
                    <% rsLogs.MoveNext %>
                    <% Loop %>
                <% End If %>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="pagination-toolbar">
        <div class="pagination-info">
            Showing <strong><%= IIf(totalRecords > 0, offset + 1, 0) %></strong> to <strong><%= IIf(offset + pageSize > totalRecords, totalRecords, offset + pageSize) %></strong> of <strong><%= totalRecords %></strong> logs
        </div>
        <div class="pagination-controls">
            <% If page > 1 Then %>
                <a href="<%= BuildAuditQuery(page - 1) %>" class="page-btn">&laquo;</a>
            <% Else %>
                <button class="page-btn" disabled>&laquo;</button>
            <% End If %>

            <% For p = 1 To totalPages %>
                <% If p = page Then %>
                    <span class="page-btn active"><%= p %></span>
                <% ElseIf p <= 5 Or p = totalPages Or (p >= page - 2 And p <= page + 2) Then %>
                    <a href="<%= BuildAuditQuery(p) %>" class="page-btn"><%= p %></a>
                <% End If %>
            <% Next %>

            <% If page < totalPages Then %>
                <a href="<%= BuildAuditQuery(page + 1) %>" class="page-btn">&raquo;</a>
            <% Else %>
                <button class="page-btn" disabled>&raquo;</button>
            <% End If %>
        </div>
    </div>
</div>

<%
If Not rsLogs Is Nothing Then
    rsLogs.Close
    Set rsLogs = Nothing
End If
CloseDbConnection conn
%>

<!--#include file="includes/footer.asp"-->
